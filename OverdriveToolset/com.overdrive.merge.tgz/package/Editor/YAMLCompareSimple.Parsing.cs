using UnityEditor;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    public partial class YAMLCompareSimple
    {
        private static BlockCategory CategorizeBlock(string typeID, string fileID, bool isStripped)
        {
            if (isStripped)              return BlockCategory.Stripped;
            if (fileID.Length <= 2)      return BlockCategory.SceneSettings;
            if (typeID == "1660057539")  return BlockCategory.SceneRoots;
            if (typeID == "1")           return BlockCategory.GameObject;
            if (typeID == "1001")        return BlockCategory.PrefabInstance;
            return BlockCategory.Secondary;
        }

        private Dictionary<string, YAMLBlock> ParseYAMLBlocks(string yamlContent)
        {
            var blocks    = new Dictionary<string, YAMLBlock>();
            var documents = BlockSplitRegex.Split(yamlContent);

            foreach (var doc in documents)
            {
                if (string.IsNullOrWhiteSpace(doc)) continue;

                var headerMatch = BlockHeaderRegex.Match(doc);
                if (!headerMatch.Success) continue;

                string typeID      = headerMatch.Groups[1].Value;
                string fileID      = headerMatch.Groups[2].Value;
                bool   isStripped  = headerMatch.Groups[3].Value.Contains("stripped");

                var    typeLineMatch = ObjectTypeRegex.Match(doc);
                string objectType   = typeLineMatch.Success ? typeLineMatch.Groups[1].Value : $"Type{typeID}";

                string name = null;
                var nameMatch = NameRegex.Match(doc);
                if (nameMatch.Success)
                {
                    name = nameMatch.Groups[1].Value.Trim();
                    if (string.IsNullOrEmpty(name)) name = null;
                }

                // MonoBehaviour blocks — extract script class name from m_EditorClassIdentifier
                if (typeID == "114")
                {
                    var classIdMatch = EditorClassIdRegex.Match(doc);
                    if (classIdMatch.Success)
                        name = classIdMatch.Groups[1].Value;
                }

                // PrefabInstance blocks — resolve name from source prefab GUID
                if (name == null && typeID == "1001")
                {
                    var guidMatch = SourcePrefabGuidRegex.Match(doc);
                    if (guidMatch.Success)
                    {
                        string assetPath = AssetDatabase.GUIDToAssetPath(guidMatch.Groups[1].Value);
                        if (!string.IsNullOrEmpty(assetPath))
                            name = System.IO.Path.GetFileNameWithoutExtension(assetPath);
                    }
                }

                string parentGoID = null;
                var goRefMatch = GameObjectRefRegex.Match(doc);
                if (goRefMatch.Success)
                    parentGoID = goRefMatch.Groups[1].Value;

                string prefabOwnerID = null;
                if (isStripped)
                {
                    var piMatch = PrefabInstanceRefRegex.Match(doc);
                    if (piMatch.Success && piMatch.Groups[1].Value != "0")
                        prefabOwnerID = piMatch.Groups[1].Value;
                }

                string fatherID = null;
                var fatherMatch = FatherRefRegex.Match(doc);
                if (fatherMatch.Success && fatherMatch.Groups[1].Value != "0")
                    fatherID = fatherMatch.Groups[1].Value;

                blocks[fileID] = new YAMLBlock
                {
                    typeID        = typeID,
                    fileID        = fileID,
                    objectType    = objectType,
                    fullContent   = doc,
                    name          = name,
                    category      = CategorizeBlock(typeID, fileID, isStripped),
                    parentGoID    = parentGoID,
                    prefabOwnerID = prefabOwnerID,
                    fatherID      = fatherID
                };
            }

            return blocks;
        }

        /// <summary>
        /// Post-parse pass: propagate prefabOwnerID from stripped proxy blocks to their non-stripped
        /// companion blocks (added GOs, added components) by following parentGoID and fatherID chains.
        /// After this pass, any block with prefabOwnerID != null is owned by a PrefabInstance and
        /// should be skipped in the main comparison loop.
        /// </summary>
        private static void ResolvePrefabCompanions(Dictionary<string, YAMLBlock> blocks)
        {
            // Iteratively propagate ownership until stable
            bool changed = true;
            while (changed)
            {
                changed = false;
                foreach (var block in blocks.Values)
                {
                    if (block.prefabOwnerID != null) continue;

                    // Component → its parent GO is a stripped (or already-resolved) block
                    if (block.parentGoID != null &&
                        blocks.TryGetValue(block.parentGoID, out var parentGo) &&
                        parentGo.prefabOwnerID != null)
                    {
                        block.prefabOwnerID = parentGo.prefabOwnerID;
                        changed = true;
                        continue;
                    }

                    // Transform → m_Father points to a stripped (or already-resolved) Transform
                    if (block.fatherID != null &&
                        blocks.TryGetValue(block.fatherID, out var father) &&
                        father.prefabOwnerID != null)
                    {
                        block.prefabOwnerID = father.prefabOwnerID;
                        changed = true;
                        continue;
                    }
                }
            }

            // Final pass: GO blocks inherit ownership from any component that was resolved above
            foreach (var block in blocks.Values)
            {
                if (block.prefabOwnerID != null) continue;
                if (block.category != BlockCategory.GameObject) continue;

                foreach (var other in blocks.Values)
                {
                    if (other.parentGoID == block.fileID && other.prefabOwnerID != null)
                    {
                        block.prefabOwnerID = other.prefabOwnerID;
                        break;
                    }
                }
            }
        }

        private static Dictionary<string, string> ParseProperties(string content)
        {
            var result = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(content)) return result;

            string currentKey   = null;
            var    currentValue = new System.Text.StringBuilder();

            foreach (var line in content.Split('\n'))
            {
                var trimmed = line.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("---")) continue;

                int colonIdx = line.IndexOf(':');
                if (colonIdx > 0 && !line.TrimStart().StartsWith("-"))
                {
                    if (currentKey != null)
                        result[currentKey] = currentValue.ToString().Trim();

                    currentKey = line[..colonIdx].Trim();
                    currentValue.Clear();
                    currentValue.Append(line[(colonIdx + 1)..].Trim());
                }
                else if (currentKey != null && (trimmed.StartsWith("-") || trimmed.StartsWith("{")))
                {
                    currentValue.Append(" ");
                    currentValue.Append(trimmed);
                }
            }

            if (currentKey != null)
                result[currentKey] = currentValue.ToString().Trim();

            return result;
        }
    }
}
