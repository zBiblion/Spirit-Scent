using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UIElements;
using System.Collections.Generic;
using System.IO;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// EditorWindow for showing RAW 3-way diff with zero filtering.
    /// Shows all properties from all blocks separately without any management.
    /// </summary>
    public class PullPreviewSimpleWindow : EditorWindow
    {
        private ScrollView _listViewRaw;
        private Label _titleLabel;
        private TextField _searchField;
        private Toggle _onlyShowConflictsToggle;
        private VisualElement _gitNotice;
        private YAMLCompareSimple _comparison;
        
        // ID collision blocking UI
        private VisualElement _idCollisionBlocker;
        private Toggle _makeBackupToggle;
        private bool _hasIDCollisions = false;

        private const string UxmlPath = "UI/PullPreview_Simple";

        [MenuItem("Tools/Overdrive/Scene Merge/TEST Raw Diff Window")]
        public static void TestRawDiffWindow()
        {
            // Use the same test files as YAMLCompare.TestPreviewPullChanges()
            string baseAbsPath   = GetAbsolutePath("Assets/Merge Testing/MergeTest_Base.unity");
            string oursAbsPath   = GetAbsolutePath("Assets/Merge Testing/MergeTest_Ours.unity");
            string theirsAbsPath = GetAbsolutePath("Assets/Merge Testing/MergeTest_Theirs.unity");

            if (!File.Exists(baseAbsPath))
            {
                Debug.LogError($"Test file not found: {baseAbsPath}");
                return;
            }
            if (!File.Exists(oursAbsPath))
            {
                Debug.LogError($"Test file not found: {oursAbsPath}");
                return;
            }
            if (!File.Exists(theirsAbsPath))
            {
                Debug.LogError($"Test file not found: {theirsAbsPath}");
                return;
            }

            var comparison = new YAMLCompareSimple();
            
            // CRITICAL: Check for ID collisions BEFORE doing any comparison
            bool hasCollisions = comparison.DetectIDCollisions(baseAbsPath, oursAbsPath, theirsAbsPath);
            
            if (!hasCollisions)
            {
                // Safe to proceed with full comparison
                comparison.CompareFiles(baseAbsPath, oursAbsPath, theirsAbsPath);
            }
            
            ShowWindow(comparison);
        }

        private static string GetAbsolutePath(string assetPath)
        {
            // Convert Unity relative path (Assets/...) to absolute file system path
            if (assetPath.StartsWith("Assets/"))
            {
                return Path.Combine(Application.dataPath, assetPath.Substring(7));
            }
            return assetPath;
        }

        // Main entry point - call this with a YAMLCompareSimple object
        public static void ShowWindow(YAMLCompareSimple comparison)
        {
            var window = GetWindow<PullPreviewSimpleWindow>("Raw Diff Preview");
            window._comparison = comparison;
            window.RefreshDisplay();
        }

        private void OnEnable()
        {
            CreateUI();
        }

        private void CreateUI()
        {
            var root = rootVisualElement;
            root.Clear();

            var template = Resources.Load<VisualTreeAsset>(UxmlPath);
            if (template != null)
            {
                template.CloneTree(root);
                _titleLabel = root.Q<Label>("Title");
                _gitNotice = root.Q<VisualElement>("GitNotice");
                _listViewRaw = root.Q<ScrollView>("ListViewRaw");
                _searchField = root.Q<TextField>("Search");
                _onlyShowConflictsToggle = root.Q<Toggle>("OnlyShowConflicts");
                
                // Remove example items container
                var examplesContainer = root.Q<VisualElement>("Examples");
                if (examplesContainer != null)
                {
                    examplesContainer.RemoveFromHierarchy();
                }

                // Setup search field
                if (_searchField != null)
                {
                    _searchField.RegisterValueChangedCallback(evt => RefreshDisplay());
                }
                
                // Setup toggle for conflict-only filtering
                if (_onlyShowConflictsToggle != null)
                {
                    _onlyShowConflictsToggle.RegisterValueChangedCallback(evt => RefreshDisplay());
                }
            }
            else
            {
                Debug.LogWarning($"[PullPreviewSimpleWindow] Could not load UXML at Resources/{UxmlPath}");
                _titleLabel = new Label("Raw Diff Preview");
                root.Add(_titleLabel);
                _listViewRaw = new ScrollView();
                _listViewRaw.style.flexGrow = 1;
                root.Add(_listViewRaw);
            }

            if (_titleLabel != null)
                _titleLabel.text = "Raw Diff Preview";

            // Hide git notice
            if (_gitNotice != null)
                _gitNotice.style.display = DisplayStyle.None;

            if (_comparison != null)
                RefreshDisplay();
        }

        private void RefreshDisplay()
        {
            if (_comparison == null || _listViewRaw == null) return;

            _listViewRaw.Clear();
            
            // Remove any existing ID collision blocker
            if (_idCollisionBlocker != null)
            {
                _idCollisionBlocker.RemoveFromHierarchy();
                _idCollisionBlocker = null;
            }
            
            // Check if we have ID collisions that need to be fixed first
            _hasIDCollisions = _comparison.detectedCollisions.Count > 0;
            
            if (_hasIDCollisions)
            {
                ShowIDCollisionBlocker();
                return;
            }

            // Normal display - no ID collisions
            string searchQuery = _searchField?.value?.ToLower() ?? "";
            bool onlyShowConflicts = _onlyShowConflictsToggle?.value ?? false;

            int totalPropertyDiffs = 0;

            // Render all changes
            foreach (var change in _comparison.changes)
            {
                // Skip SceneRoots (scene ordering metadata - not actionable)
                if (change.isSceneRoots)
                    continue;

                // Apply search filter
                if (!string.IsNullOrEmpty(searchQuery))
                {
                    string combinedText = $"{change.displayPath} {change.propertyName} {change.oursValue} {change.theirsValue}".ToLower();
                    if (!combinedText.Contains(searchQuery))
                        continue;
                }

                // Filter by conflict status
                if (onlyShowConflicts && !change.isConflict)
                    continue;

                var item = CreateRawDiffItem(change);
                _listViewRaw.Add(item);
                totalPropertyDiffs++;
            }

            if (totalPropertyDiffs == 0)
            {
                if (string.IsNullOrEmpty(searchQuery))
                {
                    _listViewRaw.Add(new Label($"No property diffs found.\nTotal changes: {_comparison.changes.Count}"));
                }
                else
                {
                    _listViewRaw.Add(new Label($"No matching properties found for '{searchQuery}'."));
                }
            }
            else
            {
                if (_titleLabel != null)
                    _titleLabel.text = $"Raw Diff Preview ({totalPropertyDiffs} properties)";
            }
        }
        
        private void ShowIDCollisionBlocker()
        {
            _idCollisionBlocker = new VisualElement();
            _idCollisionBlocker.style.flexGrow = 1;
            _idCollisionBlocker.style.paddingTop = 20;
            _idCollisionBlocker.style.paddingLeft = 20;
            _idCollisionBlocker.style.paddingRight = 20;
            _idCollisionBlocker.style.paddingBottom = 20;
            
            // Critical warning header
            var headerLabel = new Label("⚠️ CRITICAL: ID COLLISIONS DETECTED");
            headerLabel.style.fontSize = 20;
            headerLabel.style.color = new Color(1f, 0.3f, 0.3f);
            headerLabel.style.unityFontStyleAndWeight = FontStyle.Bold;
            headerLabel.style.marginBottom = 10;
            _idCollisionBlocker.Add(headerLabel);
            
            // Explanation
            var explanationLabel = new Label(
                "These files contain ID collisions that MUST be fixed before merging.\n\n" +
                "An ID collision occurs when the same fileID is used for different component types " +
                "in your version vs. their version. This will crash Unity's merge tool.\n\n" +
                $"Found {_comparison.detectedCollisions.Count} collision(s):");
            explanationLabel.style.fontSize = 14;
            explanationLabel.style.whiteSpace = WhiteSpace.Normal;
            explanationLabel.style.marginBottom = 15;
            _idCollisionBlocker.Add(explanationLabel);
            
            // List each collision
            foreach (var collision in _comparison.detectedCollisions)
            {
                var collisionItem = new VisualElement();
                collisionItem.style.paddingLeft = 10;
                collisionItem.style.paddingBottom = 8;
                collisionItem.style.borderLeftColor = new Color(1f, 0.5f, 0.5f);
                collisionItem.style.borderLeftWidth = 3;
                collisionItem.style.marginBottom = 10;
                
                var collisionLabel = new Label(
                    $"• Block ID: {collision.fileID}\n" +
                    $"  Ours:   {collision.oursObjectType} (ClassID {collision.oursTypeID})\n" +
                    $"  Theirs: {collision.theirsObjectType} (ClassID {collision.theirsTypeID})");
                collisionLabel.style.fontSize = 12;
                collisionLabel.style.whiteSpace = WhiteSpace.Normal;
                collisionItem.Add(collisionLabel);
                
                _idCollisionBlocker.Add(collisionItem);
            }
            
            // Backup checkbox
            _makeBackupToggle = new Toggle("Make a scene backup first (recommended)");
            _makeBackupToggle.value = true;  // On by default
            _makeBackupToggle.style.marginTop = 15;
            _makeBackupToggle.style.marginBottom = 5;
            _idCollisionBlocker.Add(_makeBackupToggle);
            
            // Fix All button
            var fixButton = new Button(OnFixAllCollisions);
            fixButton.text = "Fix All ID Collisions (Renumber in Ours)";
            fixButton.style.height = 40;
            fixButton.style.fontSize = 16;
            fixButton.style.marginTop = 20;
            fixButton.style.backgroundColor = new Color(0.8f, 0.3f, 0.3f);
            _idCollisionBlocker.Add(fixButton);
            
            // Warning note
            var warningLabel = new Label(
                "\nThis will automatically renumber the conflicting blocks in YOUR version (ours) " +
                "and update all references. The changes will be saved to disk immediately.");
            warningLabel.style.fontSize = 12;
            warningLabel.style.whiteSpace = WhiteSpace.Normal;
            warningLabel.style.color = new Color(1f, 1f, 0.7f);
            warningLabel.style.marginTop = 10;
            _idCollisionBlocker.Add(warningLabel);
            
            _listViewRaw.Add(_idCollisionBlocker);
            
            // Update title
            if (_titleLabel != null)
                _titleLabel.text = $"⚠️ ID COLLISIONS - MUST FIX ({_comparison.detectedCollisions.Count})";
        }
        
        private void OnFixAllCollisions()
        {
            if (_comparison == null) return;
            
            // Confirmation dialog
            if (!EditorUtility.DisplayDialog(
                "Fix All ID Collisions",
                $"This will renumber {_comparison.detectedCollisions.Count} conflicting block(s) in your working copy (ours) " +
                "to resolve all ID collisions.\n\n" +
                "All references to these IDs within your file will be updated automatically.\n\n" +
                "This cannot be undone except through version control. Continue?",
                "Fix All",
                "Cancel"))
            {
                return;
            }
            
            Debug.Log($"[PullPreviewSimple] Fixing {_comparison.detectedCollisions.Count} ID collision(s)...");
            
            // Create backup if requested
            bool makeBackup = _makeBackupToggle?.value ?? true;
            string backupPath = null;
            
            if (makeBackup && !string.IsNullOrEmpty(_comparison.oursPath))
            {
                try
                {
                    backupPath = _comparison.oursPath + ".idcollision_backup";
                    File.Copy(_comparison.oursPath, backupPath, true);
                    Debug.Log($"[PullPreviewSimple] Created backup: {backupPath}");
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning($"[PullPreviewSimple] Failed to create backup: {ex.Message}");
                }
            }
            
            // Call the fix method
            bool success = _comparison.FixAllIDCollisions();
            
            if (success)
            {
                // Force Unity to reimport the modified file
                if (!string.IsNullOrEmpty(_comparison.oursPath))
                {
                    string relativePath = GetUnityRelativePath(_comparison.oursPath);
                    if (!string.IsNullOrEmpty(relativePath))
                    {
                        AssetDatabase.ImportAsset(relativePath, ImportAssetOptions.ForceUpdate);
                        Debug.Log($"[PullPreviewSimple] Reimported modified asset: {relativePath}");
                    }
                    else
                    {
                        AssetDatabase.Refresh();
                    }
                }
                
                // Re-check for ID collisions
                Debug.Log("[PullPreviewSimple] Re-checking for ID collisions...");
                bool stillHasCollisions = _comparison.DetectIDCollisions(_comparison.basePath, _comparison.oursPath, _comparison.theirsPath);
                
                if (stillHasCollisions)
                {
                    EditorUtility.DisplayDialog(
                        "Fix Failed",
                        $"ID collision fix failed - {_comparison.detectedCollisions.Count} collision(s) still detected.\n\n" +
                        "Please check the console for errors and try again.",
                        "OK");
                    RefreshDisplay();
                }
                else
                {
                    // Success! Now do the full comparison
                    Debug.Log("[PullPreviewSimple] ✅ All ID collisions fixed! Proceeding with comparison...");
                    _comparison.CompareFiles(_comparison.basePath, _comparison.oursPath, _comparison.theirsPath);
                    
                    string successMessage = "All ID collisions have been fixed successfully.\n\n" +
                                          "The comparison will now proceed normally.";
                    
                    if (!string.IsNullOrEmpty(backupPath))
                    {
                        successMessage += $"\n\nBackup saved to:\n{Path.GetFileName(backupPath)}";
                    }
                    
                    EditorUtility.DisplayDialog(
                        "Success!",
                        successMessage,
                        "OK");
                    
                    RefreshDisplay();
                }
            }
            else
            {
                EditorUtility.DisplayDialog(
                    "Fix Failed",
                    "Failed to fix ID collisions. Please check the console for errors.",
                    "OK");
            }
        }
        
        private string GetUnityRelativePath(string absolutePath)
        {
            // Convert absolute path back to Unity relative path
            string dataPath = Application.dataPath;
            if (absolutePath.StartsWith(dataPath))
            {
                return "Assets" + absolutePath.Substring(dataPath.Length).Replace('\\', '/');
            }
            return null;
        }

        private VisualElement CreateRawDiffItem(YAMLCompareSimple.PropertyChange change)
        {
            var item = new VisualElement();
            item.AddToClassList("raw-item");
            
            // Apply "deleted" class if this is a deletion-related change
            if (change.isDeletion)
            {
                item.AddToClassList("deleted");
            }

            // Apply "conflict" class if this is a conflict
            if (change.isConflict)
            {
                item.AddToClassList("conflict");
            }

            // Path label
            var pathLabel = new Label(change.displayPath);
            pathLabel.name = "Path";
            pathLabel.AddToClassList("item-path");
            item.Add(pathLabel);

            // Property name label
            var itemNameLabel = new Label(change.propertyName);
            itemNameLabel.name = "ItemName";
            itemNameLabel.AddToClassList("item-title");
            item.Add(itemNameLabel);

            // Special case: Conflict where item was deleted but modified on the other side
            if (change.isConflict && change.isDeletion)
            {
                string message;
                if (change.conflictNote != null)
                {
                    message = change.conflictNote;
                }
                else if (change.oursValue == "Deleted")
                {
                    // Deleted in ours, modified in theirs
                    message = "This item was modified in Theirs, but you deleted it. Their changes will be lost. This could make them sad ... or angry.";
                }
                else
                {
                    // Deleted in theirs, modified in ours
                    message = "You modified this item, but it was deleted in Theirs. Your changes will be lost. Best solution until we implement patching: a pointy stick.";
                }

                var conflictNote = new Label(message);
                conflictNote.AddToClassList("conflict-notes");
                item.Add(conflictNote);
                return item;
            }

            // Determine winner: theirs wins if not conflict, or if conflict and prefab
            bool theirsWins = !change.isConflict || !change.oursWins;

            // Ours value
            var oursField = new TextField("Ours");
            oursField.isReadOnly = true;
            oursField.multiline = true;
            oursField.value = change.oursValue ?? "(not present)";
            
            // Apply win/lose style
            if (!theirsWins)
                oursField.AddToClassList("win");
            else
                oursField.AddToClassList("lose");
            
            item.Add(oursField);

            // Theirs value
            var theirsField = new TextField("Theirs");
            theirsField.isReadOnly = true;
            theirsField.multiline = true;
            theirsField.value = change.theirsValue ?? "(not present)";
            
            // Apply win/lose style
            if (theirsWins)
                theirsField.AddToClassList("win");
            else
                theirsField.AddToClassList("lose");
            
            item.Add(theirsField);

            return item;
        }
    }
}
