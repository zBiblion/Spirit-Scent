using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// EditorWindow for previewing incoming changes from Git merges.
    /// </summary>
    public class PullPreviewWindow : EditorWindow
    {
        private ScrollView _itemList;
        private Label _titleLabel;
        private VisualElement _gitNotice;
        private YAMLCompare _comparison;
        private string _fetchError;
        private string _sceneAssetPath;  // Track scene path for stash system
        private string _sceneGuid;       // Track scene GUID for stash system
        private PullPreviewUIBuilder _uiBuilder;

        private const string UxmlPath = "UI/PullPreview";

        [MenuItem("Tools/Overdrive/Scene Merge/Compare Two Files")]
        public static void CompareTwoFiles()
        {
            string pathA = EditorUtility.OpenFilePanel("Select File A", Application.dataPath, "unity,prefab");
            if (string.IsNullOrEmpty(pathA)) return;

            string pathB = EditorUtility.OpenFilePanel("Select File B", Application.dataPath, "unity,prefab");
            if (string.IsNullOrEmpty(pathB)) return;

            var comparison = new YAMLCompare();
            comparison.CompareFiles(pathA, pathB);
            ShowWindow(comparison);
        }

        [MenuItem("Tools/Overdrive/Scene Merge/Pre-Merge Check Active Scene")]
        public static void PreMergeCheckActiveScene()
        {
            var scene = EditorSceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(scene.path))
            {
                Debug.LogError("[SceneMerge] Save the active scene before running a pre-merge check.");
                return;
            }

            string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string repoRoot    = SceneMergeGitOperations.RunGit("rev-parse --show-toplevel", projectRoot);
            if (repoRoot == null)
            {
                Debug.LogError("[SceneMerge] Could not find Git repository root.");
                return;
            }

            string upstream = SceneMergeGitOperations.RunGit("rev-parse --abbrev-ref @{u}", repoRoot);
            if (string.IsNullOrEmpty(upstream))
            {
                Debug.LogError("[SceneMerge] No upstream tracking branch set. Run: git branch --set-upstream-to=origin/<branch>");
                return;
            }

            // Attempt to fetch latest from remote (non-critical; comparisons can work with local data)
            string fetchError = SceneMergeGitOperations.RunGitWithError("fetch", repoRoot);

            string baseCommit = SceneMergeGitOperations.RunGit($"merge-base HEAD {upstream}", repoRoot);
            if (baseCommit == null)
            {
                Debug.LogError($"[SceneMerge] Could not find merge-base between HEAD and {upstream}.");
                return;
            }

            string absScenePath  = Path.GetFullPath(Path.Combine(projectRoot, scene.path));
            string sceneRelToRepo = Path.GetRelativePath(repoRoot, absScenePath).Replace('\\', '/');

            string baseTmp   = Path.GetTempFileName();
            string theirsTmp = Path.GetTempFileName();
            try
            {
                string baseContent   = SceneMergeGitOperations.RunGit($"show {baseCommit}:\"{sceneRelToRepo}\"", repoRoot);
                string theirsContent = SceneMergeGitOperations.RunGit($"show {upstream}:\"{sceneRelToRepo}\"", repoRoot);

                if (baseContent == null)
                {
                    Debug.LogError($"[SceneMerge] Could not read base version of {sceneRelToRepo} at {baseCommit}.");
                    return;
                }
                if (theirsContent == null)
                {
                    Debug.LogError($"[SceneMerge] Could not read {upstream} version of {sceneRelToRepo}.");
                    return;
                }

                File.WriteAllText(baseTmp,   baseContent);
                File.WriteAllText(theirsTmp, theirsContent);

                var comparison = new YAMLCompare();
                comparison.CompareFiles(baseTmp, absScenePath, theirsTmp);
                ShowWindow(comparison, fetchError, scene.path);
            }
            finally
            {
                if (File.Exists(baseTmp))   File.Delete(baseTmp);
                if (File.Exists(theirsTmp)) File.Delete(theirsTmp);
            }
        }

        // Main entry point - call this with a YAMLCompare object
        public static void ShowWindow(YAMLCompare comparison, string fetchError = null, string sceneAssetPath = null)
        {
            SceneMergeLogger.WriteComparisonLog(comparison, fetchError);
            
            var window = GetWindow<PullPreviewWindow>("Pull Preview");
            window._comparison = comparison;
            window._fetchError = fetchError;
            window._sceneAssetPath = sceneAssetPath;
            
            // Get the scene GUID if we have a path
            if (!string.IsNullOrEmpty(sceneAssetPath))
            {
                window._sceneGuid = AssetDatabase.AssetPathToGUID(sceneAssetPath);
            }
            
            window.RefreshDisplay();
        }

        private void OnEnable()
        {
            CreateUI();
        }

        private void CreateUI()
        {
            var root = rootVisualElement;
            root.Clear();

            var template = Resources.Load<VisualTreeAsset>(UxmlPath);
            if (template != null)
            {
                template.CloneTree(root);
                _titleLabel = root.Q<Label>("Title");
                _gitNotice = root.Q<VisualElement>("GitNotice");
                _itemList = root.Q<ScrollView>("ItemList");
                _itemList.Clear(); // Remove example content from UXML
            }
            else
            {
                Debug.LogWarning($"[PullPreviewWindow] Could not load UXML at Resources/{UxmlPath}");
                _titleLabel = new Label("Pull Preview");
                root.Add(_titleLabel);
                _itemList = new ScrollView();
                _itemList.style.flexGrow = 1;
                root.Add(_itemList);
            }

            if (_titleLabel != null)
                _titleLabel.text = EditorSceneManager.GetActiveScene().name;

            if (_comparison != null)
                RefreshDisplay();
        }

        private void RefreshDisplay()
        {
            if (_comparison == null || _itemList == null) return;

            _itemList.Clear();

            // Initialize UI builder
            _uiBuilder = new PullPreviewUIBuilder(_comparison, _sceneAssetPath, StashProperty, StashEntity, OnFixIDCollision);

            // Show/hide git notice based on fetch error
            if (_gitNotice != null)
            {
                _gitNotice.style.display = string.IsNullOrEmpty(_fetchError) ? DisplayStyle.None : DisplayStyle.Flex;
            }

            int oursCount = _comparison.oursBlocks?.Count ?? 0;
            int theirsCount = _comparison.theirsBlocks?.Count ?? 0;

            if (_comparison.changes.Count == 0)
            {
                _itemList.Add(new Label($"No changes detected.\nOurs: {oursCount} blocks\nTheirs: {theirsCount} blocks"));
                return;
            }

            var byCategory = _comparison.changes
                .GroupBy(c => c.blockCategory)
                .ToDictionary(g => g.Key, g => g.ToList());

            // Build stripped IDs set to exclude their owned secondary blocks
            var strippedIds = new HashSet<string>(
                _comparison.oursBlocks.Values
                    .Concat(_comparison.theirsBlocks.Values)
                    .Where(b => b.category == YAMLCompare.BlockCategory.Stripped)
                    .Select(b => b.fileID));

            // --- GOs + Secondary: one BlockGroup per GO, BlockItems show component header ---
            byCategory.TryGetValue(YAMLCompare.BlockCategory.GameObject, out var goChanges);
            byCategory.TryGetValue(YAMLCompare.BlockCategory.Secondary, out var secondaryChanges);
            goChanges ??= new List<YAMLCompare.ChangeInfo>();
            secondaryChanges = (secondaryChanges ?? new List<YAMLCompare.ChangeInfo>())
                .Where(c => c.parentGoID == null || !strippedIds.Contains(c.parentGoID))
                .ToList();

            var goById = goChanges.ToDictionary(c => c.blockID);
            var secondaryByGo = secondaryChanges
                .GroupBy(c => c.parentGoID ?? "")
                .ToDictionary(g => g.Key, g => g.ToList());
            var ungroupedSecondary = secondaryByGo.TryGetValue("", out var orphans)
                ? orphans : new List<YAMLCompare.ChangeInfo>();

            var allGoIds = new HashSet<string>(goChanges.Select(c => c.blockID));
            allGoIds.UnionWith(secondaryChanges
                .Where(c => !string.IsNullOrEmpty(c.parentGoID))
                .Select(c => c.parentGoID));

            foreach (var goId in allGoIds.OrderBy(id => GetGoName(id, goById)))
            {
                goById.TryGetValue(goId, out var goChange);

                secondaryByGo.TryGetValue(goId, out var components);
                if (goChange != null && goChange.changeType != YAMLCompare.ChangeType.Modified)
                {
                    // Whole GO was added/removed — skip components, show as a single flat group
                    var conflictingComponents = components?.Where(c => c.changeType == YAMLCompare.ChangeType.Conflict).ToList();
                    VisualElement note = null;
                    if (conflictingComponents?.Count > 0)
                    {
                        // Determine direction: did we delete or did they delete?
                        if (goChange.oursContent == null)
                        {
                            note = _uiBuilder.BuildDeletionConflictNoteReverse(conflictingComponents, goChange);
                        }
                        else
                        {
                            note = _uiBuilder.BuildDeletionConflictNote(conflictingComponents, goChange);
                        }
                    }
                    var group = _uiBuilder.CreateSingleBlockGroup(goChange, note);
                    if (note != null)
                    {
                        group.AddToClassList("conflict");
                        // Add stash button for the entire GameObject
                        if (!string.IsNullOrEmpty(_sceneAssetPath))
                        {
                            string stashLabel = goChange.oursContent == null ? "Stash Theirs" : "Stash Ours";
                            var stashButton = CreateStashEntityButton(goChange, stashLabel);
                            group.Add(stashButton);
                        }
                    }
                    _itemList.Add(group);
                }
                else
                {
                    _itemList.Add(_uiBuilder.CreateBlockGroup(goId, goChange, components));
                }
            }

            foreach (var change in ungroupedSecondary.OrderBy(c => c.blockName ?? c.blockType))
                _itemList.Add(_uiBuilder.CreateSingleBlockGroup(change));

            // --- PrefabInstances: one BlockGroup per prefab, no BlockHeader inside item ---
            if (byCategory.TryGetValue(YAMLCompare.BlockCategory.PrefabInstance, out var prefabChanges))
                foreach (var change in prefabChanges.OrderBy(c => c.blockName ?? c.blockType))
                    _itemList.Add(_uiBuilder.CreateSingleBlockGroup(change));

            // --- SceneSettings only (SceneRoots filtered via isSceneRoots flag) ---
            // SceneRoots (typeID 1660057539) tracks scene object ordering. It nearly always
            // changes between branches and Unity regenerates it automatically on scene import,
            // so showing it to the user is noise with no actionable value.
            if (byCategory.TryGetValue(YAMLCompare.BlockCategory.SceneSettings, out var sceneSettingsChanges))
                foreach (var change in sceneSettingsChanges.Where(c => !c.isSceneRoots).OrderBy(c => c.blockType))
                    _itemList.Add(_uiBuilder.CreateSingleBlockGroup(change));
        }

        // Helper method for getting GameObject names during grouping
        private string GetGoName(string goId, Dictionary<string, YAMLCompare.ChangeInfo> goById, YAMLCompare.ChangeInfo goChange = null)
        {
            if (goChange != null && goChange.blockName != null) return goChange.blockName;
            if (goById != null && goById.TryGetValue(goId, out var c) && c.blockName != null) return c.blockName;

            if (_comparison.oursBlocks.TryGetValue(goId, out var block) && block.name != null) return block.name;
            if (_comparison.theirsBlocks.TryGetValue(goId, out block) && block.name != null) return block.name;
            if (_comparison.baseBlocks.TryGetValue(goId, out block) && block.name != null) return block.name;

            return $"ID {goId}";
        }
        
        /// <summary>
        /// Creates a "Stash Ours/Theirs" button for deletion conflicts that stashes an entire entity.
        /// </summary>
        private UnityEngine.UIElements.Button CreateStashEntityButton(YAMLCompare.ChangeInfo change, string label)
        {
            string entityName = change.blockName ?? change.blockType;
            var button = new UnityEngine.UIElements.Button(() =>
            {
                StashEntity(change, label == "Stash Ours" ? "ours" : "theirs");
            })
            {
                text = $"{label} ({entityName})"
            };
            button.AddToClassList("stash");
            button.tooltip = $"Save the entire {change.blockType} for restoration after merge";
            return button;
        }

        /// <summary>
        /// Converts an absolute file path to a Unity-relative path (Assets/...).
        /// Returns null if the path is not within the Unity project.
        /// </summary>
        private static string GetUnityRelativePath(string absolutePath)
        {
            if (string.IsNullOrEmpty(absolutePath))
                return null;

            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string fullPath = Path.GetFullPath(absolutePath);

            if (fullPath.StartsWith(projectPath, StringComparison.OrdinalIgnoreCase))
            {
                string relativePath = Path.GetRelativePath(projectPath, fullPath);
                // Convert backslashes to forward slashes for Unity
                return relativePath.Replace('\\', '/');
            }

            return null;
        }

        /// <summary>
        /// Handles the "Fix ID Collision" button click.
        /// </summary>
        private void OnFixIDCollision(string collidingID)
        {
            if (_comparison == null)
            {
                Debug.LogError("[PullPreview] Cannot fix ID collision - no comparison available");
                return;
            }

            Debug.Log($"[PullPreview] Fixing ID collision for block {collidingID}");

            // Show progress/confirmation
            if (!EditorUtility.DisplayDialog(
                "Fix ID Collision",
                $"This will renumber block {collidingID} in your working copy (ours) to resolve the ID collision.\n\n" +
                "All references to this ID within your file will be updated automatically.\n\n" +
                "This cannot be undone except through version control. Continue?",
                "Fix It",
                "Cancel"))
            {
                return;
            }

            // Call the fix method
            bool success = _comparison.FixIDCollision(collidingID);

            if (success)
            {
                // Force Unity to reimport the modified file
                if (!string.IsNullOrEmpty(_comparison.oursPath))
                {
                    string relativePath = GetUnityRelativePath(_comparison.oursPath);
                    if (!string.IsNullOrEmpty(relativePath))
                    {
                        AssetDatabase.ImportAsset(relativePath, ImportAssetOptions.ForceUpdate);
                        Debug.Log($"[PullPreview] Reimported modified asset: {relativePath}");
                    }
                    else
                    {
                        // Fallback to full refresh if path conversion fails
                        AssetDatabase.Refresh();
                    }
                }

                // Refresh the display with the updated comparison
                RefreshDisplay();
                
                Debug.Log($"[PullPreview] ✅ ID collision fixed for block {collidingID}");
                EditorUtility.DisplayDialog(
                    "ID Collision Fixed",
                    $"Block {collidingID} has been successfully renumbered.\n\n" +
                    "The conflict has been resolved and your file has been updated.",
                    "OK");
            }
            else
            {
                Debug.LogError($"[PullPreview] Failed to fix ID collision for block {collidingID}");
                EditorUtility.DisplayDialog(
                    "Fix Failed",
                    $"Failed to fix ID collision for block {collidingID}.\n\n" +
                    "Check the Console for details.",
                    "OK");
            }
        }

        /// <summary>
        /// Stashes a property value for later application.
        /// </summary>
        private void StashProperty(YAMLCompare.ChangeInfo change, string propertyName, string value, string source)
        {
            if (string.IsNullOrEmpty(_sceneAssetPath) || string.IsNullOrEmpty(_sceneGuid))
            {
                EditorUtility.DisplayDialog("Cannot Stash", 
                    "Scene path not available. Stashing is only available when running Pre-Merge Check on a saved scene.", 
                    "OK");
                return;
            }

            var entry = new YAMLStash.StashEntry
            {
                blockId = change.blockID,
                blockType = change.blockType ?? "Unknown",
                blockName = change.blockName,
                propertyPath = propertyName,
                value = value,
                source = source
            };

            YAMLStash.AddStashEntry(_sceneAssetPath, _sceneGuid, entry);
            
            EditorUtility.DisplayDialog("Property Stashed", 
                $"Stashed {source} value for {change.blockType}.{propertyName}\n\n" +
                $"Block: {change.blockName ?? change.blockID}\n" +
                $"Value: {TruncateForDisplay(value, 60)}\n\n" +
                $"Use 'Tools > Overdrive > Scene Merge > Apply Stashes' after the merge to apply this value.",
                "OK");
        }

        /// <summary>
        /// Stashes an entire entity (component/GameObject/prefab) for later restoration.
        /// Also finds and stashes any property references to this entity in other blocks.
        /// </summary>
        private void StashEntity(YAMLCompare.ChangeInfo change, string source)
        {
            if (string.IsNullOrEmpty(_sceneAssetPath) || string.IsNullOrEmpty(_sceneGuid))
            {
                EditorUtility.DisplayDialog("Cannot Stash", 
                    "Scene path not available. Stashing is only available when running Pre-Merge Check on a saved scene.", 
                    "OK");
                return;
            }

            // Get the full YAML content for this entity
            string yamlContent = source == "ours" ? change.oursContent : change.theirsContent;
            
            if (string.IsNullOrEmpty(yamlContent))
            {
                EditorUtility.DisplayDialog("Cannot Stash", 
                    $"No {source} content available for this entity.", 
                    "OK");
                return;
            }

            // Create a special stash entry for the entire entity
            var entry = new YAMLStash.StashEntry
            {
                blockId = change.blockID,
                blockType = change.blockType ?? "Unknown",
                blockName = change.blockName,
                propertyPath = "__FULL_ENTITY__",  // Special marker for entity-level stash
                value = yamlContent,
                source = source
            };

            YAMLStash.AddStashEntry(_sceneAssetPath, _sceneGuid, entry);
            
            // Now find and stash any references to this entity in the current scene
            int referencesStashed = StashReferencesToEntity(change.blockID, source);
            
            string referencesMessage = referencesStashed > 0 
                ? $"\n\n✓ Also stashed {referencesStashed} property reference(s) to this entity."
                : "";
            
            EditorUtility.DisplayDialog("Entity Stashed", 
                $"Stashed {source} {change.blockType}\n\n" +
                $"Block: {change.blockName ?? change.blockID}\n" +
                $"ID: {change.blockID}\n\n" +
                $"The entire {change.blockType} will be restored after the merge.{referencesMessage}\n\n" +
                $"Use 'Tools > Overdrive > Scene Merge > Apply Stashes' after the merge to apply it.",
                "OK");
        }

        /// <summary>
        /// Finds and stashes all property references to a specific entity fileID.
        /// Returns the number of references stashed.
        /// </summary>
        private int StashReferencesToEntity(string entityFileId, string source)
        {
            if (_comparison == null || string.IsNullOrEmpty(_comparison.oursPath))
                return 0;

            try
            {
                // Read the current scene content to find references
                string sceneContent = File.ReadAllText(_comparison.oursPath);
                
                // Find all references to this entity
                var references = YAMLStash.FindReferencesToEntity(sceneContent, entityFileId);
                
                if (references.Count == 0)
                {
                    Debug.Log($"No references found to entity {entityFileId}");
                    return 0;
                }
                
                // Stash each reference
                foreach (var (blockId, blockType, blockName, propertyPath, value) in references)
                {
                    // Skip if this is the entity itself
                    if (blockId == entityFileId)
                        continue;
                    
                    // Special case: if this is a component's m_GameObject property, we need to stash
                    // the entire component block, not just the property reference
                    if (propertyPath == "m_GameObject")
                    {
                        // This is a component owned by the GameObject - stash the full component
                        var sourceBlocks = source == "ours" ? _comparison.oursBlocks : _comparison.theirsBlocks;
                        if (sourceBlocks.TryGetValue(blockId, out var componentBlock))
                        {
                            var componentEntry = new YAMLStash.StashEntry
                            {
                                blockId = blockId,
                                blockType = blockType,
                                blockName = blockName,
                                propertyPath = "__FULL_ENTITY__",  // Store as full entity
                                value = componentBlock.fullContent,
                                source = source,
                                isDependentReference = true,
                                referencedEntityId = entityFileId
                            };
                            
                            YAMLStash.AddStashEntry(_sceneAssetPath, _sceneGuid, componentEntry);
                            Debug.Log($"  → Stashed full {blockType} component (owned by GameObject)");
                        }
                    }
                    else
                    {
                        // This is a regular property reference - stash just the property
                        var refEntry = new YAMLStash.StashEntry
                        {
                            blockId = blockId,
                            blockType = blockType,
                            blockName = blockName,
                            propertyPath = propertyPath,
                            value = value,
                            source = source,
                            isDependentReference = true,
                            referencedEntityId = entityFileId
                        };
                        
                        YAMLStash.AddStashEntry(_sceneAssetPath, _sceneGuid, refEntry);
                        Debug.Log($"  → Stashed property reference {blockType}.{propertyPath}");
                    }
                }
                
                Debug.Log($"Stashed {references.Count} reference(s) to entity {entityFileId}");
                return references.Count;
            }
            catch (Exception ex)
            {
                Debug.LogError($"Failed to find/stash references to entity {entityFileId}: {ex.Message}");
                return 0;
            }
        }

        private string TruncateForDisplay(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return "(empty)";
            if (value.Length <= maxLength) return value;
            return value.Substring(0, maxLength) + "...";
        }
    }
}
