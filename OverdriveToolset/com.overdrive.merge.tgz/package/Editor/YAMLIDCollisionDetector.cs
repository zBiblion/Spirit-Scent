using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Detects and fixes critical ID collisions in Unity YAML files.
    /// An ID collision occurs when the same fileID is used for different component types
    /// in two versions - this will crash Unity's merge tool and must be fixed before merging.
    /// </summary>
    public class YAMLIDCollisionDetector
    {
        // Compiled regex patterns for YAML parsing
        private static readonly Regex BlockSplitRegex  = new(@"(?=^--- !u!)", RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex BlockHeaderRegex = new(@"^--- !u!(\d+) &(\d+)(.*)", RegexOptions.Compiled);
        private static readonly Regex ObjectTypeRegex  = new(@"^--- !u!\d+ &\d+.*\n(\w+):", RegexOptions.Compiled | RegexOptions.Multiline);

        /// <summary>
        /// Represents a critical ID collision that must be fixed before merging.
        /// </summary>
        public class IDCollision
        {
            public string fileID;           // The colliding file ID
            public string oursTypeID;       // Our ClassID/typeID
            public string theirsTypeID;     // Their ClassID/typeID
            public string oursObjectType;   // Our object type name
            public string theirsObjectType; // Their object type name
        }

        /// <summary>
        /// Lightweight header-only block info for fast collision detection.
        /// </summary>
        private class BlockHeader
        {
            public string typeID;
            public string objectType;
        }

        /// <summary>
        /// Detect ID collisions between three YAML files.
        /// Returns list of all detected collisions (empty if none found).
        /// </summary>
        public static List<IDCollision> DetectCollisions(string basePath, string oursPath, string theirsPath)
        {
            var collisions = new List<IDCollision>();

            // Fast parse - just extract headers (typeID + fileID) without full block parsing
            string baseContent   = File.ReadAllText(basePath);
            string oursContent   = File.ReadAllText(oursPath);
            string theirsContent = File.ReadAllText(theirsPath);

            var baseHeaders   = ParseBlockHeaders(baseContent);
            var oursHeaders   = ParseBlockHeaders(oursContent);
            var theirsHeaders = ParseBlockHeaders(theirsContent);

            // Check for collisions: same fileID, different typeID, not in base (both sides added independently)
            foreach (var kvp in oursHeaders)
            {
                string fileID = kvp.Key;
                if (theirsHeaders.TryGetValue(fileID, out var theirsHeader))
                {
                    bool inBase = baseHeaders.ContainsKey(fileID);

                    if (!inBase && kvp.Value.typeID != theirsHeader.typeID)
                    {
                        // CRITICAL: Same fileID used for different component types
                        collisions.Add(new IDCollision
                        {
                            fileID = fileID,
                            oursTypeID = kvp.Value.typeID,
                            theirsTypeID = theirsHeader.typeID,
                            oursObjectType = kvp.Value.objectType,
                            theirsObjectType = theirsHeader.objectType
                        });

                        Debug.LogError($"[YAMLIDCollisionDetector] ID COLLISION: Block {fileID} has different ClassIDs - " +
                                     $"Ours: {kvp.Value.typeID} ({kvp.Value.objectType}), " +
                                     $"Theirs: {theirsHeader.typeID} ({theirsHeader.objectType})");
                    }
                }
            }

            return collisions;
        }

        /// <summary>
        /// Fix all ID collisions by renumbering the conflicting blocks in OURS file.
        /// Updates both block headers and all references throughout the file.
        /// Returns true if all collisions were successfully fixed.
        /// </summary>
        public static bool FixAllCollisions(List<IDCollision> collisions, string basePath, string oursPath, string theirsPath)
        {
            if (collisions == null || collisions.Count == 0)
            {
                Debug.LogWarning("[YAMLIDCollisionDetector] No ID collisions to fix");
                return true;
            }

            try
            {
                // Get all existing IDs from all versions to ensure uniqueness
                var allExistingIds = new HashSet<string>();

                // Parse headers to get all IDs
                string baseContent   = File.ReadAllText(basePath);
                string oursContent   = File.ReadAllText(oursPath);
                string theirsContent = File.ReadAllText(theirsPath);

                var baseHeaders   = ParseBlockHeaders(baseContent);
                var oursHeaders   = ParseBlockHeaders(oursContent);
                var theirsHeaders = ParseBlockHeaders(theirsContent);

                allExistingIds.UnionWith(baseHeaders.Keys);
                allExistingIds.UnionWith(oursHeaders.Keys);
                allExistingIds.UnionWith(theirsHeaders.Keys);

                // Fix each collision by renumbering in ours
                foreach (var collision in collisions)
                {
                    // Generate new unique ID
                    string newID = GenerateUniqueID(allExistingIds);
                    Debug.Log($"[YAMLIDCollisionDetector] Fixing ID collision: {collision.fileID} → {newID}");

                    // Replace the block header: --- !u!XXX &OLDID  →  --- !u!XXX &NEWID
                    oursContent = Regex.Replace(oursContent,
                        $@"^(--- !u!\d+) &{collision.fileID}\b",
                        $"$1 &{newID}",
                        RegexOptions.Multiline);

                    // Replace all fileID references in any format:
                    // - Simple: {fileID: OLDID}
                    // - With guid: {fileID: OLDID, guid: abc, type: 3}
                    // - In arrays: - {fileID: OLDID}
                    // - In modifications: target: {fileID: OLDID, ...}
                    // Pattern captures "fileID: " and replaces just the ID number, preserving everything after
                    oursContent = Regex.Replace(oursContent,
                        $@"(fileID:\s*){collision.fileID}\b",
                        $"${{1}}{newID}");

                    // Add new ID to the set to avoid collision with next fix
                    allExistingIds.Add(newID);
                }

                // Write back to ours file
                File.WriteAllText(oursPath, oursContent);

                Debug.Log($"[YAMLIDCollisionDetector] ✅ Fixed {collisions.Count} ID collision(s)");
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[YAMLIDCollisionDetector] Failed to fix ID collisions: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Lightweight header-only parsing for fast ID collision detection.
        /// Returns fileID -> (typeID, objectType) mapping without parsing full block content.
        /// </summary>
        private static Dictionary<string, BlockHeader> ParseBlockHeaders(string yamlContent)
        {
            var headers = new Dictionary<string, BlockHeader>();
            var documents = BlockSplitRegex.Split(yamlContent);

            foreach (var doc in documents)
            {
                if (string.IsNullOrWhiteSpace(doc)) continue;

                // Match: --- !u!TYPE_ID &FILE_ID
                var headerMatch = BlockHeaderRegex.Match(doc);
                if (!headerMatch.Success) continue;

                string typeID = headerMatch.Groups[1].Value;
                string fileID = headerMatch.Groups[2].Value;

                // Get the object type from the next line
                var typeLineMatch = ObjectTypeRegex.Match(doc);
                string objectType = typeLineMatch.Success ? typeLineMatch.Groups[1].Value : $"Type{typeID}";

                headers[fileID] = new BlockHeader
                {
                    typeID = typeID,
                    objectType = objectType
                };
            }

            return headers;
        }

        /// <summary>
        /// Generates a unique ID that doesn't exist in the provided set.
        /// Uses Unity's typical ID format (positive 32-bit integers).
        /// </summary>
        private static string GenerateUniqueID(HashSet<string> existingIds)
        {
            var random = new System.Random();
            string newId;
            int attempts = 0;
            const int maxAttempts = 1000;

            do
            {
                // Generate random positive 32-bit integer (Unity's format)
                newId = random.Next(10000000, int.MaxValue).ToString();
                attempts++;

                if (attempts > maxAttempts)
                {
                    Debug.LogError($"[YAMLIDCollisionDetector] Failed to generate unique ID after {maxAttempts} attempts");
                    return random.Next(10000000, int.MaxValue).ToString(); // Return anyway
                }
            } while (existingIds.Contains(newId));

            return newId;
        }
    }
}
