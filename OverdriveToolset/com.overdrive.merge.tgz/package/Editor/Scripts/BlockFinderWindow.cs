using UnityEngine;
using UnityEditor;
using UnityEditor.Search;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Debug window for finding GameObjects in the hierarchy by block ID.
    /// Uses progressive search with increasing specificity to locate objects,
    /// optimized for large scenes (100k+ objects) using Unity's Search API.
    /// </summary>
    public class BlockFinderWindow : EditorWindow
    {
        private string blockId = "";
        private Vector2 scrollPosition;
        private SearchResult lastSearchResult;
        private GameObject testPrefab;

        [MenuItem("Overdrive/Block Finder (Debug)")]
        public static void ShowWindow()
        {
            GetWindow<BlockFinderWindow>("Block Finder");
        }

        private void OnGUI()
        {
            EditorGUILayout.LabelField("Find GameObject by Block ID", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            EditorGUILayout.HelpBox(
                "Enter a Unity file ID (block ID) to locate the corresponding GameObject in the active scene. " +
                "This tool searches through scene data and uses progressive search for accuracy.",
                MessageType.Info);

            EditorGUILayout.Space();

            // Input field
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Block ID:", GUILayout.Width(70));
            blockId = EditorGUILayout.TextField(blockId);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();

            // Search button
            if (GUILayout.Button("Find in Hierarchy", GUILayout.Height(30)))
            {
                PerformSearch();
            }

            EditorGUILayout.Space();

            // Test data generation
            EditorGUILayout.LabelField("Test Utilities", EditorStyles.boldLabel);

            testPrefab = (GameObject)EditorGUILayout.ObjectField("Test Prefab (Optional)", testPrefab, typeof(GameObject), false);
            EditorGUILayout.HelpBox(
                "Assign a prefab to create 1000 instances mixed with 1000 empty GameObjects (2000 total).\n" +
                "Leave empty to create only empty GameObjects.",
                MessageType.Info);

            if (GUILayout.Button("Generate 1000 Random Test Objects"))
            {
                GenerateTestObjects(1000);
            }

            EditorGUILayout.Space();

            // Display results
            if (lastSearchResult != null)
            {
                scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
                DisplaySearchResult(lastSearchResult);
                EditorGUILayout.EndScrollView();
            }
        }

        private void PerformSearch()
        {
            if (string.IsNullOrWhiteSpace(blockId))
            {
                lastSearchResult = new SearchResult
                {
                    Success = false,
                    Message = "Please enter a block ID"
                };
                return;
            }

            var activeScene = SceneManager.GetActiveScene();
            if (!activeScene.IsValid())
            {
                lastSearchResult = new SearchResult
                {
                    Success = false,
                    Message = "No active scene loaded"
                };
                return;
            }

            string scenePath = activeScene.path;
            if (string.IsNullOrEmpty(scenePath))
            {
                lastSearchResult = new SearchResult
                {
                    Success = false,
                    Message = "Active scene is not saved. Please save the scene first."
                };
                return;
            }

            // Read and parse the scene file
            string sceneText = File.ReadAllText(scenePath);
            var blocks = BlockComparison.BlockParser.ParseBlocks(sceneText);

            // Create reference dictionary for block hopping
            var allBlocksRef = blocks.ToDictionary(b => b.Id);
            BlockComparison.Block.AllBlocksReference = allBlocksRef;

            // Re-extract metadata with references available
            foreach (var block in blocks)
                block.ExtractMetadata();

            // Find the target block
            var targetBlock = blocks.FirstOrDefault(b => b.Id == blockId);
            if (targetBlock == null)
            {
                lastSearchResult = new SearchResult
                {
                    Success = false,
                    Message = $"Block ID '{blockId}' not found in scene file '{scenePath}'"
                };
                return;
            }

            // Process the block
            ProcessBlock(targetBlock, allBlocksRef, activeScene);
        }

        private void ProcessBlock(BlockComparison.Block block, Dictionary<string, BlockComparison.Block> allBlocks, Scene scene)
        {
            string blockType = block.BlockType;

            // Determine if we need to navigate to parent GameObject
            BlockComparison.Block targetBlock = block;
            string searchContext = "";

            // Check block type
            if (blockType == "GameObject")
            {
                searchContext = "Searching for GameObject directly";
            }
            else if (blockType == "PrefabInstance")
            {
                searchContext = "Searching for PrefabInstance (top-level)";
            }
            else if (blockType == "Transform" || blockType == "RectTransform")
            {
                // Transform components belong to GameObjects, find parent GO
                var goId = GetGOIdForBlock(block);
                if (goId != null && allBlocks.TryGetValue(goId, out var goBlock))
                {
                    targetBlock = goBlock;
                    searchContext = $"Component detected ({blockType}), searching for parent GameObject (ID: {goId})";
                }
                else
                {
                    lastSearchResult = new SearchResult
                    {
                        Success = false,
                        Message = $"Could not find parent GameObject for {blockType} component (Block ID: {block.Id})"
                    };
                    return;
                }
            }
            else
            {
                // Generic component - find parent GameObject
                var goId = GetGOIdForBlock(block);
                if (goId != null && allBlocks.TryGetValue(goId, out var goBlock))
                {
                    targetBlock = goBlock;
                    searchContext = $"Component detected ({blockType}), searching for parent GameObject (ID: {goId})";
                }
                else
                {
                    lastSearchResult = new SearchResult
                    {
                        Success = false,
                        Message = $"Could not find parent GameObject for component '{blockType}' (Block ID: {block.Id}). " +
                                  "This might be a stripped block or orphaned component."
                    };
                    return;
                }
            }

            // Now search for the target block in the hierarchy
            SearchInHierarchy(targetBlock, scene, searchContext);
        }

        private void SearchInHierarchy(BlockComparison.Block targetBlock, Scene scene, string context)
        {
            var candidates = new List<GameObject>();

            Debug.Log($"[BlockFinder] Searching through scene for block '{targetBlock.Id}' (Type: {targetBlock.BlockType}, Name: '{targetBlock.SourceName}')");

            // Progressive search with increasing specificity using Search API

            // STEP 1: Search by name using Search API (only for GameObjects, not reliable for prefabs)
            if (targetBlock.BlockType == "GameObject" && !string.IsNullOrEmpty(targetBlock.SourceName))
            {
                candidates = SearchByName(targetBlock.SourceName, scene);

                if (candidates.Count == 1)
                {
                    lastSearchResult = new SearchResult
                    {
                        Success = true,
                        Message = $"{context}\n\nFound by name match using Search API!",
                        FoundObject = candidates[0],
                        BlockInfo = targetBlock,
                        SearchMethod = "Search API (Name)"
                    };
                    SelectAndPingObject(candidates[0]);
                    return;
                }

                if (candidates.Count > 1)
                {
                    Debug.Log($"[BlockFinder] Name search found {candidates.Count} candidates, proceeding to transform comparison");
                }
            }

            // STEP 2: Get all scene objects for transform-based search
            // (Search API doesn't support custom transform queries, so we use manual filtering)
            var allObjects = GetAllSceneObjects(scene);

            // If we didn't get candidates from name search, use all objects
            var searchPool = candidates.Count > 0 ? candidates : allObjects;

            // STEP 3: Search by transform properties (position, rotation, scale)
            var transformCandidates = FilterByTransform(searchPool, targetBlock);

            if (transformCandidates.Count == 1)
            {
                lastSearchResult = new SearchResult
                {
                    Success = true,
                    Message = $"{context}\n\nFound by transform data match!",
                    FoundObject = transformCandidates[0],
                    BlockInfo = targetBlock,
                    SearchMethod = "Transform Data"
                };
                SelectAndPingObject(transformCandidates[0]);
                return;
            }

            if (transformCandidates.Count > 1)
            {
                // STEP 4: Use candidates list for further refinement
                candidates = transformCandidates;

                // Try to filter by name within transform matches
                if (!string.IsNullOrEmpty(targetBlock.SourceName))
                {
                    var nameFiltered = candidates.Where(go => go.name == targetBlock.SourceName).ToList();
                    if (nameFiltered.Count == 1)
                    {
                        lastSearchResult = new SearchResult
                        {
                            Success = true,
                            Message = $"{context}\n\nFound by transform + name match!",
                            FoundObject = nameFiltered[0],
                            BlockInfo = targetBlock,
                            SearchMethod = "Transform + Name"
                        };
                        SelectAndPingObject(nameFiltered[0]);
                        return;
                    }

                    if (nameFiltered.Count > 0)
                        candidates = nameFiltered;
                }

                // STEP 5: Additional filtering by components/hierarchy
                // (Could add more sophisticated matching here)

                // Multiple matches found
                lastSearchResult = new SearchResult
                {
                    Success = false,
                    Message = $"{context}\n\nFound {candidates.Count} potential matches. Unable to determine unique object.\n\n" +
                              $"Matches:\n{string.Join("\n", candidates.Select(c => GetHierarchyPath(c)))}",
                    BlockInfo = targetBlock,
                    SearchMethod = "Multiple Matches"
                };
                return;
            }

            // No matches found
            lastSearchResult = new SearchResult
            {
                Success = false,
                Message = $"{context}\n\nNo matching GameObject found in the hierarchy.\n\n" +
                          $"Looking for: {targetBlock.BlockType} '{targetBlock.SourceName}' (Block ID: {targetBlock.Id})",
                BlockInfo = targetBlock,
                SearchMethod = "None"
            };
        }

        private List<GameObject> SearchByName(string objectName, Scene scene)
        {
            var results = new List<GameObject>();

            // Use Search API to find objects by name in the scene
            // Query format: "h: name" where h: is the hierarchy provider
            var searchContext = SearchService.CreateContext("scene", $"{objectName}");

            var items = SearchService.GetItems(searchContext);
            foreach (var item in items)
            {
                var obj = item.ToObject<GameObject>();
                if (obj != null && obj.scene == scene && obj.name == objectName)
                {
                    results.Add(obj);
                }
            }

            searchContext.Dispose();

            Debug.Log($"[BlockFinder] Search API found {results.Count} objects with name '{objectName}'");
            return results;
        }

        private List<GameObject> GetAllSceneObjects(Scene scene)
        {
            var allObjects = new List<GameObject>();
            var rootObjects = scene.GetRootGameObjects();

            foreach (var root in rootObjects)
            {
                allObjects.Add(root);
                allObjects.AddRange(root.GetComponentsInChildren<Transform>(true).Select(t => t.gameObject));
            }

            Debug.Log($"[BlockFinder] Scene contains {allObjects.Count} total objects");
            return allObjects;
        }

        private List<GameObject> FilterByTransform(List<GameObject> objects, BlockComparison.Block block)
        {
            // Extract transform data from block
            var position = ExtractVector3(block.Content, "m_LocalPosition");
            var rotation = ExtractQuaternion(block.Content, "m_LocalRotation");
            var scale = ExtractVector3(block.Content, "m_LocalScale");

            var matches = new List<GameObject>();

            foreach (var obj in objects)
            {
                var transform = obj.transform;
                bool positionMatch = !position.HasValue || Vector3.Distance(transform.localPosition, position.Value) < 0.0001f;
                bool rotationMatch = !rotation.HasValue || Quaternion.Angle(transform.localRotation, rotation.Value) < 0.001f;
                bool scaleMatch = !scale.HasValue || Vector3.Distance(transform.localScale, scale.Value) < 0.0001f;

                if (positionMatch && rotationMatch && scaleMatch)
                {
                    matches.Add(obj);
                }
            }

            return matches;
        }

        private Vector3? ExtractVector3(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*\{{x:\s*([-\d.]+),\s*y:\s*([-\d.]+),\s*z:\s*([-\d.]+)\}}");
            if (match.Success)
            {
                return new Vector3(
                    float.Parse(match.Groups[1].Value),
                    float.Parse(match.Groups[2].Value),
                    float.Parse(match.Groups[3].Value)
                );
            }
            return null;
        }

        private Quaternion? ExtractQuaternion(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*\{{x:\s*([-\d.]+),\s*y:\s*([-\d.]+),\s*z:\s*([-\d.]+),\s*w:\s*([-\d.]+)\}}");
            if (match.Success)
            {
                return new Quaternion(
                    float.Parse(match.Groups[1].Value),
                    float.Parse(match.Groups[2].Value),
                    float.Parse(match.Groups[3].Value),
                    float.Parse(match.Groups[4].Value)
                );
            }
            return null;
        }

        private string GetGOIdForBlock(BlockComparison.Block block)
        {
            var match = Regex.Match(block.Content, @"m_GameObject:\s*\{fileID:\s*(\d+)\}");
            return match.Success ? match.Groups[1].Value : null;
        }

        private string GetHierarchyPath(GameObject obj)
        {
            string path = obj.name;
            Transform parent = obj.transform.parent;
            while (parent != null)
            {
                path = parent.name + "/" + path;
                parent = parent.parent;
            }
            return path;
        }

        private void SelectAndPingObject(GameObject obj)
        {
            Selection.activeGameObject = obj;
            EditorGUIUtility.PingObject(obj);
            Debug.Log($"[BlockFinder] Selected: {GetHierarchyPath(obj)}");
        }

        private void GenerateTestObjects(int count)
        {
            var activeScene = SceneManager.GetActiveScene();
            if (!activeScene.IsValid())
            {
                EditorUtility.DisplayDialog("Error", "No active scene loaded", "OK");
                return;
            }

            bool hasPrefab = testPrefab != null;
            int totalObjects = hasPrefab ? count * 2 : count;
            string message = hasPrefab
                ? $"This will create {count} empty GameObjects + {count} prefab instances ({totalObjects} total) with random positions and names in the active scene.\n\nContinue?"
                : $"This will create {count} empty GameObjects with random positions and names in the active scene.\n\nContinue?";

            if (!EditorUtility.DisplayDialog("Generate Test Objects", message, "Yes", "Cancel"))
            {
                return;
            }

            // Create a parent object to hold all test objects
            GameObject parent = new GameObject($"TestObjects_{System.DateTime.Now:yyyyMMdd_HHmmss}");
            Undo.RegisterCreatedObjectUndo(parent, "Generate Test Objects");

            var random = new System.Random();
            string[] prefixes = { "Test", "Debug", "Sample", "Object", "Node", "Item", "Entity", "Element" };

            int createdCount = 0;

            // Create empty GameObjects
            for (int i = 0; i < count; i++)
            {
                // Generate random name
                string prefix = prefixes[random.Next(prefixes.Length)];
                string name = $"{prefix}_{i:D4}_{random.Next(1000, 9999)}";

                // Create GameObject
                GameObject go = new GameObject(name);
                go.transform.SetParent(parent.transform);

                // Random position (spread across a large area)
                float x = (float)(random.NextDouble() * 200 - 100); // -100 to 100
                float y = (float)(random.NextDouble() * 200 - 100);
                float z = (float)(random.NextDouble() * 200 - 100);
                go.transform.localPosition = new Vector3(x, y, z);

                // Random rotation
                float rotX = (float)(random.NextDouble() * 360);
                float rotY = (float)(random.NextDouble() * 360);
                float rotZ = (float)(random.NextDouble() * 360);
                go.transform.localRotation = Quaternion.Euler(rotX, rotY, rotZ);

                // Random scale (between 0.5 and 2.0)
                float scale = (float)(random.NextDouble() * 1.5 + 0.5);
                go.transform.localScale = Vector3.one * scale;

                Undo.RegisterCreatedObjectUndo(go, "Generate Test Objects");
                createdCount++;
            }

            // Create prefab instances if prefab is assigned
            if (hasPrefab)
            {
                for (int i = 0; i < count; i++)
                {
                    // Instantiate prefab
                    GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(testPrefab);
                    instance.transform.SetParent(parent.transform);

                    // Generate random name with "Prefab" prefix
                    string name = $"Prefab_{i:D4}_{random.Next(1000, 9999)}";
                    instance.name = name;

                    // Random position (spread across a large area)
                    float x = (float)(random.NextDouble() * 200 - 100); // -100 to 100
                    float y = (float)(random.NextDouble() * 200 - 100);
                    float z = (float)(random.NextDouble() * 200 - 100);
                    instance.transform.localPosition = new Vector3(x, y, z);

                    // Random rotation
                    float rotX = (float)(random.NextDouble() * 360);
                    float rotY = (float)(random.NextDouble() * 360);
                    float rotZ = (float)(random.NextDouble() * 360);
                    instance.transform.localRotation = Quaternion.Euler(rotX, rotY, rotZ);

                    // Random scale (between 0.5 and 2.0)
                    float scale = (float)(random.NextDouble() * 1.5 + 0.5);
                    instance.transform.localScale = Vector3.one * scale;

                    Undo.RegisterCreatedObjectUndo(instance, "Generate Test Objects");
                    createdCount++;
                }
            }

            EditorUtility.SetDirty(parent);
            Debug.Log($"[BlockFinder] Generated {createdCount} test objects under '{parent.name}'");
            EditorUtility.DisplayDialog("Success", $"Created {createdCount} test objects under '{parent.name}'", "OK");
        }

        private void DisplaySearchResult(SearchResult result)
        {
            if (result.Success)
            {
                EditorGUILayout.HelpBox("✓ GameObject Found!", MessageType.Info);

                EditorGUILayout.LabelField("Search Method:", result.SearchMethod, EditorStyles.boldLabel);
                EditorGUILayout.Space();

                if (result.FoundObject != null)
                {
                    EditorGUILayout.LabelField("Object:", EditorStyles.boldLabel);
                    EditorGUI.indentLevel++;
                    EditorGUILayout.ObjectField("GameObject", result.FoundObject, typeof(GameObject), true);
                    EditorGUILayout.LabelField("Path:", GetHierarchyPath(result.FoundObject));
                    EditorGUI.indentLevel--;

                    EditorGUILayout.Space();

                    if (GUILayout.Button("Select in Hierarchy"))
                    {
                        SelectAndPingObject(result.FoundObject);
                    }
                }
            }
            else
            {
                EditorGUILayout.HelpBox("✗ Search Failed", MessageType.Warning);
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Details:", EditorStyles.boldLabel);
            EditorGUILayout.TextArea(result.Message, GUILayout.MinHeight(100));

            if (result.BlockInfo != null)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Block Information:", EditorStyles.boldLabel);
                EditorGUI.indentLevel++;
                EditorGUILayout.LabelField("Block ID:", result.BlockInfo.Id);
                EditorGUILayout.LabelField("Block Type:", result.BlockInfo.BlockType);
                EditorGUILayout.LabelField("Source Name:", result.BlockInfo.SourceName ?? "(none)");
                EditorGUI.indentLevel--;
            }
        }

        private class SearchResult
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public GameObject FoundObject { get; set; }
            public BlockComparison.Block BlockInfo { get; set; }
            public string SearchMethod { get; set; }
        }
    }
}
