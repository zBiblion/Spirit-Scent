using UnityEditor;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;

namespace Overdrive.Editor.Merge
{
    /*
    - Get all ID blocks from the three files
    - For Ours, determine which blocks changed vs Base
    - For Theirs, determine which blocks changed vs Base
    - Compare these block sets, and find any that have overlap
    - Show a Block Conflict item for each of these
    */

    public enum ConflictAction { Modified, Deleted }

    public enum ConflictType
    {
        BothModifiedGOProperty,      // Both changed a GameObject property (ours wins)
        BothModifiedPrefabProperty,  // Both changed a PrefabInstance property (theirs wins)
        ItemDeletedSimple,           // Item deleted by theirs, we modified it (their deletion wins)
        WeDeletedTheyModified,       // Item deleted by us, they modified it (our deletion wins)
    }

    public static class ConflictDefinitions
    {
        public enum WinSide { Ours, Theirs, Neither }

        public class ConflictInfo
        {
            public string DisplayName { get; set; }
            public string Resolution { get; set; }
            public string CssClass { get; set; }
            public WinSide Winner { get; set; }
            public bool ShowActionButtons { get; set; }
        }

        private static readonly Dictionary<ConflictType, ConflictInfo> definitions = new()
        {
            {
                ConflictType.BothModifiedGOProperty,
                new ConflictInfo
                {
                    DisplayName = "Both Modified",
                    Resolution = "Your change will overwrite their change",
                    CssClass = "conflict-type-GO-property",
                    Winner = WinSide.Ours,
                    ShowActionButtons = true
                }
            },
            {
                ConflictType.BothModifiedPrefabProperty,
                new ConflictInfo
                {
                    DisplayName = "Both Modified",
                    Resolution = "Their change will overwrite your change",
                    CssClass = "conflict-type-Prefab-property",
                    Winner = WinSide.Theirs,
                    ShowActionButtons = true
                }
            },
            {
                ConflictType.ItemDeletedSimple,
                new ConflictInfo
                {
                    DisplayName = "Item Deleted",
                    Resolution = "This item was deleted. Your modifications will be lost.",
                    CssClass = "conflict-type-delete",
                    Winner = WinSide.Neither,
                    ShowActionButtons = true  // Show "Stash Yours" and "Apply Theirs"
                }
            },
            {
                ConflictType.WeDeletedTheyModified,
                new ConflictInfo
                {
                    DisplayName = "Item Deleted",
                    Resolution = "You deleted this item. Their modifications will be lost.",
                    CssClass = "conflict-type-delete",
                    Winner = WinSide.Neither,
                    ShowActionButtons = true  // Show only "Apply Theirs" (no stash)
                }
            }
        };

        public static ConflictInfo GetInfo(ConflictType type)
        {
            return definitions.TryGetValue(type, out var info) ? info : new ConflictInfo { DisplayName = "Unknown", Resolution = "Unknown", CssClass = "conflict-type-GO-property", Winner = WinSide.Neither, ShowActionButtons = false };
        }
    }

    /// <summary>
    /// Represents a merge conflict between two versions of a Unity scene or prefab.
    /// Different conflict types use different subsets of fields (see field documentation).
    /// </summary>
    public class Conflict
    {
        // --- Common fields (used by all conflict types) ---

        /// <summary>Unity file ID of the conflicting block.</summary>
        public string BlockId { get; set; }

        /// <summary>Type of Unity object (GameObject, Transform, PrefabInstance, etc.).</summary>
        public string BlockType { get; set; }

        /// <summary>Display name for the conflicting item (GameObject name, prefab name, etc.).</summary>
        public string SourceName { get; set; }

        /// <summary>Property or item that has a conflict.</summary>
        public string PropertyName { get; set; }

        /// <summary>What action was taken on our side.</summary>
        public ConflictAction OurAction { get; set; }

        /// <summary>What action was taken on their side.</summary>
        public ConflictAction TheirAction { get; set; }

        /// <summary>Type of conflict (determines resolution strategy).</summary>
        public ConflictType Type { get; set; }

        /// <summary>Human-readable description of how this conflict will be resolved.</summary>
        public string Resolution { get; set; }

        // --- Both-modified conflict fields ---

        /// <summary>Our value for the modified property. Used by: BothModifiedGOProperty, BothModifiedPrefabProperty.</summary>
        public string OurValue { get; set; }

        /// <summary>Their value for the modified property. Used by: BothModifiedGOProperty, BothModifiedPrefabProperty.</summary>
        public string TheirValue { get; set; }

        /// <summary>For PrefabInstance modifications: the internal fileID of the target component. Used by: BothModifiedPrefabProperty.</summary>
        public string TargetFileId { get; set; }

        // --- Deletion conflict fields ---

        /// <summary>List of modified properties/items that will be lost due to deletion. Used by: ItemDeletedSimple, WeDeletedTheyModified.</summary>
        public List<string> ModifiedItems { get; set; }

        /// <summary>Number of modifications that will be lost. Used by: ItemDeletedSimple, WeDeletedTheyModified.</summary>
        public int ModificationCount { get; set; }
    }

    public class BlockComparison
    {
        // Store the last found conflicts for the editor window
        public static List<Conflict> lastConflicts = new();

        public const string BasePath   = "Assets/Merge Test Scenes/base.unity";
        public const string OursPath   = "Assets/Merge Test Scenes/ours.unity";
        public const string TheirsPath = "Assets/Merge Test Scenes/theirs.unity";

        // Analyze conflicts at property level with detailed information
        [MenuItem("Overdrive/Merge Test Scenes/Debug Block Comparison")]
        public static void DebugBlockComparison() =>
            DebugBlockComparison(BasePath, OursPath, TheirsPath);

        public static void DebugBlockComparison(string basePath, string oursPath, string theirsPath)
        {
            // Get all ID blocks from the three files
            var baseBlocks = BlockParser.ParseBlocks(File.ReadAllText(basePath));
            var ourBlocks = BlockParser.ParseBlocks(File.ReadAllText(oursPath));
            var theirBlocks = BlockParser.ParseBlocks(File.ReadAllText(theirsPath));

            // Create dictionaries for quick lookup
            var baseBlockDict = baseBlocks.ToDictionary(b => b.Id);
            var ourBlockDict = ourBlocks.ToDictionary(b => b.Id);
            var theirBlockDict = theirBlocks.ToDictionary(b => b.Id);

            var allBlocksRef = new Dictionary<string, Block>();
            foreach (var block in baseBlocks.Concat(ourBlocks).Concat(theirBlocks))
            {
                if (!allBlocksRef.ContainsKey(block.Id))
                    allBlocksRef[block.Id] = block;
            }
            Block.AllBlocksReference = allBlocksRef;

            // Re-extract metadata with references available on all block instances
            foreach (var block in baseBlocks.Concat(ourBlocks).Concat(theirBlocks))
                block.ExtractMetadata();

            // Find blocks with conflicts
            var ourChangedBlocks = GetChangedBlocks(ourBlocks, baseBlocks);
            var theirChangedBlocks = GetChangedBlocks(theirBlocks, baseBlocks);
            var conflictingBlockIds = new HashSet<string>(ourChangedBlocks);
            conflictingBlockIds.IntersectWith(theirChangedBlocks);

            // Generate conflicts
            lastConflicts.Clear();

            // Both-modified conflicts
            foreach (var blockId in conflictingBlockIds)
            {
                var baseBlock = baseBlockDict.TryGetValue(blockId, out var bb) ? bb : null;
                var ourBlock = ourBlockDict.TryGetValue(blockId, out var ob) ? ob : null;
                var theirBlock = theirBlockDict.TryGetValue(blockId, out var tb) ? tb : null;

                // Generate conflicts for this block
                var conflicts = GeneratePropertyConflicts(blockId, baseBlock, ourBlock, theirBlock);
                lastConflicts.AddRange(conflicts);
            }

            // Deletion conflicts
            var deletionConflicts = DetectDeletionConflicts(
                baseBlockDict,
                ourBlockDict,
                theirBlockDict,
                ourChangedBlocks,
                theirChangedBlocks);
            lastConflicts.AddRange(deletionConflicts);
        }

        private static HashSet<string> GetChangedBlocks(List<Block> targetBlocks, List<Block> baseBlocks)
        {
            var changed = new HashSet<string>();
            var baseIds = new HashSet<string>(baseBlocks.Select(b => b.Id));

            // Additions and modifications
            foreach (var block in targetBlocks)
            {
                var baseBlock = baseBlocks.Find(b => b.Id == block.Id);
                if (baseBlock == null || baseBlock.Content != block.Content)
                    changed.Add(block.Id);
            }

            // Deletions
            foreach (var block in baseBlocks)
            {
                if (!targetBlocks.Any(b => b.Id == block.Id))
                    changed.Add(block.Id);
            }

            return changed;
        }

        private static List<Conflict> GeneratePropertyConflicts(string blockId, Block baseBlock, Block ourBlock, Block theirBlock)
        {
            var conflicts = new List<Conflict>();

            // Only handle both-modified conflicts here
            // Deletion conflicts are now handled by DetectDeletionConflicts()
            bool ourDeleted = ourBlock == null;
            bool theirDeleted = theirBlock == null;

            // Only process if both sides still have the block (both-modified case)
            if (ourDeleted || theirDeleted)
                return conflicts;

            if (ourBlock.Content == theirBlock.Content)
                return conflicts;

            if (ourBlock.BlockType == "PrefabInstance")
            {
                var baseMods = baseBlock != null ? ParsePrefabModifications(baseBlock.Content) : new Dictionary<string, string>();
                var ourMods = ParsePrefabModifications(ourBlock.Content);
                var theirMods = ParsePrefabModifications(theirBlock.Content);

                var ourDiffKeys = ourMods.Keys
                    .Where(k => !baseMods.TryGetValue(k, out var bv) || bv != ourMods[k])
                    .ToHashSet();
                var theirDiffKeys = theirMods.Keys
                    .Where(k => !baseMods.TryGetValue(k, out var bv) || bv != theirMods[k])
                    .ToHashSet();

                foreach (var key in ourDiffKeys.Intersect(theirDiffKeys))
                {
                    if (ourMods[key] == theirMods[key]) continue;

                    var colonIdx = key.IndexOf(':');
                    var propertyPath = key[(colonIdx + 1)..];
                    var conflictInfo = ConflictDefinitions.GetInfo(ConflictType.BothModifiedPrefabProperty);
                    conflicts.Add(new Conflict
                    {
                        BlockId = blockId,
                        BlockType = "PrefabInstance",
                        SourceName = ourBlock.SourceName,
                        PropertyName = propertyPath,
                        TargetFileId = key[..colonIdx],
                        OurAction = ConflictAction.Modified,
                        OurValue = ourMods[key],
                        TheirAction = ConflictAction.Modified,
                        TheirValue = theirMods[key],
                        Type = ConflictType.BothModifiedPrefabProperty,
                        Resolution = conflictInfo.Resolution
                    });
                }
            }
            else
            {
                var ourDiffs = ourBlock.GetDifferingProperties(baseBlock ?? ourBlock);
                var theirDiffs = theirBlock.GetDifferingProperties(baseBlock ?? theirBlock);

                foreach (var prop in ourDiffs.Intersect(theirDiffs))
                {
                    var ourValue   = ExtractPropertyValue(ourBlock.Content,   prop);
                    var theirValue = ExtractPropertyValue(theirBlock.Content, prop);

                    // GetDifferingProperties is line-index based: adding a list entry (e.g.
                    // m_Component) shifts every following line, making properties like m_Layer
                    // appear changed vs. base even when their values are identical in both
                    // ours and theirs.  Skip those false positives here.
                    if (ourValue == theirValue) continue;

                    var conflictInfo = ConflictDefinitions.GetInfo(ConflictType.BothModifiedGOProperty);
                    conflicts.Add(new Conflict
                    {
                        BlockId = blockId,
                        BlockType = ourBlock.BlockType,
                        SourceName = ourBlock.SourceName,
                        PropertyName = prop,
                        OurAction = ConflictAction.Modified,
                        OurValue = ourValue,
                        TheirAction = ConflictAction.Modified,
                        TheirValue = theirValue,
                        Type = ConflictType.BothModifiedGOProperty,
                        Resolution = conflictInfo.Resolution
                    });
                }
            }

            return FilterSpecialCases(conflicts);
        }

        // -----------------------------------------------------------------------
        // Special Cases — intentional suppressions, kept separate from main logic
        // -----------------------------------------------------------------------

        private static List<Conflict> FilterSpecialCases(List<Conflict> conflicts)
        {
            // m_LocalRotation (x/y/z/w quaternion) — suppress in favour of m_LocalEulerAnglesHint.
            // The raw quaternion values are not meaningful to the user; the Euler hint is shown instead.
            conflicts.RemoveAll(c => c.PropertyName == "m_LocalRotation"
                                  || c.PropertyName.StartsWith("m_LocalRotation."));

            return conflicts;
        }

        // -----------------------------------------------------------------------

        private static int CountPrefabListItems(string content, string listName)
        {
            var sectionMatch = Regex.Match(content, $@"{listName}:(.*?)(?=\n\s+m_|\z)", RegexOptions.Singleline);
            if (!sectionMatch.Success) return 0;
            var section = sectionMatch.Groups[1].Value;
            if (section.Trim() == "[]") return 0;
            return Regex.Matches(section, @"\n\s+-").Count;
        }

        internal static Dictionary<string, string> ParsePrefabModifications(string content)
        {
            var result = new Dictionary<string, string>();
            var propPathRegex = new Regex(@"propertyPath:\s*(.+)");
            var valueRegex = new Regex(@"^[ \t]+value:\s*(.+)", RegexOptions.Multiline);

            // Split on "- target:" to isolate each modification entry
            var entries = Regex.Split(content, @"(?=- target:)");
            foreach (var entry in entries)
            {
                if (!entry.TrimStart().StartsWith("- target:")) continue;

                var fileIdMatch = Regex.Match(entry, @"fileID:\s*(\d+)");
                var propMatch = propPathRegex.Match(entry);
                var valueMatch = valueRegex.Match(entry);

                if (!fileIdMatch.Success || !propMatch.Success || !valueMatch.Success) continue;

                var key = $"{fileIdMatch.Groups[1].Value}:{propMatch.Groups[1].Value.Trim()}";
                result[key] = valueMatch.Groups[1].Value.Trim();
            }

            return result;
        }

        private static string ExtractPropertyValue(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*(.+?)(?:\n|$)");
            return match.Success ? match.Groups[1].Value.Trim() : "";
        }

        // -----------------------------------------------------------------------
        // NEW SIMPLIFIED DELETION CONFLICT DETECTION
        // -----------------------------------------------------------------------

        /// <summary>
        /// Simplified approach: detect deleted items and show one card per deleted item
        /// with a summary of modifications that will be lost.
        /// </summary>
        private static List<Conflict> DetectDeletionConflicts(
            Dictionary<string, Block> baseBlockDict,
            Dictionary<string, Block> ourBlockDict,
            Dictionary<string, Block> theirBlockDict,
            HashSet<string> ourChangedBlocks,
            HashSet<string> theirChangedBlocks)
        {
            var conflicts = new List<Conflict>();
            var reportedBlocks = new HashSet<string>();

            // STEP 1: GameObjects deleted by theirs that we modified
            foreach (var baseBlock in baseBlockDict.Values.Where(b => b.BlockType == "GameObject"))
            {
                if (theirBlockDict.ContainsKey(baseBlock.Id)) continue; // Not deleted

                var goId = baseBlock.Id;
                var modifications = CollectOurModificationsForDeletedGO(
                    goId, baseBlockDict, ourBlockDict, ourChangedBlocks);

                if (modifications.Any())
                {
                    conflicts.Add(new Conflict
                    {
                        BlockId = goId,
                        BlockType = "GameObject",
                        SourceName = baseBlock.SourceName ?? $"GameObject {goId}",
                        PropertyName = "(deleted GameObject)",
                        ModifiedItems = modifications,
                        ModificationCount = modifications.Count,
                        Type = ConflictType.ItemDeletedSimple,
                        Resolution = "This GameObject was deleted. Your modifications to it will be lost.",
                        OurAction = ConflictAction.Modified,
                        TheirAction = ConflictAction.Deleted
                    });

                    reportedBlocks.Add(goId);
                    foreach (var componentId in GetComponentIdsForGO(goId, baseBlockDict))
                    {
                        // Don't mark PrefabInstance as reported - it deserves its own card
                        var component = baseBlockDict.GetValueOrDefault(componentId);
                        if (component?.BlockType != "PrefabInstance")
                            reportedBlocks.Add(componentId);
                    }
                }
            }

            // STEP 2: Individual components deleted (where parent GO still exists)
            // Also handles PrefabInstance, which doesn't have a parent GO
            foreach (var baseBlock in baseBlockDict.Values)
            {
                if (baseBlock.BlockType == "GameObject" || reportedBlocks.Contains(baseBlock.Id))
                    continue;

                if (theirBlockDict.ContainsKey(baseBlock.Id)) continue; // Not deleted

                // PrefabInstance is a top-level entity without a parent GO
                var goId = GetGOIdForBlock(baseBlock);
                if (baseBlock.BlockType != "PrefabInstance")
                {
                    // For regular components, skip if parent GO was also deleted (covered by STEP 1)
                    if (goId == null || !theirBlockDict.ContainsKey(goId)) continue;
                }

                if (ourChangedBlocks.Contains(baseBlock.Id) && ourBlockDict.ContainsKey(baseBlock.Id))
                {
                    var modifications = GetModificationSummary(baseBlock, ourBlockDict.GetValueOrDefault(baseBlock.Id));

                    // PrefabInstance is a top-level entity, components are attached to GameObjects
                    string sourceName, propertyName, resolution;
                    if (baseBlock.BlockType == "PrefabInstance")
                    {
                        sourceName = baseBlock.SourceName ?? "Prefab";
                        propertyName = "(deleted prefab instance)";
                        resolution = "This prefab instance was deleted. Your modifications to it will be lost.";
                    }
                    else
                    {
                        var goName = baseBlockDict.GetValueOrDefault(goId)?.SourceName ?? "GameObject";
                        sourceName = goName; // Just the GO name - BlockType already contains the component type
                        propertyName = "(deleted component)";
                        resolution = "This component was deleted. Your modifications to it will be lost.";
                    }

                    conflicts.Add(new Conflict
                    {
                        BlockId = baseBlock.Id,
                        BlockType = baseBlock.BlockType,
                        SourceName = sourceName,
                        PropertyName = propertyName,
                        ModifiedItems = modifications,
                        ModificationCount = modifications.Count,
                        Type = ConflictType.ItemDeletedSimple,
                        Resolution = resolution,
                        OurAction = ConflictAction.Modified,
                        TheirAction = ConflictAction.Deleted
                    });

                    reportedBlocks.Add(baseBlock.Id);
                }
            }

            // STEP 3: Components we added to GameObjects that theirs deleted
            foreach (var ourBlock in ourBlockDict.Values)
            {
                if (baseBlockDict.ContainsKey(ourBlock.Id)) continue; // Not a new addition
                if (reportedBlocks.Contains(ourBlock.Id)) continue;

                var goId = GetGOIdForBlock(ourBlock);
                if (goId == null) continue;

                if (baseBlockDict.ContainsKey(goId) && !theirBlockDict.ContainsKey(goId))
                {
                    if (reportedBlocks.Contains(goId)) continue;

                    var goName = baseBlockDict.GetValueOrDefault(goId)?.SourceName ?? "GameObject";

                    conflicts.Add(new Conflict
                    {
                        BlockId = goId,
                        BlockType = "GameObject",
                        SourceName = goName,
                        PropertyName = "(deleted GameObject)",
                        ModifiedItems = new List<string> { $"Added {ourBlock.BlockType} component" },
                        ModificationCount = 1,
                        Type = ConflictType.ItemDeletedSimple,
                        Resolution = "This GameObject was deleted. Your added component will be lost.",
                        OurAction = ConflictAction.Modified,
                        TheirAction = ConflictAction.Deleted
                    });

                    reportedBlocks.Add(goId);
                }
            }

            // STEP 4: Components removed from PrefabInstances that we modified
            foreach (var theirBlock in theirBlockDict.Values.Where(b => b.BlockType == "PrefabInstance"))
            {
                if (!ourBlockDict.TryGetValue(theirBlock.Id, out var ourBlock)) continue;
                if (!baseBlockDict.TryGetValue(theirBlock.Id, out var baseBlock)) continue;

                // Get components they removed from the prefab
                var theirRemovedComponents = GetPrefabRemovedComponents(theirBlock.Content);
                var baseRemovedComponents = GetPrefabRemovedComponents(baseBlock.Content);
                var newlyRemovedComponents = theirRemovedComponents.Except(baseRemovedComponents).ToList();

                if (!newlyRemovedComponents.Any()) continue;

                // Check if we modified any of those components
                var ourMods = ParsePrefabModifications(ourBlock.Content);
                var baseMods = ParsePrefabModifications(baseBlock.Content);

                var ourChangedMods = ourMods.Keys
                    .Where(k => !baseMods.TryGetValue(k, out var bv) || bv != ourMods[k])
                    .ToList();

                // Group modifications by component (targetFileId)
                var modsByComponent = new Dictionary<string, List<string>>();
                foreach (var modKey in ourChangedMods)
                {
                    var colonIdx = modKey.IndexOf(':');
                    if (colonIdx < 0) continue;
                    var targetFileId = modKey[..colonIdx];

                    if (newlyRemovedComponents.Contains(targetFileId))
                    {
                        if (!modsByComponent.ContainsKey(targetFileId))
                            modsByComponent[targetFileId] = new List<string>();

                        var propertyPath = modKey[(colonIdx + 1)..];
                        modsByComponent[targetFileId].Add(propertyPath);
                    }
                }

                // Create one conflict per removed component
                foreach (var kvp in modsByComponent)
                {
                    var targetFileId = kvp.Key;
                    var conflictingMods = kvp.Value;

                    // Use "Component" as generic type - we don't have easy access to the prefab asset to determine the actual type
                    var componentType = "Component";

                    var sourceName = ourBlock.SourceName ?? "Prefab";

                    conflicts.Add(new Conflict
                    {
                        BlockId = theirBlock.Id,
                        BlockType = componentType,
                        SourceName = sourceName,
                        PropertyName = "(removed prefab component)",
                        TargetFileId = targetFileId, // Indicates this is a prefab-related conflict
                        ModifiedItems = conflictingMods,
                        ModificationCount = conflictingMods.Count,
                        Type = ConflictType.ItemDeletedSimple,
                        Resolution = "This component was removed from the prefab. Your modifications to it will be lost.",
                        OurAction = ConflictAction.Modified,
                        TheirAction = ConflictAction.Deleted
                    });
                }
            }

            // STEP 5: Items WE deleted that THEY modified
            foreach (var baseBlock in baseBlockDict.Values)
            {
                if (baseBlock.BlockType == "GameObject" || reportedBlocks.Contains(baseBlock.Id))
                    continue;

                if (ourBlockDict.ContainsKey(baseBlock.Id)) continue; // We didn't delete it

                // For components, skip if parent GO was also deleted
                var goId = GetGOIdForBlock(baseBlock);
                if (baseBlock.BlockType != "PrefabInstance")
                {
                    if (goId == null || !ourBlockDict.ContainsKey(goId)) continue;
                }

                if (theirChangedBlocks.Contains(baseBlock.Id) && theirBlockDict.ContainsKey(baseBlock.Id))
                {
                    var modifications = GetModificationSummary(baseBlock, theirBlockDict.GetValueOrDefault(baseBlock.Id));

                    string sourceName, propertyName, resolution;
                    if (baseBlock.BlockType == "PrefabInstance")
                    {
                        sourceName = baseBlock.SourceName ?? "Prefab";
                        propertyName = "(deleted prefab instance)";
                        resolution = "You deleted this prefab instance. Their modifications to it will be lost.";
                    }
                    else
                    {
                        var goName = baseBlockDict.GetValueOrDefault(goId)?.SourceName ?? "GameObject";
                        sourceName = goName;
                        propertyName = "(deleted component)";
                        resolution = "You deleted this component. Their modifications to it will be lost.";
                    }

                    conflicts.Add(new Conflict
                    {
                        BlockId = baseBlock.Id,
                        BlockType = baseBlock.BlockType,
                        SourceName = sourceName,
                        PropertyName = propertyName,
                        ModifiedItems = modifications,
                        ModificationCount = modifications.Count,
                        Type = ConflictType.WeDeletedTheyModified,
                        Resolution = resolution,
                        OurAction = ConflictAction.Deleted,
                        TheirAction = ConflictAction.Modified
                    });

                    reportedBlocks.Add(baseBlock.Id);
                }
            }

            return conflicts;
        }

        private const int MaxInlineDiffs = 10;

        private static List<string> CollectOurModificationsForDeletedGO(
            string goId,
            Dictionary<string, Block> baseBlockDict,
            Dictionary<string, Block> ourBlockDict,
            HashSet<string> ourChangedBlocks)
        {
            var modifications = new List<string>();

            // Check if we modified the GO itself
            if (ourChangedBlocks.Contains(goId) &&
                baseBlockDict.TryGetValue(goId, out var baseGO) &&
                ourBlockDict.TryGetValue(goId, out var ourGO))
            {
                var goDiffs = GetModificationSummary(baseGO, ourGO);
                if (goDiffs.Any())
                    modifications.Add($"GameObject: {string.Join(", ", goDiffs)}");
            }

            // Check each component of this GO (excluding PrefabInstance - it gets its own card)
            foreach (var baseBlock in baseBlockDict.Values)
            {
                if (baseBlock.BlockType == "PrefabInstance") continue;

                var blockGoId = GetGOIdForBlock(baseBlock);
                if (blockGoId != goId) continue;

                if (ourChangedBlocks.Contains(baseBlock.Id))
                {
                    var ourBlock = ourBlockDict.GetValueOrDefault(baseBlock.Id);
                    var componentDiffs = GetModificationSummary(baseBlock, ourBlock);

                    if (componentDiffs.Any())
                    {
                        var summary = componentDiffs.Count <= MaxInlineDiffs
                            ? string.Join(", ", componentDiffs)
                            : $"{string.Join(", ", componentDiffs.Take(MaxInlineDiffs))} (+{componentDiffs.Count - MaxInlineDiffs} more)";

                        modifications.Add($"{baseBlock.BlockType}: {summary}");
                    }
                }
            }

            // Check for components we added to this GO
            foreach (var ourBlock in ourBlockDict.Values)
            {
                if (baseBlockDict.ContainsKey(ourBlock.Id)) continue;

                var blockGoId = GetGOIdForBlock(ourBlock);
                if (blockGoId == goId)
                    modifications.Add($"Added {ourBlock.BlockType}");
            }

            return modifications;
        }

        private static List<string> GetModificationSummary(Block baseBlock, Block modifiedBlock)
        {
            if (baseBlock == null || modifiedBlock == null)
                return new List<string>();

            if (modifiedBlock.BlockType == "PrefabInstance")
                return GetPrefabModificationSummary(baseBlock.Content, modifiedBlock.Content);

            var diffs = modifiedBlock.GetDifferingProperties(baseBlock);
            return diffs.Where(prop =>
            {
                var baseValue = ExtractPropertyValue(baseBlock.Content, prop);
                var modValue = ExtractPropertyValue(modifiedBlock.Content, prop);
                return baseValue != modValue;
            }).ToList();
        }

        private static List<string> GetPrefabModificationSummary(string baseContent, string modifiedContent)
        {
            var baseMods = ParsePrefabModifications(baseContent);
            var modifiedMods = ParsePrefabModifications(modifiedContent);
            var changedProps = new List<string>();

            foreach (var kvp in modifiedMods)
            {
                if (!baseMods.TryGetValue(kvp.Key, out var baseValue) || baseValue != kvp.Value)
                {
                    var colonIdx = kvp.Key.IndexOf(':');
                    if (colonIdx >= 0)
                        changedProps.Add(kvp.Key[(colonIdx + 1)..]);
                }
            }

            if (HasStructuralChanges(baseContent, modifiedContent))
                changedProps.Add("[structural changes]");

            return changedProps;
        }

        private static bool HasStructuralChanges(string baseContent, string modifiedContent)
        {
            return CountPrefabListItems(modifiedContent, "m_RemovedGameObjects") >
                       CountPrefabListItems(baseContent, "m_RemovedGameObjects")
                || CountPrefabListItems(modifiedContent, "m_RemovedComponents") >
                       CountPrefabListItems(baseContent, "m_RemovedComponents")
                || CountPrefabListItems(modifiedContent, "m_AddedGameObjects") !=
                       CountPrefabListItems(baseContent, "m_AddedGameObjects")
                || CountPrefabListItems(modifiedContent, "m_AddedComponents") !=
                       CountPrefabListItems(baseContent, "m_AddedComponents");
        }

        private static List<string> GetComponentIdsForGO(string goId, Dictionary<string, Block> blockDict)
        {
            var componentIds = new List<string>();
            foreach (var block in blockDict.Values)
            {
                if (block.BlockType == "GameObject") continue;
                var blockGoId = GetGOIdForBlock(block);
                if (blockGoId == goId)
                    componentIds.Add(block.Id);
            }
            return componentIds;
        }

        private static string GetGOIdForBlock(Block block)
        {
            var match = Regex.Match(block.Content, @"m_GameObject:\s*\{fileID:\s*(\d+)\}");
            return match.Success ? match.Groups[1].Value : null;
        }

        private static List<string> GetPrefabRemovedComponents(string content)
        {
            var removedComponents = new List<string>();
            var sectionMatch = Regex.Match(content, @"m_RemovedComponents:(.*?)(?=\n\s+m_|\z)", RegexOptions.Singleline);

            if (!sectionMatch.Success) return removedComponents;

            var section = sectionMatch.Groups[1].Value;
            var matches = Regex.Matches(section, @"\{fileID:\s*(\d+),");

            foreach (Match match in matches)
            {
                if (match.Groups.Count > 1)
                    removedComponents.Add(match.Groups[1].Value);
            }

            return removedComponents;
        }

        // Block Parser - Given the text of a scene file, find all blocks and return them as a list of Block objects
        public static class BlockParser
        {
            public static List<Block> ParseBlocks(string sceneText)
            {
                var blocks = new List<Block>();

                // Split by block headers to isolate each block
                var blockSections = sceneText.Split(new[] { "--- !u!" }, System.StringSplitOptions.None);

                // First section is the file header, skip it
                for (int i = 1; i < blockSections.Length; i++)
                {
                    var section = blockSections[i];
                    var lines = section.Split(new[] { "\r\n", "\r", "\n" }, System.StringSplitOptions.None);

                    if (lines.Length == 0) continue;

                    // First line contains the block type and ID (e.g., "29 &1")
                    var headerLine = lines[0];
                    var idMatch = Regex.Match(headerLine, @"&(\d+)");

                    if (!idMatch.Success) continue;

                    var id = idMatch.Groups[1].Value;

                    // Content is everything after the header line
                    var content = string.Join("\n", lines, 1, lines.Length - 1).TrimEnd();

                    blocks.Add(new Block(id, content));
                }

                return blocks;
            }
        }

        // Simple data structure for storing block information
        public class Block
        {
            public string Id { get; set; }
            public string Content { get; set; }
            public string BlockType { get; set; }
            public string SourceName { get; set; }

            // Static reference to all blocks for block-hopping
            public static Dictionary<string, Block> AllBlocksReference { get; set; } = new();

            public Block(string id, string content)
            {
                Id = id;
                Content = content;
                ExtractMetadata();
            }

            public void ExtractMetadata()
            {
                // Extract block type (e.g., "GameObject", "Transform", "MonoBehaviour")
                var blockTypeMatch = Regex.Match(Content, @"^(\w+):");
                BlockType = blockTypeMatch.Success ? blockTypeMatch.Groups[1].Value : "Unknown";

                // Try to get source name from m_GameObject reference first (block-hopping)
                var gameObjectMatch = Regex.Match(Content, @"m_GameObject:\s*\{fileID:\s*(\d+)\}");
                if (gameObjectMatch.Success)
                {
                    var gameObjectId = gameObjectMatch.Groups[1].Value;
                    if (AllBlocksReference.TryGetValue(gameObjectId, out var gameObjectBlock))
                    {
                        var nameMatch = Regex.Match(gameObjectBlock.Content, @"m_Name: (.+)$", RegexOptions.Multiline);
                        if (nameMatch.Success)
                        {
                            SourceName = nameMatch.Groups[1].Value.Trim();
                            return;
                        }
                    }
                }

                // For PrefabInstance: extract name from the m_Name modification entry
                if (BlockType == "PrefabInstance")
                {
                    var prefabNameMatch = Regex.Match(Content, @"propertyPath: m_Name\s+value: (.+)", RegexOptions.Multiline);
                    if (prefabNameMatch.Success)
                    {
                        SourceName = prefabNameMatch.Groups[1].Value.Trim();
                        return;
                    }
                }

                // Fallback: extract source name directly from this block's m_Name field
                var directNameMatch = Regex.Match(Content, @"m_Name: (.+)$", RegexOptions.Multiline);
                SourceName = directNameMatch.Success ? directNameMatch.Groups[1].Value.Trim() : string.Empty;
            }

            public List<string> GetDifferingProperties(Block other)
            {
                var differences = new List<string>();

                var thisLines = Content.Split(new[] { "\r\n", "\r", "\n" }, System.StringSplitOptions.None);
                var otherLines = other.Content.Split(new[] { "\r\n", "\r", "\n" }, System.StringSplitOptions.None);

                // Compare line by line
                var maxLines = System.Math.Max(thisLines.Length, otherLines.Length);
                for (int i = 0; i < maxLines; i++)
                {
                    var thisLine = i < thisLines.Length ? thisLines[i] : "";
                    var otherLine = i < otherLines.Length ? otherLines[i] : "";

                    if (thisLine != otherLine)
                    {
                        // Extract property name from lines that start with spaces and contain a colon
                        var propertyMatch = Regex.Match(thisLine, @"^\s+(\w+):");
                        if (propertyMatch.Success)
                        {
                            var propertyName = propertyMatch.Groups[1].Value;
                            if (!differences.Contains(propertyName))
                                differences.Add(propertyName);
                        }
                        else
                        {
                            // Also check the other line for the property name
                            propertyMatch = Regex.Match(otherLine, @"^\s+(\w+):");
                            if (propertyMatch.Success)
                            {
                                var propertyName = propertyMatch.Groups[1].Value;
                                if (!differences.Contains(propertyName))
                                    differences.Add(propertyName);
                            }
                        }
                    }
                }

                return differences;
            }
        }
    }
}
