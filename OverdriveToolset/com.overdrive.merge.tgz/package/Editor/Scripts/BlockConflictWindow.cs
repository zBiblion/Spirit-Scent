using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using System;
using System.IO;
using Overdrive.ToolsetManager;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;
using UnityEditor.UIElements;

namespace Overdrive.Editor.Merge
{
    public class BlockConflictWindow : EditorWindow
    {
        // Removed: groupedConflicts dictionary - no longer needed with simplified approach
        private bool _backupBeforeApply = true;
        private bool _backupBeforeIDFix = true;

        // null = not yet run, true = collisions found, false = all clear
        private IDCollisionSolver _solver;
        private bool? _collisionState;

        // Test Options
        private bool useSpecificFiles = true;
        private UnityEngine.Object _baseFile;
        private UnityEngine.Object _oursFile;
        private UnityEngine.Object _theirsFile;

        // Resolved paths (persisted so the Fix ID Collisions button can re-use them)
        private string _resolvedBasePath;
        private string _resolvedOursPath;
        private string _resolvedTheirsPath;

        // Debug display mode (see ChangesetDebug.cs)
        private enum DisplayMode { Conflicts, OursChanges, TheirsChanges }
        private DisplayMode _displayMode = DisplayMode.Conflicts;

        // Temp files written from git content — kept alive for the collision fixer, cleaned on next run or window close
        private string _gitBaseTmp;
        private string _gitTheirsTmp;

        // Git fetch state — null = not attempted, true = succeeded, false = failed
        private bool?  _fetchState;
        private string _fetchError;

        // Status section — null = not yet checked
        private bool?  _statusCliInstalled;
        private bool?  _statusGitConfigured;
        private bool?  _statusGitReachable;
        private bool?  _statusLicensed;

        // UI element references
        private VisualElement     _defaultView;
        private VisualElement     _idConflictView;
        private VisualElement     _gitIssueView;
        private ToggleButtonGroup _viewModeButtons;
        private ScrollView        _mainScrollView;
        private ScrollView        _stashScrollView;
        private Toggle            _backupBeforeStashToggle;
        private Label             _gitErrorText;
        private Label             _activeFileNameLabel;
        private Button            _installCLIButton;
        private Button            _fixGitDriverButton;
        private Button            _activateLicenseButton;
        private ObjectField       _baseField;
        private ObjectField       _oursField;
        private ObjectField       _theirsField;

        [MenuItem("Window/Overdrive/Conflict Checker")]
        public static void ShowWindow()
        {
            GetWindow<BlockConflictWindow>("Conflict Checker");
        }

        // -----------------------------------------------------------------------
        // UI Toolkit entry point
        // -----------------------------------------------------------------------

        public void CreateGUI()
        {
            var uxml = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(
                "Packages/com.overdrive.merge/Editor/Resources/UI/ConflictChecker.uxml");
            if (uxml == null)
            {
                Debug.LogError("[BlockConflictWindow] Could not load ConflictChecker.uxml.");
                return;
            }

            uxml.CloneTree(rootVisualElement);
            BindUI();
            RefreshUI();

            EditorSceneManager.sceneOpened     += OnSceneOpened;
            EditorSceneManager.newSceneCreated += OnNewSceneCreated;
        }

        private void OnDisable()
        {
            CleanupGitTempFiles();
            EditorSceneManager.sceneOpened     -= OnSceneOpened;
            EditorSceneManager.newSceneCreated -= OnNewSceneCreated;
        }

        private void OnSceneOpened(Scene scene, OpenSceneMode _)                       => UpdateActiveFileName();
        private void OnNewSceneCreated(Scene scene, NewSceneSetup _, NewSceneMode __)  => UpdateActiveFileName();

        private void UpdateActiveFileName()
        {
            if (_activeFileNameLabel == null) return;
            _activeFileNameLabel.text = SceneManager.GetActiveScene().name;
        }

        // -----------------------------------------------------------------------
        // BindUI
        // -----------------------------------------------------------------------

        private void BindUI()
        {
            var root = rootVisualElement;

            // Top-level panels
            _defaultView    = root.Q("DefaultView");
            _idConflictView = root.Q("IDConflictView");
            _gitIssueView   = root.Q("GitIssueView");

            // Active file label
            _activeFileNameLabel = root.Q<Label>("ActiveFileName");
            UpdateActiveFileName();

            // ── ConflictsTab ─────────────────────────────────────────────────

            root.Q<Button>("RefreshMainListButton").clicked   += () => { RunCheck(); RefreshUI(); };
            root.Q<Button>("RunTestMergeButton").clicked      += RunTestMerge;
            root.Q<Button>("ExportMainListLogButton").clicked += ExportConflictLog;

            _viewModeButtons = root.Q<ToggleButtonGroup>("ViewModeButtons");
            _viewModeButtons.RegisterValueChangedCallback(evt =>
            {
                var state = evt.newValue;
                if      (state[0]) _displayMode = DisplayMode.Conflicts;
                else if (state[1]) _displayMode = DisplayMode.OursChanges;
                else if (state[2]) _displayMode = DisplayMode.TheirsChanges;
                BuildMainScrollViewCards();
            });

            _mainScrollView = root.Q<ScrollView>("MainItemsScrollView");
            _mainScrollView.Q("Examples-Hide-These").style.display = DisplayStyle.None;

            // ── StashTab ─────────────────────────────────────────────────────

            _stashScrollView = root.Q<ScrollView>("StashItemsScrollView");
            _stashScrollView.Q("Examples-Hide-These").style.display = DisplayStyle.None;

            _backupBeforeStashToggle = root.Q<Toggle>("BackupBeforeStashToggle");
            _backupBeforeStashToggle.value = _backupBeforeApply;
            _backupBeforeStashToggle.RegisterValueChangedCallback(evt => _backupBeforeApply = evt.newValue);

            // ── IDConflictView ───────────────────────────────────────────────

            root.Q<Button>("FixIDConflictsButton").clicked += OnFixIDConflictsClicked;

            var idFixBackupToggle = root.Q<Toggle>("BackupBeforeIDFixToggle");
            idFixBackupToggle.value = _backupBeforeIDFix;
            idFixBackupToggle.RegisterValueChangedCallback(evt => _backupBeforeIDFix = evt.newValue);

            // ── GitIssueView ─────────────────────────────────────────────────

            _gitErrorText = root.Q<Label>("ErrorText");
            root.Q<Button>("Guide").clicked   += () => Application.OpenURL("https://www.overdrivetoolset.com/merge#git-connection");
            root.Q<Button>("Discord").clicked += () => Application.OpenURL("https://discord.gg/overdrivetoolset");

            // ── Settings: Status rows ────────────────────────────────────────

            _installCLIButton = root.Q<Button>("InstallCLIButton");
            root.Q<Button>("RefreshCLIButton").clicked += () =>
            {
                _statusCliInstalled = SceneMergeInstaller.IsInstalled();
                UpdateStatusRows();
            };
            _installCLIButton.clicked += () =>
            {
                SceneMergeInstaller.ForceReinstall();
                _statusCliInstalled = SceneMergeInstaller.IsInstalled();
                UpdateStatusRows();
            };

            _fixGitDriverButton = root.Q<Button>("FixGitDriverButton");
            root.Q<Button>("RefreshGitDriverButton").clicked += () =>
            {
                _statusGitConfigured = SceneMergeInstaller.IsGitConfigured();
                UpdateStatusRows();
            };
            _fixGitDriverButton.clicked += () =>
            {
                SceneMergeInstaller.ReconfigureGit();
                _statusGitConfigured = SceneMergeInstaller.IsGitConfigured();
                UpdateStatusRows();
            };

            root.Q<Button>("RefreshGitRemoteButton").clicked += () =>
            {
                RefreshGitRemote();
                UpdateStatusRows();
            };

            _activateLicenseButton = root.Q<Button>("ActivateLicenseButton");
            root.Q<Button>("RefreshLicenseButton").clicked += () =>
            {
                _statusLicensed = OverdriveToolsetManager.IsProductLicensed(889);
                UpdateStatusRows();
            };
            _activateLicenseButton.clicked += () =>
                EditorApplication.ExecuteMenuItem("Window/Overdrive/Toolset Manager");

            // ── Settings: Local Files ────────────────────────────────────────

            var localFilesToggle = root.Q<Toggle>("LocalFilesToggle");
            localFilesToggle.value = useSpecificFiles;
            localFilesToggle.RegisterValueChangedCallback(evt =>
            {
                useSpecificFiles = evt.newValue;
                UpdateLocalFilesSection();
            });

            _baseField   = root.Q<ObjectField>("BaseField");
            _oursField   = root.Q<ObjectField>("OursField");
            _theirsField = root.Q<ObjectField>("TheirsField");

            _baseField.objectType   = typeof(UnityEngine.Object);
            _oursField.objectType   = typeof(UnityEngine.Object);
            _theirsField.objectType = typeof(UnityEngine.Object);

            _baseField.value   = _baseFile;
            _oursField.value   = _oursFile;
            _theirsField.value = _theirsFile;

            _baseField.RegisterValueChangedCallback(evt   => _baseFile   = evt.newValue);
            _oursField.RegisterValueChangedCallback(evt   => _oursFile   = evt.newValue);
            _theirsField.RegisterValueChangedCallback(evt => _theirsFile = evt.newValue);

            root.Q<Button>("RefreshOursFileButton").clicked += () =>
            {
                _oursFile        = ResetFileToBase(_oursFile,   "ours.unity");
                _oursField.value = _oursFile;
            };
            root.Q<Button>("RefreshTheirsFileButton").clicked += () =>
            {
                _theirsFile        = ResetFileToBase(_theirsFile, "theirs.unity");
                _theirsField.value = _theirsFile;
            };

            UpdateLocalFilesSection();
        }

        // -----------------------------------------------------------------------
        // RefreshUI — call after any data state changes
        // -----------------------------------------------------------------------

        private void RefreshUI()
        {
            UpdatePanelVisibility();
            UpdateStatusRows();
            BuildMainScrollViewCards();
            BuildStashCards();
        }

        private void UpdatePanelVisibility()
        {
            if (!useSpecificFiles && _fetchState == false)
            {
                if (_gitErrorText != null) _gitErrorText.text = _fetchError ?? string.Empty;
                _defaultView.style.display    = DisplayStyle.None;
                _idConflictView.style.display = DisplayStyle.None;
                _gitIssueView.style.display   = DisplayStyle.Flex;
                return;
            }

            if (_collisionState == true)
            {
                _defaultView.style.display    = DisplayStyle.None;
                _idConflictView.style.display = DisplayStyle.Flex;
                _gitIssueView.style.display   = DisplayStyle.None;
                return;
            }

            _defaultView.style.display    = DisplayStyle.Flex;
            _idConflictView.style.display = DisplayStyle.None;
            _gitIssueView.style.display   = DisplayStyle.None;
        }

        private void UpdateStatusRows()
        {
            SetStatusToggle("StatusToggle-CLI",       _statusCliInstalled);
            SetStatusToggle("StatusToggle-GitDriver",  _statusGitConfigured);
            SetStatusToggle("StatusToggle-GitRemote",  _statusGitReachable);
            SetStatusToggle("StatusToggle-License",    _statusLicensed);

            _installCLIButton?.SetEnabled(_statusCliInstalled    == false);
            _fixGitDriverButton?.SetEnabled(_statusGitConfigured == false);
            _activateLicenseButton?.SetEnabled(_statusLicensed   == false);
        }

        private void SetStatusToggle(string toggleName, bool? state)
        {
            var toggle = rootVisualElement.Q<Toggle>(toggleName);
            if (toggle == null) return;
            toggle.SetValueWithoutNotify(state == true);
            toggle.style.opacity = state == null ? 0.4f : 1f;
        }

        private void UpdateLocalFilesSection()
        {
            _baseField?.SetEnabled(useSpecificFiles);
            _oursField?.SetEnabled(useSpecificFiles);
            _theirsField?.SetEnabled(useSpecificFiles);
            rootVisualElement.Q<Button>("RefreshOursFileButton")?.SetEnabled(useSpecificFiles);
            rootVisualElement.Q<Button>("RefreshTheirsFileButton")?.SetEnabled(useSpecificFiles);
        }

        private void OnFixIDConflictsClicked()
        {
            // _backupBeforeIDFix is stored; IDCollisionSolver.Fix() does not yet accept a
            // backup parameter — wire it in once the solver supports it.
            if (!_solver.Fix()) return;

            bool stillHasCollisions = _solver.Detect(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            _collisionState = stillHasCollisions;

            if (!stillHasCollisions)
            {
                BlockComparison.DebugBlockComparison(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
                ChangesetDebug.Compute(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            }

            RefreshUI();
        }

        // -----------------------------------------------------------------------
        // Card builders
        // -----------------------------------------------------------------------

        private void BuildMainScrollViewCards()
        {
            if (_mainScrollView == null) return;

            // Remove previously generated cards; leave Examples-Hide-These intact
            var toRemove = _mainScrollView.Children()
                .Where(c => c.name != "Examples-Hide-These")
                .ToList();
            foreach (var el in toRemove) _mainScrollView.Remove(el);

            if (_collisionState == null)
            {
                _mainScrollView.Add(MakeInfoLabel("Click 'Refresh' to run the comparison."));
                return;
            }

            if (_displayMode == DisplayMode.OursChanges)  { BuildChangesetCards(ChangesetDebug.lastOurChanges);   return; }
            if (_displayMode == DisplayMode.TheirsChanges) { BuildChangesetCards(ChangesetDebug.lastTheirChanges); return; }

            UpdateConflictsViewButtonLabel();
            BuildConflictCards();
        }

        private void UpdateConflictsViewButtonLabel()
        {
            var btn = _viewModeButtons?.Q<Button>("ConflictsView");
            if (btn == null) return;
            int count = BlockComparison.lastConflicts?.Count ?? 0;
            btn.text = count > 0 ? $"Conflicts ({count})" : "Conflicts";
        }

        private void BuildConflictCards()
        {
            if (BlockComparison.lastConflicts == null || BlockComparison.lastConflicts.Count == 0)
            {
                _mainScrollView.Add(MakeInfoLabel("No conflicts found."));
                return;
            }

            // Simplified: Just render each conflict directly - no grouping needed!
            foreach (var conflict in BlockComparison.lastConflicts)
                _mainScrollView.Add(BuildConflictCard(conflict));
        }

        private VisualElement BuildConflictCard(Conflict conflict)
        {
            // Use simplified rendering for deletion conflict types
            if (conflict.Type == ConflictType.ItemDeletedSimple || conflict.Type == ConflictType.WeDeletedTheyModified)
                return BuildDeletionConflictCard(conflict);

            // Original rendering for both-modified conflicts
            bool isPrefab = conflict.BlockType == "PrefabInstance";
            var conflictInfo = ConflictDefinitions.GetInfo(conflict.Type);

            var card = new VisualElement();
            card.AddToClassList("item-card");
            card.AddToClassList(conflictInfo.CssClass);

            // Path row - now includes the property name as the final element
            var pathRow = new VisualElement();
            pathRow.AddToClassList("item-path");

            var pathLabel = new Label(conflict.SourceName ?? $"Block {conflict.BlockId}");
            pathLabel.AddToClassList("show-left-side-icon");
            pathLabel.AddToClassList("path-label");
            WindowUtilities.ApplyGameObjectOrPrefabIconToLabel(pathLabel, isPrefab);
            pathRow.Add(pathLabel);

            if (!string.IsNullOrEmpty(conflict.BlockType) && conflict.BlockType != "GameObject" && !isPrefab)
            {
                var arrow = new VisualElement();
                arrow.AddToClassList("icon");
                arrow.AddToClassList("item-path-arrow");
                pathRow.Add(arrow);

                var compLabel = new Label(WindowUtilities.HumanizePropertyName(conflict.BlockType));
                compLabel.AddToClassList("show-left-side-icon");
                compLabel.AddToClassList("path-label");
                WindowUtilities.ApplyComponentIconToLabel(compLabel, conflict.BlockType);
                pathRow.Add(compLabel);

                // Add arrow before property name
                var arrow2 = new VisualElement();
                arrow2.AddToClassList("icon");
                arrow2.AddToClassList("item-path-arrow");
                pathRow.Add(arrow2);
            }
            else
            {
                // Add arrow before property name
                var arrow = new VisualElement();
                arrow.AddToClassList("icon");
                arrow.AddToClassList("item-path-arrow");
                pathRow.Add(arrow);
            }

            // Property name as final path element
            var propLabel = new Label(WindowUtilities.FormatPropertyName(conflict.PropertyName));
            propLabel.AddToClassList("path-label");
            propLabel.AddToClassList("path-label-final");
            pathRow.Add(propLabel);

            card.Add(pathRow);

            // Conflict info text
            var infoLabel = new Label(conflictInfo.Resolution);
            infoLabel.AddToClassList("conflict-info");
            card.Add(infoLabel);

            // Value rows
            string oursText   = conflict.OurAction   == ConflictAction.Deleted ? "DELETED" : conflict.OurValue;
            string theirsText = conflict.TheirAction == ConflictAction.Deleted ? "DELETED" : conflict.TheirValue;

            var oursField = new TextField { label = "Yours", value = oursText, isReadOnly = true };
            oursField.AddToClassList("show-left-side-icon");
            oursField.AddToClassList("indent-one-level");
            oursField.AddToClassList(conflictInfo.Winner == ConflictDefinitions.WinSide.Ours ? "property-value-win" : "property-value-lose");
            card.Add(oursField);

            var theirsField = new TextField { label = "Theirs", value = theirsText, isReadOnly = true };
            theirsField.AddToClassList("show-left-side-icon");
            theirsField.AddToClassList("indent-one-level");
            theirsField.AddToClassList(conflictInfo.Winner == ConflictDefinitions.WinSide.Theirs ? "property-value-win" : "property-value-lose");
            card.Add(theirsField);

            // Action button - only show "Stash" for prefabs
            if (conflictInfo.ShowActionButtons && isPrefab)
            {
                var stashBtn = new Button(() => CaptureStash(conflict, conflict.OurValue)) { text = "Stash your changes to re-apply later" };
                stashBtn.AddToClassList("stash-button");
                card.Add(stashBtn);
            }

            // Select In Hierarchy button
            var selectBtn = CreateSelectInHierarchyButton(conflict.BlockId);
            if (selectBtn != null)
                card.Add(selectBtn);

            return card;
        }

        private VisualElement BuildDeletionConflictCard(Conflict conflict)
        {
            var conflictInfo = ConflictDefinitions.GetInfo(conflict.Type);
            var card = new VisualElement();
            card.AddToClassList("item-card");
            card.AddToClassList(conflictInfo.CssClass);

            // Path row - final element gets path-label-final class
            // TargetFileId indicates this is a prefab-related conflict (for icon purposes)
            bool isPrefabRelated = !string.IsNullOrEmpty(conflict.TargetFileId) || conflict.BlockType == "PrefabInstance";
            bool isComponent = !string.IsNullOrEmpty(conflict.BlockType) && conflict.BlockType != "GameObject" && conflict.BlockType != "PrefabInstance";

            var pathRow = new VisualElement();
            pathRow.AddToClassList("item-path");

            if (isComponent)
            {
                // GameObject/Prefab > Component structure
                var pathLabel = new Label(conflict.SourceName ?? $"Block {conflict.BlockId}");
                pathLabel.AddToClassList("show-left-side-icon");
                pathLabel.AddToClassList("path-label");
                WindowUtilities.ApplyGameObjectOrPrefabIconToLabel(pathLabel, isPrefabRelated);
                pathRow.Add(pathLabel);

                var arrow = new VisualElement();
                arrow.AddToClassList("icon");
                arrow.AddToClassList("item-path-arrow");
                pathRow.Add(arrow);

                var compLabel = new Label(WindowUtilities.HumanizePropertyName(conflict.BlockType));

                // Only show icon if we know the specific component type (not generic "Component")
                if (conflict.BlockType != "Component")
                {
                    compLabel.AddToClassList("show-left-side-icon");
                    WindowUtilities.ApplyComponentIconToLabel(compLabel, conflict.BlockType);
                }

                compLabel.AddToClassList("path-label");
                compLabel.AddToClassList("path-label-final");
                pathRow.Add(compLabel);
            }
            else
            {
                // Just GameObject/Prefab - it's the final element
                // Add margin-bottom when path has only one element
                pathRow.style.marginBottom = 6;

                var pathLabel = new Label(conflict.SourceName ?? $"Block {conflict.BlockId}");
                pathLabel.AddToClassList("show-left-side-icon");
                pathLabel.AddToClassList("path-label");
                pathLabel.AddToClassList("path-label-final");
                WindowUtilities.ApplyGameObjectOrPrefabIconToLabel(pathLabel, isPrefabRelated);
                pathRow.Add(pathLabel);
            }

            card.Add(pathRow);

            // Determine who deleted and who modified
            bool weDeleted = conflict.OurAction == ConflictAction.Deleted;
            bool theyDeleted = conflict.TheirAction == ConflictAction.Deleted;

            // Determine the item type for the conflict info text
            string itemType = conflict.BlockType == "PrefabInstance" ? "Prefab Instance" :
                             isComponent ? "Component" :
                             isPrefabRelated ? "Prefab Instance" :
                             "GameObject";

            // Conflict info text - different messages based on who deleted
            string infoText;
            if (theyDeleted && !weDeleted)
            {
                // They deleted, we modified
                infoText = $"This {itemType} was edited in Yours, but removed in Theirs. On merge, your changes will be discarded:";
            }
            else
            {
                // We deleted, they modified
                infoText = $"This {itemType} was removed in Yours, but edited in Theirs. On merge, their changes will be discarded:";
            }

            var infoLabel = new Label(infoText);
            infoLabel.AddToClassList("conflict-info");
            card.Add(infoLabel);

            // Spacer
            var spacer = new VisualElement();
            spacer.style.marginTop = 6;
            card.Add(spacer);

            // List of modifications that will be lost
            if (conflict.ModifiedItems != null && conflict.ModifiedItems.Any())
            {
                var itemsToShow = conflict.ModifiedItems.Take(10).ToList();
                var changeListText = string.Join("\n", itemsToShow.Select(item => $"• {item}"));

                if (conflict.ModifiedItems.Count > 10)
                    changeListText += $"\n• (+{conflict.ModifiedItems.Count - 10} more changes)";

                var changeList = new Label(changeListText);
                changeList.AddToClassList("indent-one-level");
                changeList.AddToClassList("show-left-side-icon");
                changeList.AddToClassList("property-value-lose");
                card.Add(changeList);
            }

            // Action button - only show "Stash" when we have changes to stash (they deleted, we modified)
            if (conflictInfo.ShowActionButtons && theyDeleted && !weDeleted)
            {
                var stashBtn = new Button(() => Debug.Log($"[DEBUG] Stash Yours clicked for {conflict.SourceName ?? conflict.BlockId}"))
                    { text = "Stash your changes to re-apply later" };
                stashBtn.AddToClassList("stash-button");
                card.Add(stashBtn);
            }

            // Select In Hierarchy button
            var selectBtn = CreateSelectInHierarchyButton(conflict.BlockId);
            if (selectBtn != null)
                card.Add(selectBtn);

            return card;
        }

        private void BuildChangesetCards(List<ChangeEntry> entries)
        {
            if (entries == null || entries.Count == 0)
            {
                _mainScrollView.Add(MakeInfoLabel("No changes found."));
                return;
            }

            foreach (var entry in entries)
                _mainScrollView.Add(BuildChangesetCard(entry));
        }

        private static VisualElement BuildChangesetCard(ChangeEntry entry)
        {
            string context = string.IsNullOrEmpty(entry.SourceName)
                ? $"{entry.BlockType} ({entry.BlockId})"
                : $"{entry.BlockType} on {entry.SourceName}";

            var card = new VisualElement();
            card.AddToClassList("item-card");

            if (entry.IsAdded || entry.IsDeleted)
            {
                var title = new Label($"{(entry.IsAdded ? "[Added]" : "[Deleted]")} {context}");
                title.style.unityFontStyleAndWeight = FontStyle.Bold;
                card.Add(title);
            }
            else
            {
                var title = new Label($"[Modified] {context} — {WindowUtilities.FormatPropertyName(entry.PropertyName)}");
                title.style.unityFontStyleAndWeight = FontStyle.Bold;
                card.Add(title);

                var before = new Label($"Before: {entry.BaseValue}");
                var after  = new Label($"After:  {entry.NewValue}");
                before.AddToClassList("indent-one-level");
                after.AddToClassList("indent-one-level");
                card.Add(before);
                card.Add(after);
            }

            return card;
        }

        private void BuildStashCards()
        {
            if (_stashScrollView == null) return;

            var toRemove = _stashScrollView.Children()
                .Where(c => c.name != "Examples-Hide-These" && c is not Toggle)
                .ToList();
            foreach (var el in toRemove) _stashScrollView.Remove(el);

            var scenePath = GetAbsoluteOursPath();
            var stashes   = StashManager.Load(scenePath);

            if (stashes.Count == 0)
            {
                _stashScrollView.Add(MakeInfoLabel("No stashed items for this scene."));
                return;
            }

            for (int i = stashes.Count - 1; i >= 0; i--)
                _stashScrollView.Add(BuildStashCard(stashes[i]));
        }

        private VisualElement BuildStashCard(StashEntry stash)
        {
            var card = new VisualElement();
            card.AddToClassList("item-card");

            var title = new Label(stash.DisplayName);
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            card.Add(title);
            card.Add(new Label($"Value: {stash.StashedValue}"));
            card.Add(new Label($"Saved: {stash.CreatedAt}"));

            var buttons = new VisualElement();
            buttons.style.flexDirection = FlexDirection.Row;

            var applyBtn = new Button(() =>
            {
                if (StashApplicator.Apply(stash, stash.ScenePath, _backupBeforeApply))
                {
                    StashManager.Remove(stash.EntryId, stash.ScenePath);
                    BuildStashCards();
                }
            })
            { text = "Apply" };
            applyBtn.style.flexBasis = 1;

            var discardBtn = new Button(() =>
            {
                StashManager.Remove(stash.EntryId, stash.ScenePath);
                BuildStashCards();
            })
            { text = "Discard" };
            discardBtn.style.flexBasis = 1;

            buttons.Add(applyBtn);
            buttons.Add(discardBtn);
            card.Add(buttons);

            return card;
        }

        private static Label MakeInfoLabel(string text)
        {
            var label = new Label(text);
            label.style.marginLeft = 6;
            label.style.marginTop  = 6;
            label.style.opacity    = 0.6f;
            label.style.whiteSpace = WhiteSpace.Normal;
            return label;
        }

        private Button CreateSelectInHierarchyButton(string blockId)
        {
            // Only show button if we have a valid scene path to parse
            if (string.IsNullOrEmpty(_resolvedOursPath) || !File.Exists(_resolvedOursPath))
                return null;

            var button = new Button(() =>
            {
                var activeScene = SceneManager.GetActiveScene();
                if (!activeScene.IsValid())
                {
                    EditorUtility.DisplayDialog("No Active Scene", "No scene is currently active. Please open the scene you want to search in.", "OK");
                    return;
                }

                var result = WindowUtilities.FindAndSelectGameObjectForBlock(blockId, _resolvedOursPath, activeScene);

                if (result == null)
                {
                    EditorUtility.DisplayDialog("Not Found",
                        "Could not locate this object in the active scene hierarchy.\n\n" +
                        "Make sure the scene is loaded and matches the file being analyzed.", "OK");
                }
            })
            { text = "Select In Hierarchy" };

            button.style.marginTop = 4;
            return button;
        }

        // -----------------------------------------------------------------------
        // Run Check
        // -----------------------------------------------------------------------

        private void RunCheck()
        {
            _fetchState = null;
            _fetchError = null;
            if (useSpecificFiles)
                RunCheckFromTestFiles();
            else
                RunCheckFromGit();
        }

        private void RunCheckFromTestFiles()
        {
            if (_baseFile == null || _oursFile == null || _theirsFile == null)
            {
                Debug.LogWarning("[BlockConflictWindow] Please assign all three test files (Base, Ours, Theirs).");
                return;
            }

            _resolvedBasePath   = AssetDatabase.GetAssetPath(_baseFile);
            _resolvedOursPath   = AssetDatabase.GetAssetPath(_oursFile);
            _resolvedTheirsPath = AssetDatabase.GetAssetPath(_theirsFile);

            RunComparison();
        }

        private void RunCheckFromGit()
        {
            var scene = SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(scene.path))
            {
                Debug.LogError("[BlockConflictWindow] Save the active scene before running a conflict check.");
                return;
            }

            string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string repoRoot    = SceneMergeGitOperations.RunGit("rev-parse --show-toplevel", projectRoot);
            if (repoRoot == null)
            {
                Debug.LogError("[BlockConflictWindow] Could not find Git repository root.");
                return;
            }

            if (!TryFetchGit(repoRoot)) return;

            string upstream = SceneMergeGitOperations.RunGit("rev-parse --abbrev-ref @{u}", repoRoot);
            if (string.IsNullOrEmpty(upstream))
            {
                Debug.LogError("[BlockConflictWindow] No upstream tracking branch set. Run: git branch --set-upstream-to=origin/<branch>");
                return;
            }

            string mergeBase = SceneMergeGitOperations.RunGit($"merge-base HEAD {upstream}", repoRoot);
            if (mergeBase == null)
            {
                Debug.LogError($"[BlockConflictWindow] Could not find merge-base between HEAD and {upstream}.");
                return;
            }

            string absScenePath   = Path.GetFullPath(Path.Combine(projectRoot, scene.path));
            string sceneRelToRepo = Path.GetRelativePath(repoRoot, absScenePath).Replace('\\', '/');

            string baseContent   = SceneMergeGitOperations.RunGit($"show {mergeBase}:\"{sceneRelToRepo}\"", repoRoot);
            string theirsContent = SceneMergeGitOperations.RunGit($"show {upstream}:\"{sceneRelToRepo}\"", repoRoot);

            if (baseContent == null)
            {
                Debug.LogError($"[BlockConflictWindow] Could not read base version of scene at {mergeBase}.");
                return;
            }
            if (theirsContent == null)
            {
                Debug.LogError($"[BlockConflictWindow] Could not read {upstream} version of scene.");
                return;
            }

            CleanupGitTempFiles();

            _gitBaseTmp   = Path.GetTempFileName();
            _gitTheirsTmp = Path.GetTempFileName();
            File.WriteAllText(_gitBaseTmp,   baseContent);
            File.WriteAllText(_gitTheirsTmp, theirsContent);

            _resolvedBasePath   = _gitBaseTmp;
            _resolvedOursPath   = absScenePath;
            _resolvedTheirsPath = _gitTheirsTmp;

            RunComparison();
        }

        private void RunComparison()
        {
            _solver = new IDCollisionSolver();
            bool hasCollisions = _solver.Detect(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            _collisionState = hasCollisions;

            if (!hasCollisions)
            {
                BlockComparison.DebugBlockComparison(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
                ChangesetDebug.Compute(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            }
        }

        private void RunTestMerge()
        {
            string yamlMergePath = SceneMergeGitOperations.FindUnityYAMLMerge();
            if (string.IsNullOrEmpty(yamlMergePath))
            {
                Debug.LogError("[BlockConflictWindow] UnityYAMLMerge not found. Is Unity installed via Unity Hub?");
                return;
            }

            string basePath, oursPath, theirsPath, outputPath;
            string tempBase = null, tempTheirs = null;

            try
            {
                if (useSpecificFiles)
                {
                    if (_baseFile == null || _oursFile == null || _theirsFile == null)
                    {
                        Debug.LogWarning("[BlockConflictWindow] Assign all three test files before running a test merge.");
                        return;
                    }

                    basePath   = Path.GetFullPath(AssetDatabase.GetAssetPath(_baseFile));
                    oursPath   = Path.GetFullPath(AssetDatabase.GetAssetPath(_oursFile));
                    theirsPath = Path.GetFullPath(AssetDatabase.GetAssetPath(_theirsFile));
                    outputPath = Path.Combine(Path.GetDirectoryName(oursPath), "Ours_MergeTest.unity");
                }
                else
                {
                    var scene = SceneManager.GetActiveScene();
                    if (string.IsNullOrEmpty(scene.path))
                    {
                        Debug.LogError("[BlockConflictWindow] Save the active scene before running a test merge.");
                        return;
                    }

                    string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                    string repoRoot = SceneMergeGitOperations.RunGit("rev-parse --show-toplevel", projectRoot);
                    if (repoRoot == null) { Debug.LogError("[BlockConflictWindow] Could not find Git repository root."); return; }

                    if (!TryFetchGit(repoRoot)) return;

                    string upstream = SceneMergeGitOperations.RunGit("rev-parse --abbrev-ref @{u}", repoRoot);
                    if (string.IsNullOrEmpty(upstream)) { Debug.LogError("[BlockConflictWindow] No upstream tracking branch set. Run: git branch --set-upstream-to=origin/<branch>"); return; }

                    string mergeBase = SceneMergeGitOperations.RunGit($"merge-base HEAD {upstream}", repoRoot);
                    if (mergeBase == null) { Debug.LogError($"[BlockConflictWindow] Could not find merge-base between HEAD and {upstream}."); return; }

                    string absScenePath   = Path.GetFullPath(Path.Combine(projectRoot, scene.path));
                    string sceneRelToRepo = Path.GetRelativePath(repoRoot, absScenePath).Replace('\\', '/');

                    string baseContent   = SceneMergeGitOperations.RunGit($"show {mergeBase}:\"{sceneRelToRepo}\"", repoRoot);
                    string theirsContent = SceneMergeGitOperations.RunGit($"show {upstream}:\"{sceneRelToRepo}\"", repoRoot);

                    if (baseContent   == null) { Debug.LogError("[BlockConflictWindow] Could not read base version of scene."); return; }
                    if (theirsContent == null) { Debug.LogError($"[BlockConflictWindow] Could not read {upstream} version of scene."); return; }

                    tempBase   = Path.GetTempFileName();
                    tempTheirs = Path.GetTempFileName();
                    File.WriteAllText(tempBase,   baseContent);
                    File.WriteAllText(tempTheirs, theirsContent);

                    basePath   = tempBase;
                    oursPath   = absScenePath;
                    theirsPath = tempTheirs;
                    outputPath = Path.Combine(Path.GetDirectoryName(absScenePath), $"{scene.name}_MergeTest.unity");
                }

                var psi = new System.Diagnostics.ProcessStartInfo(
                    yamlMergePath,
                    $"merge --fallback none -p \"{basePath}\" \"{oursPath}\" \"{theirsPath}\" \"{outputPath}\"")
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true
                };

                using var proc = System.Diagnostics.Process.Start(psi);
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                int exitCode = proc.ExitCode;
                if (exitCode != 0 && exitCode != 2)
                {
                    Debug.LogError($"[BlockConflictWindow] Test merge failed (exit code {exitCode}).\nStderr: {stderr}");
                    return;
                }

                string resultNote = exitCode == 2 ? " (conflicts auto-resolved, ours kept)" : " (clean)";
                Debug.Log($"[BlockConflictWindow] Test merge complete{resultNote}.\nOutput: {outputPath}");

                AssetDatabase.Refresh();

                string projectRootForAsset = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                string assetRelPath = Path.GetRelativePath(projectRootForAsset, outputPath).Replace('\\', '/');
                var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetRelPath);
                if (asset != null)
                    Selection.activeObject = asset;
            }
            finally
            {
                if (tempBase   != null && File.Exists(tempBase))   File.Delete(tempBase);
                if (tempTheirs != null && File.Exists(tempTheirs)) File.Delete(tempTheirs);
            }
        }

        private bool TryFetchGit(string repoRoot)
        {
            string error = SceneMergeGitOperations.RunGitWithError("fetch", repoRoot);
            if (error == null)
            {
                _fetchState = true;
                _fetchError = null;
                return true;
            }

            _fetchState = false;
            _fetchError = error.Trim();
            return false;
        }

        private void CleanupGitTempFiles()
        {
            if (_gitBaseTmp   != null && File.Exists(_gitBaseTmp))   File.Delete(_gitBaseTmp);
            if (_gitTheirsTmp != null && File.Exists(_gitTheirsTmp)) File.Delete(_gitTheirsTmp);
            _gitBaseTmp   = null;
            _gitTheirsTmp = null;
        }

        private UnityEngine.Object ResetFileToBase(UnityEngine.Object target, string fallbackFileName)
        {
            if (_baseFile == null) return target;
            var basePath = AssetDatabase.GetAssetPath(_baseFile);
            if (string.IsNullOrEmpty(basePath)) return target;

            string targetPath;
            if (target == null)
            {
                var dir = Path.GetDirectoryName(basePath).Replace('\\', '/');
                targetPath = $"{dir}/{fallbackFileName}";
            }
            else
            {
                targetPath = AssetDatabase.GetAssetPath(target);
                if (string.IsNullOrEmpty(targetPath)) return target;
            }

            File.Copy(basePath, targetPath, overwrite: true);
            AssetDatabase.Refresh();
            return AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(targetPath);
        }

        // -----------------------------------------------------------------------
        // Git Remote status
        // -----------------------------------------------------------------------

        private void RefreshGitRemote()
        {
            string projectRoot = Path.GetDirectoryName(Application.dataPath);
            string repoRoot    = SceneMergeGitOperations.RunGit("rev-parse --show-toplevel", projectRoot);
            if (repoRoot == null)
            {
                _statusGitReachable = false;
                return;
            }

            string error        = SceneMergeGitOperations.RunGitWithError("fetch", repoRoot);
            _statusGitReachable = error == null;
        }

        // -----------------------------------------------------------------------
        // Export log
        // -----------------------------------------------------------------------

        private void ExportConflictLog()
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"Conflict Log — {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Total conflicts: {BlockComparison.lastConflicts.Count}");
            sb.AppendLine(new string('-', 60));

            foreach (var conflict in BlockComparison.lastConflicts)
            {
                sb.AppendLine($"[{ConflictDefinitions.GetInfo(conflict.Type).DisplayName}]  Block {conflict.BlockId}  ({conflict.BlockType})");
                if (!string.IsNullOrEmpty(conflict.SourceName))
                    sb.AppendLine($"  Source:   {conflict.SourceName}");
                sb.AppendLine($"  Property: {conflict.PropertyName}");
                sb.AppendLine($"  Ours:     {(conflict.OurAction   == ConflictAction.Deleted ? "Deleted" : conflict.OurValue)}");
                sb.AppendLine($"  Theirs:   {(conflict.TheirAction == ConflictAction.Deleted ? "Deleted" : conflict.TheirValue)}");
                sb.AppendLine($"  Result:   {conflict.Resolution}");
                sb.AppendLine();
            }

            string path = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "conflict_log.txt"));
            File.WriteAllText(path, sb.ToString());
            Debug.Log($"[BlockConflictWindow] Conflict log exported to: {path}");
            EditorUtility.RevealInFinder(path);
        }

        // -----------------------------------------------------------------------
        // Stash
        // -----------------------------------------------------------------------

        private void DirectApply(Conflict conflict, string value)
        {
            var scenePath = GetAbsoluteOursPath();
            if (string.IsNullOrEmpty(scenePath)) return;

            var entry = new StashEntry
            {
                BlockId      = conflict.BlockId,
                BlockType    = conflict.BlockType,
                PropertyName = conflict.PropertyName,
                TargetFileId = conflict.TargetFileId,
                StashedValue = value,
            };

            if (!StashApplicator.Apply(entry, scenePath, _backupBeforeApply)) return;

            if (conflict.BlockType == "PrefabInstance"
                && conflict.PropertyName.StartsWith("m_LocalEulerAnglesHint."))
            {
                ApplyCompanionQuaternion(conflict, scenePath);
            }

            rootVisualElement.schedule.Execute(ReAnalyse).ExecuteLater(0);
        }

        private void ApplyCompanionQuaternion(Conflict conflict, string scenePath)
        {
            if (string.IsNullOrEmpty(_resolvedTheirsPath) || !File.Exists(_resolvedTheirsPath))
                return;

            var theirsRaw = File.ReadAllText(_resolvedTheirsPath);
            var sections  = theirsRaw.Split(new[] { "--- !u!" }, StringSplitOptions.None);

            string theirsBlock = null;
            for (int i = 1; i < sections.Length; i++)
            {
                if (Regex.IsMatch(sections[i], $@"&{Regex.Escape(conflict.BlockId)}\b"))
                {
                    theirsBlock = sections[i];
                    break;
                }
            }
            if (theirsBlock == null) return;

            var theirsMods = BlockComparison.ParsePrefabModifications(theirsBlock);

            foreach (var axis in new[] { "x", "y", "z", "w" })
            {
                var rotPropName = $"m_LocalRotation.{axis}";
                var rotKey      = $"{conflict.TargetFileId}:{rotPropName}";
                if (!theirsMods.TryGetValue(rotKey, out var rotValue)) continue;

                var rotEntry = new CompanionStashEntry
                {
                    BlockId      = conflict.BlockId,
                    BlockType    = "PrefabInstance",
                    PropertyName = rotPropName,
                    TargetFileId = conflict.TargetFileId,
                    StashedValue = rotValue,
                };
                StashApplicator.ApplyCompanion(rotEntry, scenePath);
            }
        }

        private void CaptureStash(Conflict conflict, string value)
        {
            var scenePath = GetAbsoluteOursPath();
            if (string.IsNullOrEmpty(scenePath)) return;

            var entry = new StashEntry
            {
                EntryId      = Guid.NewGuid().ToString(),
                CreatedAt    = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                ScenePath    = scenePath,
                DisplayName  = GetStashDisplayName(conflict),
                BlockId      = conflict.BlockId,
                BlockType    = conflict.BlockType,
                PropertyName = conflict.PropertyName,
                TargetFileId = conflict.TargetFileId,
                StashedValue = value,
            };

            if (conflict.BlockType == "PrefabInstance"
                && conflict.PropertyName.StartsWith("m_LocalEulerAnglesHint."))
            {
                entry.CompanionEntries = BuildQuaternionCompanions(conflict, scenePath);
            }

            StashManager.Save(entry, scenePath);
            BuildStashCards();
        }

        private static List<CompanionStashEntry> BuildQuaternionCompanions(Conflict conflict, string scenePath)
        {
            var companions = new List<CompanionStashEntry>();
            if (!File.Exists(scenePath)) return companions;

            var raw      = File.ReadAllText(scenePath);
            var sections = raw.Split(new[] { "--- !u!" }, StringSplitOptions.None);

            string block = null;
            for (int i = 1; i < sections.Length; i++)
            {
                if (Regex.IsMatch(sections[i], $@"&{Regex.Escape(conflict.BlockId)}\b"))
                {
                    block = sections[i];
                    break;
                }
            }
            if (block == null) return companions;

            var mods = BlockComparison.ParsePrefabModifications(block);

            foreach (var axis in new[] { "x", "y", "z", "w" })
            {
                var propName = $"m_LocalRotation.{axis}";
                var key      = $"{conflict.TargetFileId}:{propName}";
                if (!mods.TryGetValue(key, out var rotValue)) continue;

                companions.Add(new CompanionStashEntry
                {
                    BlockId      = conflict.BlockId,
                    BlockType    = "PrefabInstance",
                    PropertyName = propName,
                    TargetFileId = conflict.TargetFileId,
                    StashedValue = rotValue,
                });
            }

            return companions;
        }

        private string GetStashDisplayName(Conflict conflict)
        {
            var prop = WindowUtilities.FormatPropertyName(conflict.PropertyName);
            var src  = string.IsNullOrEmpty(conflict.SourceName) ? $"Block {conflict.BlockId}" : conflict.SourceName;
            return $"{prop} on {src}";
        }

        private void ReAnalyse()
        {
            if (string.IsNullOrEmpty(_resolvedBasePath)) return;
            BlockComparison.DebugBlockComparison(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            ChangesetDebug.Compute(_resolvedBasePath, _resolvedOursPath, _resolvedTheirsPath);
            RefreshUI();
        }

        private string GetAbsoluteOursPath()
        {
            if (useSpecificFiles)
            {
                if (_oursFile == null) return null;
                var rel = AssetDatabase.GetAssetPath(_oursFile);
                return Path.GetFullPath(Path.Combine(Application.dataPath, "..", rel));
            }
            return _resolvedOursPath;
        }
    }
}
