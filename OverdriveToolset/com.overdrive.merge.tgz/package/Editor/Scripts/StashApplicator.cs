using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace Overdrive.Editor.Merge
{
    public static class StashApplicator
    {
        /// <summary>
        /// Applies a stashed value back into the scene file at the original block/property location.
        /// Returns true if the file was modified successfully.
        /// </summary>
        public static bool Apply(StashEntry entry, string scenePath, bool backup = true)
        {
            if (!File.Exists(scenePath))
            {
                Debug.LogError($"[StashApplicator] Scene file not found: {scenePath}");
                return false;
            }

            if (backup)
            {
                var backupPath = scenePath + ".stash-backup";
                File.Copy(scenePath, backupPath, overwrite: true);
                Debug.Log($"[StashApplicator] Backup written to: {backupPath}");
            }

            // Split on block headers — sections[0] is the YAML file header
            var raw      = File.ReadAllText(scenePath);
            var sections = raw.Split(new[] { "--- !u!" }, System.StringSplitOptions.None);

            int idx = -1;
            for (int i = 1; i < sections.Length; i++)
            {
                if (Regex.IsMatch(sections[i], $@"&{Regex.Escape(entry.BlockId)}\b"))
                {
                    idx = i;
                    break;
                }
            }

            if (idx < 0)
            {
                Debug.LogError($"[StashApplicator] Block {entry.BlockId} not found in '{scenePath}'. " +
                               "The scene may have changed significantly since the stash was captured.");
                return false;
            }

            var modified = entry.BlockType == "PrefabInstance"
                ? ApplyPrefabMod(sections[idx], entry)
                : ApplyRegularProp(sections[idx], entry);

            if (modified == null) return false;

            sections[idx] = modified;
            File.WriteAllText(scenePath, string.Join("--- !u!", sections));

            // Apply any companion entries (e.g. m_LocalRotation.* paired with m_LocalEulerAnglesHint.*)
            // without a backup — the backup already happened for the primary entry.
            foreach (var companion in entry.CompanionEntries)
                ApplyCompanion(companion, scenePath);

            AssetDatabase.Refresh();
            return true;
        }

        public static void ApplyCompanion(CompanionStashEntry companion, string scenePath)
        {
            var raw      = File.ReadAllText(scenePath);
            var sections = raw.Split(new[] { "--- !u!" }, System.StringSplitOptions.None);

            int idx = -1;
            for (int i = 1; i < sections.Length; i++)
            {
                if (Regex.IsMatch(sections[i], $@"&{Regex.Escape(companion.BlockId)}\b"))
                {
                    idx = i;
                    break;
                }
            }
            if (idx < 0) return;

            var modified = companion.BlockType == "PrefabInstance"
                ? ApplyPrefabMod(sections[idx], companion.TargetFileId, companion.PropertyName, companion.StashedValue)
                : ApplyRegularProp(sections[idx], companion.BlockId, companion.PropertyName, companion.StashedValue);

            if (modified == null) return;

            sections[idx] = modified;
            File.WriteAllText(scenePath, string.Join("--- !u!", sections));
        }

        // -----------------------------------------------------------------------
        // Regular block — replace the property line directly
        // -----------------------------------------------------------------------

        private static string ApplyRegularProp(string section, StashEntry entry)
            => ApplyRegularProp(section, entry.BlockId, entry.PropertyName, entry.StashedValue);

        private static string ApplyRegularProp(string section, string blockId, string propertyName, string value)
        {
            // Matches "  propertyName: <anything>" — preserves leading whitespace
            var pattern = $@"([ \t]+{Regex.Escape(propertyName)}:[ \t]*)(.+)";
            if (!Regex.IsMatch(section, pattern))
            {
                Debug.LogError($"[StashApplicator] Property '{propertyName}' not found in block {blockId}.");
                return null;
            }
            return Regex.Replace(section, pattern, $"${{1}}{value}");
        }

        // -----------------------------------------------------------------------
        // PrefabInstance — locate the right m_Modifications entry, replace value
        // -----------------------------------------------------------------------

        private static string ApplyPrefabMod(string section, StashEntry entry)
            => ApplyPrefabMod(section, entry.TargetFileId, entry.PropertyName, entry.StashedValue);

        private static string ApplyPrefabMod(string section, string targetFileId, string propertyName, string value)
        {
            // Split on "- target:" boundaries to isolate each modification entry
            var parts = Regex.Split(section, @"(?=- target:)");
            bool found = false;

            for (int i = 0; i < parts.Length; i++)
            {
                if (!parts[i].TrimStart().StartsWith("- target:")) continue;

                var fileIdMatch = Regex.Match(parts[i], @"fileID:\s*(\d+)");
                var propMatch   = Regex.Match(parts[i], @"propertyPath:\s*(.+)");

                if (!fileIdMatch.Success || !propMatch.Success) continue;
                if (fileIdMatch.Groups[1].Value != targetFileId) continue;
                if (propMatch.Groups[1].Value.Trim() != propertyName) continue;

                // Replace the value line, preserving indentation
                parts[i] = Regex.Replace(parts[i],
                    @"([ \t]+value:[ \t]*)(.+)",
                    $"${{1}}{value}");
                found = true;
                break;
            }

            if (!found)
            {
                Debug.LogError($"[StashApplicator] Modification entry for target {targetFileId} / " +
                               $"'{propertyName}' not found in PrefabInstance block.");
                return null;
            }

            return string.Join("", parts);
        }
    }
}
