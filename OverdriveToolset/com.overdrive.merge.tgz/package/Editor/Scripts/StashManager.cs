using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Overdrive.Editor.Merge
{
    // Flat companion entry — no CompanionEntries field, breaking the self-reference
    // that causes Unity's JsonUtility serialization-depth warning.
    [Serializable]
    public class CompanionStashEntry
    {
        public string BlockId;
        public string BlockType;
        public string PropertyName;
        public string TargetFileId;
        public string StashedValue;
    }

    [Serializable]
    public class StashEntry
    {
        public string EntryId;
        public string CreatedAt;
        public string ScenePath;     // absolute path — apply target after merge
        public string DisplayName;
        public string BlockId;
        public string BlockType;
        public string PropertyName;
        public string TargetFileId;  // PrefabInstance only
        public string StashedValue;

        // Silent companions applied alongside this entry (e.g. m_LocalRotation.*
        // paired with m_LocalEulerAnglesHint.* — not shown in the UI individually).
        public List<CompanionStashEntry> CompanionEntries = new();
    }

    public static class StashManager
    {
        [Serializable]
        private class StashFile
        {
            public List<StashEntry> entries = new List<StashEntry>();
        }

        private static string StashDir =>
            Path.GetFullPath(Path.Combine(Application.dataPath, "..", "StashData"));

        private static string GetFilePath(string scenePath)
        {
            Directory.CreateDirectory(StashDir);
            return Path.Combine(StashDir, $"{Path.GetFileNameWithoutExtension(scenePath)}-stashes.json");
        }

        public static void Save(StashEntry entry, string scenePath)
        {
            var file = Read(scenePath);
            file.entries.Add(entry);
            Write(file, scenePath);
        }

        public static List<StashEntry> Load(string scenePath)
        {
            if (string.IsNullOrEmpty(scenePath)) return new List<StashEntry>();
            return Read(scenePath).entries;
        }

        public static void Remove(string entryId, string scenePath)
        {
            var file = Read(scenePath);
            file.entries.RemoveAll(e => e.EntryId == entryId);
            Write(file, scenePath);
        }

        private static StashFile Read(string scenePath)
        {
            var path = GetFilePath(scenePath);
            if (!File.Exists(path)) return new StashFile();
            try   { return JsonUtility.FromJson<StashFile>(File.ReadAllText(path)) ?? new StashFile(); }
            catch { return new StashFile(); }
        }

        private static void Write(StashFile file, string scenePath) =>
            File.WriteAllText(GetFilePath(scenePath), JsonUtility.ToJson(file, true));
    }
}
