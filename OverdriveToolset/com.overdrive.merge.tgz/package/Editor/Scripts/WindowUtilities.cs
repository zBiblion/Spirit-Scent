using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Search;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

namespace Overdrive.Editor.Merge
{
    internal static class WindowUtilities
    {
        private static readonly Dictionary<string, string> PropertyDisplayNames = new()
        {
            // Transform — humanizer would say "Local Euler Angles Hint", not "Rotation"
            { "m_LocalEulerAnglesHint", "Rotation" },
            { "m_LocalEulerAngles",     "Rotation" },
            { "m_LocalPosition",        "Position" },
            { "m_LocalScale",           "Scale"    },
            // GameObject
            { "m_IsActive",    "Active" },
            { "m_TagString",   "Tag"    },
            { "m_Name",        "Name"   },
        };

        private static readonly Dictionary<string, string> AxisSuffixes = new()
        {
            { "x", "X axis" }, { "y", "Y axis" }, { "z", "Z axis" }, { "w", "W axis" },
            { "r", "Red"    }, { "g", "Green"  }, { "b", "Blue"   }, { "a", "Alpha"  },
        };

        internal static string FormatPropertyName(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName)) return propertyName;

            var dotIdx = propertyName.IndexOf('.');
            var baseProp  = dotIdx >= 0 ? propertyName[..dotIdx]       : propertyName;
            var component = dotIdx >= 0 ? propertyName[(dotIdx + 1)..] : null;

            var displayBase = PropertyDisplayNames.TryGetValue(baseProp, out var special)
                ? special
                : HumanizePropertyName(baseProp);

            if (component == null) return displayBase;

            var suffix = AxisSuffixes.TryGetValue(component.ToLower(), out var axisLabel)
                ? axisLabel
                : component;
            return $"{displayBase} ({suffix})";
        }

        internal static string HumanizePropertyName(string name)
        {
            if (name.StartsWith("m_")) name = name[2..];
            // Insert spaces before capital letters: "IsTrigger" → "Is Trigger"
            name = Regex.Replace(name, @"(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])", " ");
            return name.Length == 0 ? name : char.ToUpper(name[0]) + name[1..];
        }

        internal static string GetActionText(ConflictAction action, string value)
            => action == ConflictAction.Deleted ? "Deleted" : $"Set to {value}";

        internal static string GetModifiedActionText(string propertyName, string value)
        {
            if (propertyName == "(prefab instance)" || string.IsNullOrEmpty(propertyName))
                return value;
            return $"Set {FormatPropertyName(propertyName)} to {value}";
        }

        internal static void DrawChangeEntry(ChangeEntry entry)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);

            string context = string.IsNullOrEmpty(entry.SourceName)
                ? $"{entry.BlockType} ({entry.BlockId})"
                : $"{entry.BlockType} on {entry.SourceName}";

            if (entry.IsAdded)
            {
                EditorGUILayout.LabelField($"[Added] {context}", EditorStyles.miniBoldLabel);
            }
            else if (entry.IsDeleted)
            {
                EditorGUILayout.LabelField($"[Deleted] {context}", EditorStyles.miniBoldLabel);
            }
            else
            {
                EditorGUILayout.LabelField($"[Modified] {context} — {FormatPropertyName(entry.PropertyName)}", EditorStyles.miniBoldLabel);
                EditorGUILayout.Space(2);
                EditorGUILayout.LabelField($"Before: {entry.BaseValue}", EditorStyles.miniLabel);
                EditorGUILayout.LabelField($"After:  {entry.NewValue}",  EditorStyles.miniLabel);
            }

            EditorGUILayout.EndVertical();
            GUILayout.Space(3);
        }

        /// <summary>
        /// Attempts to get the Unity Editor icon for a component type.
        /// </summary>
        /// <param name="typeName">The component type name (e.g., "Transform", "BoxCollider")</param>
        /// <returns>The component's icon texture, or null if not found</returns>
        internal static Texture2D GetComponentIcon(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;

            // Try to find the type in UnityEngine assembly
            Type componentType = Type.GetType($"UnityEngine.{typeName}, UnityEngine")
                              ?? Type.GetType($"UnityEngine.{typeName}, UnityEngine.CoreModule");

            // If not found in UnityEngine, search all loaded assemblies
            if (componentType == null)
            {
                foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    componentType = assembly.GetType(typeName) ?? assembly.GetType($"UnityEngine.{typeName}");
                    if (componentType != null) break;
                }
            }

            if (componentType == null) return null;

            // Use EditorGUIUtility.ObjectContent to get the icon
            var content = EditorGUIUtility.ObjectContent(null, componentType);
            return content?.image as Texture2D;
        }

        /// <summary>
        /// Gets the Unity Editor icon for GameObject or Prefab.
        /// </summary>
        /// <param name="isPrefab">True for prefab icon, false for GameObject icon</param>
        /// <returns>The icon texture, or null if not found</returns>
        internal static Texture2D GetGameObjectOrPrefabIcon(bool isPrefab)
        {
            if (isPrefab)
            {
                // Get prefab icon
                var prefabIcon = EditorGUIUtility.IconContent("Prefab Icon");
                return prefabIcon?.image as Texture2D;
            }
            else
            {
                // Get GameObject icon
                return GetComponentIcon("GameObject");
            }
        }

        /// <summary>
        /// Applies a component icon to a Label as a background image.
        /// </summary>
        /// <param name="label">The Label to apply the icon to</param>
        /// <param name="typeName">The component type name</param>
        internal static void ApplyComponentIconToLabel(Label label, string typeName)
        {
            if (label == null) return;

            var icon = GetComponentIcon(typeName);
            if (icon == null) return;

            label.style.backgroundImage = new StyleBackground(icon);
        }

        /// <summary>
        /// Applies GameObject or Prefab icon to a Label as a background image.
        /// </summary>
        /// <param name="label">The Label to apply the icon to</param>
        /// <param name="isPrefab">True for prefab icon, false for GameObject icon</param>
        internal static void ApplyGameObjectOrPrefabIconToLabel(Label label, bool isPrefab)
        {
            if (label == null) return;

            var icon = GetGameObjectOrPrefabIcon(isPrefab);
            if (icon == null) return;

            label.style.backgroundImage = new StyleBackground(icon);
        }

        // -----------------------------------------------------------------------
        // GameObject Hierarchy Finding
        // -----------------------------------------------------------------------

        /// <summary>
        /// Attempts to find and select the GameObject corresponding to a block ID in the hierarchy.
        /// Uses progressive search with increasing specificity to locate objects.
        /// </summary>
        /// <param name="blockId">The block ID to find</param>
        /// <param name="sceneFilePath">Path to the scene file to parse for block metadata</param>
        /// <param name="scene">The scene to search in</param>
        /// <returns>The found GameObject, or null if not found</returns>
        internal static GameObject FindAndSelectGameObjectForBlock(string blockId, string sceneFilePath, Scene scene)
        {
            if (string.IsNullOrWhiteSpace(blockId))
            {
                Debug.LogWarning("[WindowUtilities] Block ID is empty.");
                return null;
            }

            if (!scene.IsValid())
            {
                Debug.LogWarning("[WindowUtilities] Invalid scene provided.");
                return null;
            }

            if (!File.Exists(sceneFilePath))
            {
                Debug.LogWarning($"[WindowUtilities] Scene file not found: {sceneFilePath}");
                return null;
            }

            // Read and parse the scene file
            string sceneText = File.ReadAllText(sceneFilePath);
            var blocks = BlockComparison.BlockParser.ParseBlocks(sceneText);

            // Create reference dictionary for block hopping
            var allBlocksRef = blocks.ToDictionary(b => b.Id);
            BlockComparison.Block.AllBlocksReference = allBlocksRef;

            // Re-extract metadata with references available
            foreach (var block in blocks)
                block.ExtractMetadata();

            // Find the target block
            var targetBlock = blocks.FirstOrDefault(b => b.Id == blockId);
            if (targetBlock == null)
            {
                Debug.LogWarning($"[WindowUtilities] Block ID '{blockId}' not found in scene file '{sceneFilePath}'");
                return null;
            }

            // Determine the GameObject block to search for
            var gameObjectBlock = GetGameObjectBlockForBlock(targetBlock, allBlocksRef);
            if (gameObjectBlock == null)
            {
                Debug.LogWarning($"[WindowUtilities] Could not find parent GameObject for block '{blockId}' (Type: {targetBlock.BlockType})");
                return null;
            }

            // Search for the GameObject in the hierarchy
            var result = FindGameObjectInHierarchy(gameObjectBlock, scene);

            if (result != null)
            {
                Selection.activeGameObject = result;
                EditorGUIUtility.PingObject(result);
                Debug.Log($"[WindowUtilities] Selected: {GetHierarchyPath(result)}");
            }
            else
            {
                Debug.LogWarning($"[WindowUtilities] GameObject not found in hierarchy for block '{blockId}' (Type: {gameObjectBlock.BlockType}, Name: '{gameObjectBlock.SourceName}')");
            }

            return result;
        }

        private static BlockComparison.Block GetGameObjectBlockForBlock(BlockComparison.Block block, Dictionary<string, BlockComparison.Block> allBlocks)
        {
            string blockType = block.BlockType;

            // GameObject and PrefabInstance blocks are already the target
            if (blockType == "GameObject" || blockType == "PrefabInstance")
                return block;

            // For components (Transform, RectTransform, etc.), find parent GameObject
            var goId = GetGOIdForBlock(block);
            if (goId != null && allBlocks.TryGetValue(goId, out var goBlock))
                return goBlock;

            return null;
        }

        private static GameObject FindGameObjectInHierarchy(BlockComparison.Block targetBlock, Scene scene)
        {
            var candidates = new List<GameObject>();

            // STEP 1: Search by name using Search API (only for GameObjects, not reliable for prefabs)
            if (targetBlock.BlockType == "GameObject" && !string.IsNullOrEmpty(targetBlock.SourceName))
            {
                candidates = SearchByName(targetBlock.SourceName, scene);

                if (candidates.Count == 1)
                    return candidates[0];
            }

            // STEP 2: Get all scene objects for transform-based search
            var allObjects = GetAllSceneObjects(scene);

            // If we didn't get candidates from name search, use all objects
            var searchPool = candidates.Count > 0 ? candidates : allObjects;

            // STEP 3: Search by transform properties (position, rotation, scale)
            var transformCandidates = FilterByTransform(searchPool, targetBlock);

            if (transformCandidates.Count == 1)
                return transformCandidates[0];

            if (transformCandidates.Count > 1)
            {
                // STEP 4: Try to filter by name within transform matches
                candidates = transformCandidates;

                if (!string.IsNullOrEmpty(targetBlock.SourceName))
                {
                    var nameFiltered = candidates.Where(go => go.name == targetBlock.SourceName).ToList();
                    if (nameFiltered.Count == 1)
                        return nameFiltered[0];

                    if (nameFiltered.Count > 0)
                        candidates = nameFiltered;
                }

                // Multiple matches - return the first one
                Debug.LogWarning($"[WindowUtilities] Found {candidates.Count} potential matches. Selecting first match.");
                return candidates[0];
            }

            // No matches found
            return null;
        }

        private static List<GameObject> SearchByName(string objectName, Scene scene)
        {
            var results = new List<GameObject>();

            // Use Search API to find objects by name in the scene
            var searchContext = SearchService.CreateContext("scene", objectName);

            var items = SearchService.GetItems(searchContext);
            foreach (var item in items)
            {
                var obj = item.ToObject<GameObject>();
                if (obj != null && obj.scene == scene && obj.name == objectName)
                {
                    results.Add(obj);
                }
            }

            searchContext.Dispose();
            return results;
        }

        private static List<GameObject> GetAllSceneObjects(Scene scene)
        {
            var allObjects = new List<GameObject>();
            var rootObjects = scene.GetRootGameObjects();

            foreach (var root in rootObjects)
            {
                allObjects.Add(root);
                allObjects.AddRange(root.GetComponentsInChildren<Transform>(true).Select(t => t.gameObject));
            }

            return allObjects;
        }

        private static List<GameObject> FilterByTransform(List<GameObject> objects, BlockComparison.Block block)
        {
            // Extract transform data from block
            var position = ExtractVector3(block.Content, "m_LocalPosition");
            var rotation = ExtractQuaternion(block.Content, "m_LocalRotation");
            var scale = ExtractVector3(block.Content, "m_LocalScale");

            var matches = new List<GameObject>();

            foreach (var obj in objects)
            {
                var transform = obj.transform;
                bool positionMatch = !position.HasValue || Vector3.Distance(transform.localPosition, position.Value) < 0.0001f;
                bool rotationMatch = !rotation.HasValue || Quaternion.Angle(transform.localRotation, rotation.Value) < 0.001f;
                bool scaleMatch = !scale.HasValue || Vector3.Distance(transform.localScale, scale.Value) < 0.0001f;

                if (positionMatch && rotationMatch && scaleMatch)
                {
                    matches.Add(obj);
                }
            }

            return matches;
        }

        private static Vector3? ExtractVector3(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*\{{x:\s*([-\d.]+),\s*y:\s*([-\d.]+),\s*z:\s*([-\d.]+)\}}");
            if (match.Success)
            {
                return new Vector3(
                    float.Parse(match.Groups[1].Value),
                    float.Parse(match.Groups[2].Value),
                    float.Parse(match.Groups[3].Value)
                );
            }
            return null;
        }

        private static Quaternion? ExtractQuaternion(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*\{{x:\s*([-\d.]+),\s*y:\s*([-\d.]+),\s*z:\s*([-\d.]+),\s*w:\s*([-\d.]+)\}}");
            if (match.Success)
            {
                return new Quaternion(
                    float.Parse(match.Groups[1].Value),
                    float.Parse(match.Groups[2].Value),
                    float.Parse(match.Groups[3].Value),
                    float.Parse(match.Groups[4].Value)
                );
            }
            return null;
        }

        private static string GetGOIdForBlock(BlockComparison.Block block)
        {
            var match = Regex.Match(block.Content, @"m_GameObject:\s*\{fileID:\s*(\d+)\}");
            return match.Success ? match.Groups[1].Value : null;
        }

        private static string GetHierarchyPath(GameObject obj)
        {
            string path = obj.name;
            Transform parent = obj.transform.parent;
            while (parent != null)
            {
                path = parent.name + "/" + path;
                parent = parent.parent;
            }
            return path;
        }
    }
}
