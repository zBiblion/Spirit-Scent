using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Self-contained ID collision detector and fixer for Unity YAML scene/prefab files.
    ///
    /// An ID collision occurs when both branches independently added a block with the same fileID
    /// (i.e. the ID did not exist in base, so both sides generated it on separate machines).
    /// The merge tool cannot resolve this regardless of block type — even two GameObjects with the
    /// same ID will produce a corrupt scene because every reference in the file becomes ambiguous.
    /// These must be resolved before any comparison or merge.
    ///
    /// Usage:
    ///   var solver = new IDCollisionSolver();
    ///   if (solver.Detect(basePath, oursPath, theirsPath))
    ///   {
    ///       // show solver.CollisionCount to the user, offer Fix()
    ///       solver.Fix();
    ///       solver.Detect(...);  // re-run to confirm clean
    ///   }
    /// </summary>
    public class IDCollisionSolver
    {
        /// <summary>FileIDs that collide, populated by the last Detect() call.</summary>
        public List<string> Collisions { get; private set; } = new List<string>();

        public int CollisionCount => Collisions.Count;

        private string _basePath;
        private string _oursPath;
        private string _theirsPath;

        private static readonly Regex _blockSplit  = new Regex(@"(?=^--- !u!)",       RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex _blockHeader = new Regex(@"^--- !u!\d+ &(\d+)", RegexOptions.Compiled);

        // -----------------------------------------------------------------------
        // Public API
        // -----------------------------------------------------------------------

        /// <summary>
        /// Scan the three scene/prefab files for ID collisions.
        /// Populates <see cref="Collisions"/> and returns true when any are found.
        /// Safe to call multiple times (clears previous results each time).
        /// </summary>
        public bool Detect(string basePath, string oursPath, string theirsPath)
        {
            _basePath   = basePath;
            _oursPath   = oursPath;
            _theirsPath = theirsPath;

            Collisions.Clear();

            var baseIDs   = ParseFileIDs(File.ReadAllText(basePath));
            var oursIDs   = ParseFileIDs(File.ReadAllText(oursPath));
            var theirsIDs = ParseFileIDs(File.ReadAllText(theirsPath));

            // Collisions = IDs added in ours ∩ IDs added in theirs
            // "Added" means not present in base — both machines generated the same ID independently.
            foreach (string fileID in oursIDs)
            {
                if (baseIDs.Contains(fileID))   continue; // existed in base — not independently added
                if (!theirsIDs.Contains(fileID)) continue; // only in ours — no collision

                Collisions.Add(fileID);
                Debug.LogError($"[IDCollisionSolver] ID collision: &{fileID} added on both branches");
            }

            return Collisions.Count > 0;
        }

        /// <summary>
        /// Fix all collisions found by the last <see cref="Detect"/> call.
        /// Renumbers the colliding blocks in OURS and rewrites every fileID reference
        /// throughout that file. Does NOT modify base or theirs.
        /// Returns true if the file was written successfully.
        /// </summary>
        public bool Fix()
        {
            if (Collisions.Count == 0)
            {
                Debug.LogWarning("[IDCollisionSolver] Fix() called with no collisions to fix.");
                return true;
            }

            if (string.IsNullOrEmpty(_oursPath) || !File.Exists(_oursPath))
            {
                Debug.LogError("[IDCollisionSolver] Fix() called but ours path is not set or does not exist.");
                return false;
            }

            try
            {
                // Back up ours before any modifications
                string backupPath = _oursPath + ".id_collision_backup";
                File.Copy(_oursPath, backupPath, overwrite: true);

                // Collect every ID in use across all three versions to guarantee uniqueness of new IDs
                var allIDs = new HashSet<string>();
                allIDs.UnionWith(ParseFileIDs(File.ReadAllText(_basePath)));
                allIDs.UnionWith(ParseFileIDs(File.ReadAllText(_oursPath)));
                allIDs.UnionWith(ParseFileIDs(File.ReadAllText(_theirsPath)));

                string oursContent = File.ReadAllText(_oursPath);

                foreach (string fileID in Collisions)
                {
                    string newID = GenerateUniqueID(allIDs);

                    // Rewrite block header:  --- !u!XXX &OLD_ID  →  --- !u!XXX &NEW_ID
                    oursContent = Regex.Replace(
                        oursContent,
                        $@"^(--- !u!\d+) &{fileID}\b",
                        $"$1 &{newID}",
                        RegexOptions.Multiline);

                    // Rewrite every fileID reference:  fileID: OLD_ID  →  fileID: NEW_ID
                    oursContent = Regex.Replace(
                        oursContent,
                        $@"(fileID:\s*){fileID}\b",
                        $"${{1}}{newID}");

                    allIDs.Add(newID); // prevent a later iteration from picking the same ID

                    Debug.Log($"[IDCollisionSolver] Renumbered &{fileID} → &{newID}");
                }

                File.WriteAllText(_oursPath, oursContent);
                Debug.Log($"[IDCollisionSolver] Fixed {Collisions.Count} ID collision(s). Backup at: {backupPath}");
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[IDCollisionSolver] Fix failed: {ex.Message}\n{ex.StackTrace}");
                return false;
            }
        }

        // -----------------------------------------------------------------------
        // Private helpers
        // -----------------------------------------------------------------------

        private HashSet<string> ParseFileIDs(string yamlContent)
        {
            var ids = new HashSet<string>();
            foreach (var doc in _blockSplit.Split(yamlContent))
            {
                if (string.IsNullOrWhiteSpace(doc)) continue;
                var m = _blockHeader.Match(doc);
                if (m.Success) ids.Add(m.Groups[1].Value);
            }
            return ids;
        }

        private static string GenerateUniqueID(HashSet<string> existing)
        {
            var rng = new System.Random();
            string id;
            int attempts = 0;
            do
            {
                id = rng.Next(10_000_000, int.MaxValue).ToString();
                if (++attempts > 10_000)
                {
                    Debug.LogError("[IDCollisionSolver] Could not generate a unique ID after 10,000 attempts.");
                    break;
                }
            }
            while (existing.Contains(id));
            return id;
        }
    }
}
