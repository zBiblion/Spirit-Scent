using UnityEditor;
using UnityEngine;
using System;
using System.IO;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Automatically installs the Scene Merge CLI tool when the package is imported.
    /// 
    /// Architecture:
    ///   1. BUNDLED: CLI tool ships in package at Packages/com.overdrive.merge/CLI~/[platform]/
    ///   2. INSTALLED: On first run, tool is copied to user's AppData/Application Support
    ///   3. EXECUTION: Git and Unity always run the tool from the installed location
    /// 
    /// Why AppData?
    ///   - Survives package updates/reimports
    ///   - Per-user installation (no admin rights needed)
    ///   - Standard location across Windows/Mac/Linux
    ///   - Git config can reference a stable path
    /// 
    /// Runs once on package import, copies the bundled executable to user directory,
    /// and configures Git to use it as a merge driver for .unity files.
    /// </summary>
    [InitializeOnLoad]
    public static class SceneMergeInstaller
    {
        private const int PRODUCT_ID = 889;
        private const string PREF_KEY_INSTALLED_VERSION = "OverdriveSceneMerge.InstalledVersion";
        private const string PREF_KEY_GIT_CONFIG_OK = "OverdriveSceneMerge.GitConfigOk";
        private const string PREF_KEY_GIT_CONFIG_ERROR = "OverdriveSceneMerge.GitConfigError";

        private static readonly string InstallDir = GetInstallDirectory();
        private static readonly string ToolExecutable = GetToolExecutablePath();

        static SceneMergeInstaller()
        {
            // Run on Unity startup / package import
            EditorApplication.delayCall += CheckAndInstall;
        }

        private static void CheckAndInstall()
        {
            string currentVersion = GetPackageVersion();
            string installedVersion = EditorPrefs.GetString(PREF_KEY_INSTALLED_VERSION, "");

            // Install if not installed, or if package version is newer
            if (!IsToolInstalled() || installedVersion != currentVersion)
            {
                InstallTool(currentVersion);
            }
        }

        private static bool IsToolInstalled()
        {
            return File.Exists(ToolExecutable);
        }

        private static void InstallTool(string version)
        {
            try
            {
                // 1. Create install directory
                Directory.CreateDirectory(InstallDir);

                // 2. Copy CLI executable from package to user directory
                string sourcePath = GetBundledExecutablePath();
                if (!File.Exists(sourcePath))
                {
                    Debug.LogError($"[Scene Merge] Bundled executable not found at: {sourcePath}");
                    EditorUtility.DisplayDialog("Scene Merge Installation Failed",
                        "Could not find bundled CLI tool. Please reinstall the package.",
                        "OK");
                    return;
                }

                File.Copy(sourcePath, ToolExecutable, overwrite: true);
                Debug.Log($"[Scene Merge] CLI tool installed to: {ToolExecutable}");

                // 3. Write version file
                WriteVersionFile();

                // 4. Make executable on Mac/Linux
                if (Application.platform == RuntimePlatform.OSXEditor)
                {
                    var chmodProcess = System.Diagnostics.Process.Start("chmod", $"+x \"{ToolExecutable}\"");
                    chmodProcess?.WaitForExit();
                }

                // 5. Configure Git for current project
                string gitError = ConfigureGit();
                if (string.IsNullOrEmpty(gitError))
                {
                    EditorPrefs.SetString(PREF_KEY_GIT_CONFIG_OK, "true");
                    EditorPrefs.DeleteKey(PREF_KEY_GIT_CONFIG_ERROR);
                }
                else
                {
                    EditorPrefs.DeleteKey(PREF_KEY_GIT_CONFIG_OK);
                    EditorPrefs.SetString(PREF_KEY_GIT_CONFIG_ERROR, gitError);
                    Debug.LogWarning($"[Scene Merge] Git configuration failed: {gitError}");
                }

                // 7. Mark as installed
                EditorPrefs.SetString(PREF_KEY_INSTALLED_VERSION, version);

                Debug.Log("[Scene Merge] Installation complete!");
            }
            catch (Exception e)
            {
                Debug.LogError($"[Scene Merge] Installation failed: {e.Message}\n{e.StackTrace}");
                EditorUtility.DisplayDialog("Scene Merge Installation Failed",
                    $"Error: {e.Message}\n\nPlease contact support at overdrivetoolset.com",
                    "OK");
            }
            finally
            {
                // Always open the status window so the user can see what happened
                EditorApplication.delayCall += SceneMergeStatus.ShowWindow;
            }
        }

        private static void WriteVersionFile()
        {
            try
            {
                // Read version from bundled VERSION.txt in the package
                var packageInfo = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SceneMergeInstaller).Assembly);
                string packagePath = packageInfo?.resolvedPath ?? "";

                if (string.IsNullOrEmpty(packagePath))
                {
                    Debug.LogWarning("[Scene Merge] Could not determine package path for version file");
                    return;
                }

                string bundledVersionPath = Path.Combine(packagePath, "CLI~", "VERSION.txt");
                if (!File.Exists(bundledVersionPath))
                {
                    Debug.LogWarning($"[Scene Merge] VERSION.txt not found at: {bundledVersionPath}");
                    return;
                }

                // Read version number
                string version = File.ReadAllText(bundledVersionPath).Trim();

                // Write to install directory as toolVersion.txt
                string versionPath = Path.Combine(InstallDir, "toolVersion.txt");
                File.WriteAllText(versionPath, version);

                Debug.Log($"[Scene Merge] Version file written: {versionPath} (Build #{version})");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[Scene Merge] Failed to write version file: {ex.Message}");
            }
        }

        /// <summary>Returns null on success, GIT_ERROR_NOT_A_REPO if not a git repo, or an error message.</summary>
        private static string ConfigureGit()
        {
            try
            {
                string projectRoot = Path.GetDirectoryName(Application.dataPath);

                // 1. Check we're inside a git repository before attempting git config
                string repoCheck = RunGitCommand("rev-parse --git-dir", projectRoot);
                if (repoCheck != null)
                {
                    if (repoCheck.Contains("not a git") || repoCheck.Contains("not in a git"))
                        return GIT_ERROR_NOT_A_REPO;
                    return repoCheck;
                }

                // 2. Add to .gitattributes
                var gitAttributesPath = Path.Combine(projectRoot, ".gitattributes");
                var attributeLine = "*.unity merge=unityscenemerge";

                if (File.Exists(gitAttributesPath))
                {
                    var content = File.ReadAllText(gitAttributesPath);
                    if (!content.Contains(attributeLine))
                    {
                        File.AppendAllText(gitAttributesPath, $"\n{attributeLine}\n");
                        Debug.Log("[Scene Merge] Added *.unity merge driver to .gitattributes");
                    }
                }
                else
                {
                    File.WriteAllText(gitAttributesPath, $"{attributeLine}\n");
                    Debug.Log("[Scene Merge] Created .gitattributes with *.unity merge driver");
                }

                // 3. Configure Git merge driver (local to this repo)
                // Use escaped quotes for Windows paths with spaces
                // %P provides the actual scene pathname (not the temp file) so we can extract GUID and find project root
                string driverCommand = $"\\\"{ToolExecutable}\\\" %O %A %B %P";

                string err = RunGitCommand($"config merge.unityscenemerge.driver \"{driverCommand}\"", projectRoot)
                          ?? RunGitCommand("config merge.unityscenemerge.name \"Unity Scene Merge Tool\"", projectRoot);

                if (err != null)
                    return err;

                Debug.Log("[Scene Merge] Git merge driver configured");
                return null;
            }
            catch (Exception e)
            {
                return $"Git configuration failed: {e.Message}";
            }
        }

        /// <summary>Returns null on success, or an error message on failure.</summary>
        private static string RunGitCommand(string arguments, string workingDirectory)
        {
            try
            {
                var startInfo = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "git",
                    Arguments = arguments,
                    WorkingDirectory = workingDirectory,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true,
                    RedirectStandardOutput = true
                };

                using (var process = System.Diagnostics.Process.Start(startInfo))
                {
                    if (process == null)
                        return "Failed to start git process. Is git installed and in PATH?";

                    // Read output before waiting for exit to avoid deadlock
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    process.WaitForExit();

                    if (process.ExitCode != 0)
                    {
                        string msg = $"git {arguments} failed (exit {process.ExitCode}): {error.Trim()}";
                        Debug.LogWarning($"[Scene Merge] {msg}");
                        return msg;
                    }

                    Debug.Log($"[Scene Merge] Git command succeeded: git {arguments}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                return $"Exception running 'git {arguments}': {ex.Message}";
            }
        }

        // Helper methods for paths

        /// <summary>
        /// Returns the user's AppData directory where the tool is INSTALLED and EXECUTED from.
        /// This is the "active" location used by Git and Unity.
        /// Windows: %LOCALAPPDATA%\Overdrive\SceneMerge\
        /// Mac: ~/Library/Application Support/Overdrive/SceneMerge/
        /// </summary>
        private static string GetInstallDirectory()
        {
            string baseDir;
            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                baseDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            }
            else if (Application.platform == RuntimePlatform.OSXEditor)
            {
                baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), 
                    "Library", "Application Support");
            }
            else // Linux
            {
                baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), 
                    ".local", "share");
            }

            return Path.Combine(baseDir, "Overdrive", "SceneMerge");
        }

        /// <summary>
        /// Returns the full path to the INSTALLED tool executable (in AppData).
        /// This is where Git driver and Unity run the tool from.
        /// </summary>
        private static string GetToolExecutablePath()
        {
            string filename = Application.platform == RuntimePlatform.WindowsEditor
                ? "SceneMergeTool.exe"
                : "SceneMergeTool";
            return Path.Combine(InstallDir, filename);
        }

        /// <summary>
        /// Returns the path to the BUNDLED tool executable shipped with the package.
        /// This is the SOURCE location, copied to AppData during installation.
        /// Packages/com.overdrive.merge/CLI~/[win-x64|osx-x64|osx-arm64]/SceneMergeTool[.exe]
        /// </summary>
        private static string GetBundledExecutablePath()
        {
            // Get this package's path
            var packageInfo = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SceneMergeInstaller).Assembly);
            string packagePath = packageInfo?.resolvedPath ?? "";

            if (string.IsNullOrEmpty(packagePath))
            {
                Debug.LogError("[Scene Merge] Could not determine package path");
                return "";
            }

            // Determine platform folder
            string platform;
            if (Application.platform == RuntimePlatform.WindowsEditor)
            {
                platform = "win-x64";
            }
            else if (Application.platform == RuntimePlatform.OSXEditor)
            {
                // Detect ARM vs Intel Mac
                if (SystemInfo.processorType.ToLower().Contains("apple") || 
                    System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture == System.Runtime.InteropServices.Architecture.Arm64)
                {
                    platform = "osx-arm64"; // Apple Silicon
                }
                else
                {
                    platform = "osx-x64"; // Intel Mac
                }
            }
            else // Linux (if Unity ever supports it for this tool)
            {
                platform = "linux-x64";
            }

            string filename = Application.platform == RuntimePlatform.WindowsEditor
                ? "SceneMergeTool.exe"
                : "SceneMergeTool";

            return Path.Combine(packagePath, "CLI~", platform, filename);
        }

        private static string GetPackageVersion()
        {
            var packageInfo = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SceneMergeInstaller).Assembly);
            return packageInfo?.version ?? "0.0.0";
        }

        // Returned by ConfigureGit/ReconfigureGit when the project has no git repo yet.
        // Not an error — git config will succeed once the repo is initialized.
        public const string GIT_ERROR_NOT_A_REPO = "NOT_IN_GIT_REPO";

        // Public API for status checking (used by status window)
        public static bool IsInstalled() => IsToolInstalled();
        public static string GetInstalledToolPath() => ToolExecutable;
        public static bool IsGitConfigured() => EditorPrefs.GetString(PREF_KEY_GIT_CONFIG_OK, "") == "true";
        public static string GetGitConfigError() => EditorPrefs.GetString(PREF_KEY_GIT_CONFIG_ERROR, "");

        /// <summary>Re-runs git configuration and updates stored status. Returns null on success.</summary>
        public static string ReconfigureGit()
        {
            string error = ConfigureGit();
            if (string.IsNullOrEmpty(error))
            {
                EditorPrefs.SetString(PREF_KEY_GIT_CONFIG_OK, "true");
                EditorPrefs.DeleteKey(PREF_KEY_GIT_CONFIG_ERROR);
            }
            else
            {
                EditorPrefs.DeleteKey(PREF_KEY_GIT_CONFIG_OK);
                EditorPrefs.SetString(PREF_KEY_GIT_CONFIG_ERROR, error);
            }
            return error;
        }

        // Manual installation trigger for debugging
        [MenuItem("Tools/Overdrive/Scene Merge/Force Reinstall CLI Tool")]
        public static void ForceReinstall()
        {
            Debug.Log("[Scene Merge] === Manual Installation Triggered ===");
            Debug.Log($"[Scene Merge] Install Directory: {InstallDir}");
            Debug.Log($"[Scene Merge] Tool Executable Path: {ToolExecutable}");
            Debug.Log($"[Scene Merge] Tool Installed: {IsToolInstalled()}");

            // Get bundled path
            string bundledPath = GetBundledExecutablePath();
            Debug.Log($"[Scene Merge] Bundled Executable Path: {bundledPath}");
            Debug.Log($"[Scene Merge] Bundled Executable Exists: {File.Exists(bundledPath)}");

            // Force install
            InstallTool(GetPackageVersion());
        }
    }
}
