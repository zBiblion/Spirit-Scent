using UnityEditor;
using UnityEngine;
using System;
using System.IO;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Handles Git operations and Unity tool discovery for scene merge functionality.
    /// </summary>
    public static class SceneMergeGitOperations
    {
        /// <summary>
        /// Runs a Git command in the given working directory.
        /// Returns trimmed stdout on success, null on failure.
        /// </summary>
        public static string RunGit(string args, string workingDir)
        {
            var psi = new System.Diagnostics.ProcessStartInfo("git", args)
            {
                WorkingDirectory       = workingDir,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                UseShellExecute        = false,
                CreateNoWindow         = true
            };
            using var proc = System.Diagnostics.Process.Start(psi);
            string output = proc.StandardOutput.ReadToEnd();
            string error = proc.StandardError.ReadToEnd();
            proc.WaitForExit();
            if (proc.ExitCode != 0)
            {
                Debug.LogWarning($"[SceneMerge] Git command failed: git {args}\nError: {error}");
            }
            return proc.ExitCode == 0 ? output.Trim() : null;
        }

        /// <summary>
        /// Runs a Git command and returns the error message (if any) instead of throwing.
        /// </summary>
        public static string RunGitWithError(string args, string workingDir)
        {
            var psi = new System.Diagnostics.ProcessStartInfo("git", args)
            {
                WorkingDirectory       = workingDir,
                RedirectStandardOutput = true,
                RedirectStandardError  = true,
                UseShellExecute        = false,
                CreateNoWindow         = true
            };
            using var proc = System.Diagnostics.Process.Start(psi);
            string output = proc.StandardOutput.ReadToEnd();
            string error = proc.StandardError.ReadToEnd();
            proc.WaitForExit();
            return proc.ExitCode != 0 ? error : null;
        }

        /// <summary>
        /// Locates the UnityYAMLMerge executable for the current Unity installation.
        /// </summary>
        public static string FindUnityYAMLMerge()
        {
            // Get Unity Editor path from EditorApplication.applicationPath
            // e.g., "C:\Program Files\Unity\Hub\Editor\6000.3.7f1\Editor\Unity.exe"
            string unityEditorPath = EditorApplication.applicationPath;
            
            if (string.IsNullOrEmpty(unityEditorPath) || !File.Exists(unityEditorPath))
                return null;

            // Go up to the Editor folder
            string editorDir = Path.GetDirectoryName(unityEditorPath);
            
            // UnityYAMLMerge is in Editor/Data/Tools/UnityYAMLMerge.exe on Windows
            // or Editor/Data/Tools/UnityYAMLMerge on Mac
            string toolsDir = Path.Combine(editorDir, "Data", "Tools");
            
            string yamlMergePath;
            if (Application.platform == RuntimePlatform.WindowsEditor)
                yamlMergePath = Path.Combine(toolsDir, "UnityYAMLMerge.exe");
            else
                yamlMergePath = Path.Combine(toolsDir, "UnityYAMLMerge");

            if (File.Exists(yamlMergePath))
                return yamlMergePath;

            // Fallback: check UNITY_YAML_MERGE environment variable
            string envPath = Environment.GetEnvironmentVariable("UNITY_YAML_MERGE");
            if (!string.IsNullOrEmpty(envPath) && File.Exists(envPath))
                return envPath;

            return null;
        }
    }
}
