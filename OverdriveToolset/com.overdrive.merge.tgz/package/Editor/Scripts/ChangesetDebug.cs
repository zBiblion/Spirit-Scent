using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    // -----------------------------------------------------------------------
    // Debug-only: shows all changes Ours/Theirs made vs Base, independently
    // of the conflict detection system.  Remove this file (and the handful of
    // call-sites in BlockConflictWindow) when no longer needed.
    // -----------------------------------------------------------------------

    public class ChangeEntry
    {
        public string BlockId     { get; set; }
        public string BlockType   { get; set; }
        public string SourceName  { get; set; }
        public string PropertyName { get; set; }
        public string BaseValue   { get; set; }
        public string NewValue    { get; set; }
        public bool   IsAdded     { get; set; } // block absent in base
        public bool   IsDeleted   { get; set; } // block absent in target
    }

    public static class ChangesetDebug
    {
        public static List<ChangeEntry> lastOurChanges   = new();
        public static List<ChangeEntry> lastTheirChanges = new();

        public static void Compute(string basePath, string oursPath, string theirsPath)
        {
            var baseBlocks  = BlockComparison.BlockParser.ParseBlocks(File.ReadAllText(basePath));
            var ourBlocks   = BlockComparison.BlockParser.ParseBlocks(File.ReadAllText(oursPath));
            var theirBlocks = BlockComparison.BlockParser.ParseBlocks(File.ReadAllText(theirsPath));

            // Re-use AllBlocksReference already populated by the conflict pass —
            // no need to rebuild it; SourceName resolution works for free.

            lastOurChanges   = ComputeChanges(ourBlocks,   baseBlocks, label: "Ours");
            lastTheirChanges = ComputeChanges(theirBlocks, baseBlocks, label: "Theirs");
        }

        private static List<ChangeEntry> ComputeChanges(
            List<BlockComparison.Block> targetBlocks,
            List<BlockComparison.Block> baseBlocks,
            string label)
        {
            var entries = new List<ChangeEntry>();
            var baseDict   = baseBlocks.ToDictionary(b => b.Id);
            var targetDict = targetBlocks.ToDictionary(b => b.Id);

            // Additions
            foreach (var block in targetBlocks)
            {
                if (baseDict.ContainsKey(block.Id)) continue;
                entries.Add(new ChangeEntry
                {
                    BlockId    = block.Id,
                    BlockType  = block.BlockType,
                    SourceName = block.SourceName,
                    IsAdded    = true,
                });
            }

            // Modifications
            foreach (var block in targetBlocks)
            {
                if (!baseDict.TryGetValue(block.Id, out var baseBlock)) continue;
                if (block.Content == baseBlock.Content) continue;

                if (block.BlockType == "PrefabInstance")
                    entries.AddRange(PrefabModificationChanges(block, baseBlock));
                else
                    entries.AddRange(PropertyChanges(block, baseBlock));
            }

            // Deletions
            foreach (var block in baseBlocks)
            {
                if (targetDict.ContainsKey(block.Id)) continue;
                entries.Add(new ChangeEntry
                {
                    BlockId    = block.Id,
                    BlockType  = block.BlockType,
                    SourceName = block.SourceName,
                    IsDeleted  = true,
                });
            }

            return entries;
        }

        // ── PrefabInstance: one entry per modified propertyPath ──────────────

        private static IEnumerable<ChangeEntry> PrefabModificationChanges(
            BlockComparison.Block target, BlockComparison.Block baseBlock)
        {
            var baseMods   = ParsePrefabMods(baseBlock.Content);
            var targetMods = ParsePrefabMods(target.Content);

            // Changed or added overrides
            foreach (var kvp in targetMods)
            {
                baseMods.TryGetValue(kvp.Key, out var baseVal);
                if (baseVal == kvp.Value) continue;

                var colonIdx = kvp.Key.IndexOf(':');
                yield return new ChangeEntry
                {
                    BlockId      = target.Id,
                    BlockType    = "PrefabInstance",
                    SourceName   = target.SourceName,
                    PropertyName = kvp.Key[(colonIdx + 1)..],
                    BaseValue    = baseVal ?? "",
                    NewValue     = kvp.Value,
                };
            }

            // Removed overrides
            foreach (var kvp in baseMods)
            {
                if (targetMods.ContainsKey(kvp.Key)) continue;
                var colonIdx = kvp.Key.IndexOf(':');
                yield return new ChangeEntry
                {
                    BlockId      = target.Id,
                    BlockType    = "PrefabInstance",
                    SourceName   = target.SourceName,
                    PropertyName = kvp.Key[(colonIdx + 1)..],
                    BaseValue    = kvp.Value,
                    NewValue     = "",
                };
            }
        }

        // ── Regular blocks: one entry per differing property line ────────────

        private static IEnumerable<ChangeEntry> PropertyChanges(
            BlockComparison.Block target, BlockComparison.Block baseBlock)
        {
            var diffProps = target.GetDifferingProperties(baseBlock);
            foreach (var prop in diffProps)
            {
                var baseVal   = ExtractPropertyValue(baseBlock.Content, prop);
                var targetVal = ExtractPropertyValue(target.Content,    prop);
                if (baseVal == targetVal) continue; // line-index false positive

                yield return new ChangeEntry
                {
                    BlockId      = target.Id,
                    BlockType    = target.BlockType,
                    SourceName   = target.SourceName,
                    PropertyName = prop,
                    BaseValue    = baseVal,
                    NewValue     = targetVal,
                };
            }
        }

        // ── Helpers (self-contained copies — no dependency on BlockComparison) ─

        private static Dictionary<string, string> ParsePrefabMods(string content)
        {
            var result        = new Dictionary<string, string>();
            var propPathRegex = new Regex(@"propertyPath:\s*(.+)");
            var valueRegex    = new Regex(@"^[ \t]+value:\s*(.+)", RegexOptions.Multiline);

            foreach (var entry in Regex.Split(content, @"(?=- target:)"))
            {
                if (!entry.TrimStart().StartsWith("- target:")) continue;

                var fileIdMatch = Regex.Match(entry, @"fileID:\s*(\d+)");
                var propMatch   = propPathRegex.Match(entry);
                var valueMatch  = valueRegex.Match(entry);

                if (!fileIdMatch.Success || !propMatch.Success || !valueMatch.Success) continue;

                var key = $"{fileIdMatch.Groups[1].Value}:{propMatch.Groups[1].Value.Trim()}";
                result[key] = valueMatch.Groups[1].Value.Trim();
            }

            return result;
        }

        private static string ExtractPropertyValue(string content, string propertyName)
        {
            var match = Regex.Match(content, $@"{propertyName}:\s*(.+?)(?:\n|$)");
            return match.Success ? match.Groups[1].Value.Trim() : "";
        }
    }
}
