using UnityEngine;
using System;
using System.IO;
using System.Linq;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Handles logging and diagnostic output for scene merge operations.
    /// </summary>
    public static class SceneMergeLogger
    {
        public static void WriteComparisonLog(YAMLCompare comparison, string fetchError)
        {
            if (comparison == null) return;

            var logPath = Path.Combine(Application.dataPath, "Merge Testing", "SceneMergeComparison.log");
            var logDir = Path.GetDirectoryName(logPath);
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            using (var logWriter = new StreamWriter(logPath, false))
            {
                logWriter.WriteLine("=== Scene Merge Comparison Results ===");
                logWriter.WriteLine($"Timestamp: {System.DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                logWriter.WriteLine();

                if (!string.IsNullOrEmpty(fetchError))
                {
                    logWriter.WriteLine("GIT FETCH ERROR:");
                    logWriter.WriteLine(fetchError);
                    logWriter.WriteLine();
                }

                logWriter.WriteLine($"Total changes detected: {comparison.changes.Count}");
                logWriter.WriteLine($"Base blocks: {comparison.baseBlocks?.Count ?? 0}");
                logWriter.WriteLine($"Ours blocks: {comparison.oursBlocks?.Count ?? 0}");
                logWriter.WriteLine($"Theirs blocks: {comparison.theirsBlocks?.Count ?? 0}");
                logWriter.WriteLine();

                if (comparison.changes.Count == 0)
                {
                    logWriter.WriteLine("No changes detected.");
                    Debug.Log($"[SceneMerge] Comparison log written to: {logPath}");
                    return;
                }

                // Summary by change type
                var byType = comparison.changes.GroupBy(c => c.changeType).ToDictionary(g => g.Key, g => g.Count());
                logWriter.WriteLine("Changes by type:");
                foreach (var kvp in byType)
                    logWriter.WriteLine($"  {kvp.Key}: {kvp.Value}");
                logWriter.WriteLine();

                // Summary by category
                var byCategory = comparison.changes.GroupBy(c => c.blockCategory).ToDictionary(g => g.Key, g => g.Count());
                logWriter.WriteLine("Changes by category:");
                foreach (var kvp in byCategory)
                    logWriter.WriteLine($"  {kvp.Key}: {kvp.Value}");
                logWriter.WriteLine();

                // Detailed change list
                logWriter.WriteLine("=== DETAILED CHANGE LIST ===");
                logWriter.WriteLine();

                foreach (var change in comparison.changes.OrderBy(c => c.blockCategory).ThenBy(c => c.blockName ?? c.blockType))
                {
                    logWriter.WriteLine($"[{change.changeType}] {change.blockCategory} - {change.blockName ?? change.blockType}");
                    logWriter.WriteLine($"  Block ID: {change.blockID}");
                    logWriter.WriteLine($"  Block Type: {change.blockType}");
                    
                    if (!string.IsNullOrEmpty(change.parentGoID))
                        logWriter.WriteLine($"  Parent GO ID: {change.parentGoID}");
                    
                    if (change.isArrayChange)
                        logWriter.WriteLine($"  Array Change: true");
                    
                    if (change.conflictingProperties != null && change.conflictingProperties.Count > 0)
                        logWriter.WriteLine($"  Conflicting Properties: {string.Join(", ", change.conflictingProperties)}");

                    if (change.changeType == YAMLCompare.ChangeType.Modified || change.changeType == YAMLCompare.ChangeType.Conflict)
                    {
                        logWriter.WriteLine($"  Base content length: {change.baseContent?.Length ?? 0}");
                        logWriter.WriteLine($"  Ours content length: {change.oursContent?.Length ?? 0}");
                        logWriter.WriteLine($"  Theirs content length: {change.theirsContent?.Length ?? 0}");

                        if (change.oursContent != null && change.theirsContent != null)
                        {
                            // Show first few lines of each version for debugging
                            logWriter.WriteLine("  Ours (first 3 lines):");
                            WriteFirstLines(logWriter, change.oursContent, 3);
                            logWriter.WriteLine("  Theirs (first 3 lines):");
                            WriteFirstLines(logWriter, change.theirsContent, 3);
                        }
                    }
                    else if (change.changeType == YAMLCompare.ChangeType.Added)
                    {
                        logWriter.WriteLine($"  Content length: {change.theirsContent?.Length ?? 0}");
                    }
                    else if (change.changeType == YAMLCompare.ChangeType.Deleted)
                    {
                        logWriter.WriteLine($"  Content length: {change.oursContent?.Length ?? 0}");
                    }

                    logWriter.WriteLine();
                }

                // Stripped blocks info
                var strippedBlocks = comparison.oursBlocks.Values
                    .Concat(comparison.theirsBlocks.Values)
                    .Where(b => b.category == YAMLCompare.BlockCategory.Stripped)
                    .ToList();
                
                if (strippedBlocks.Count > 0)
                {
                    logWriter.WriteLine("=== STRIPPED BLOCKS ===");
                    logWriter.WriteLine($"Total stripped blocks: {strippedBlocks.Count}");
                    foreach (var block in strippedBlocks.Take(10))
                        logWriter.WriteLine($"  ID {block.fileID}: {block.name ?? block.objectType}");
                    if (strippedBlocks.Count > 10)
                        logWriter.WriteLine($"  ... and {strippedBlocks.Count - 10} more");
                    logWriter.WriteLine();
                }
            }

            Debug.Log($"[SceneMerge] Comparison log written to: {logPath}");
        }

        public static void WriteFirstLines(StreamWriter writer, string content, int lineCount)
        {
            if (string.IsNullOrEmpty(content)) return;
            
            var lines = content.Split('\n');
            for (int i = 0; i < Math.Min(lineCount, lines.Length); i++)
                writer.WriteLine($"    {lines[i]}");
        }

        public static string TruncateForLog(string value, int maxLength = 60)
        {
            if (string.IsNullOrEmpty(value)) return "(null)";
            if (value.Length <= maxLength) return value;
            return value.Substring(0, maxLength) + "...";
        }
    }
}
