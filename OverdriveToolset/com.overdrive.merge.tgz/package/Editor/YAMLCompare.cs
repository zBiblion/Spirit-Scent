using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    // This class compares YAML scene/prefab files and shows ALL changes as raw blocks

    public class YAMLCompare
    {
        // Compiled at class load — used in the hot parse loop (potentially 100k+ blocks)
        private static readonly Regex BlockSplitRegex       = new(@"(?=^--- !u!)",                                        RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex BlockHeaderRegex      = new(@"^--- !u!(\d+) &(\d+)(.*)",                            RegexOptions.Compiled);
        private static readonly Regex ObjectTypeRegex       = new(@"^--- !u!\d+ &\d+.*\n(\w+):",                          RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex NameRegex             = new(@"m_Name:\s*(.+)",                                       RegexOptions.Compiled);
        private static readonly Regex SourcePrefabGuidRegex = new(@"m_SourcePrefab:\s*\{fileID:\s*\d+,\s*guid:\s*([a-f0-9]+)", RegexOptions.Compiled);
        private static readonly Regex GameObjectRefRegex    = new(@"m_GameObject:\s*\{fileID:\s*(\d+)\}",                  RegexOptions.Compiled);
        private static readonly Regex EditorClassIdRegex    = new(@"m_EditorClassIdentifier:\s*[^:]*::(\w+)",              RegexOptions.Compiled);

        private const string test_BasePath = "Assets/Merge Testing/MergeTest_Base.unity";
        private const string test_OursPath = "Assets/Merge Testing/MergeTest_Ours.unity";
        private const string test_TheirsPath = "Assets/Merge Testing/MergeTest_Theirs.unity";

        public enum BlockCategory
        {
            SceneSettings,   // fileID has 1-2 digits (scene-level settings)
            SceneRoots,      // typeID 1660057539
            Stripped,        // header contains "stripped" (prefab overrides inside a scene)
            GameObject,      // typeID 1
            PrefabInstance,  // typeID 1001
            Secondary        // everything else (components, assets, etc)
        }

        public class YAMLBlock
        {
            public string typeID;            // Unity type ID (1=GameObject, 4=Transform, etc)
            public string fileID;            // File ID reference
            public string objectType;        // Object type name (GameObject, Transform, etc)
            public string fullContent;       // Complete YAML block content
            public string name;              // Extracted name if available
            public BlockCategory category;   // Categorized block type
            public string parentGoID;        // For Secondary blocks: fileID of the owner GameObject
        }

        public static void TestPreviewPullChanges()
        {
            // Test implementation using all three hardcoded test files (3-way)
            string baseAbsPath   = GetAbsolutePath(test_BasePath);
            string oursAbsPath   = GetAbsolutePath(test_OursPath);
            string theirsAbsPath = GetAbsolutePath(test_TheirsPath);

            if (!File.Exists(baseAbsPath))
            {
                Debug.LogError($"Test file not found: {baseAbsPath}");
                return;
            }
            if (!File.Exists(oursAbsPath))
            {
                Debug.LogError($"Test file not found: {oursAbsPath}");
                return;
            }
            if (!File.Exists(theirsAbsPath))
            {
                Debug.LogError($"Test file not found: {theirsAbsPath}");
                return;
            }

            var comparison = new YAMLCompare();
            comparison.CompareFiles(baseAbsPath, oursAbsPath, theirsAbsPath);
            PullPreviewWindow.ShowWindow(comparison);
        }

        public static void TestPreviewPullChangesRaw()
        {
            // Test implementation for raw diff window (3-way, zero filtering)
            string baseAbsPath   = GetAbsolutePath(test_BasePath);
            string oursAbsPath   = GetAbsolutePath(test_OursPath);
            string theirsAbsPath = GetAbsolutePath(test_TheirsPath);

            if (!File.Exists(baseAbsPath))
            {
                Debug.LogError($"Test file not found: {baseAbsPath}");
                return;
            }
            if (!File.Exists(oursAbsPath))
            {
                Debug.LogError($"Test file not found: {oursAbsPath}");
                return;
            }
            if (!File.Exists(theirsAbsPath))
            {
                Debug.LogError($"Test file not found: {theirsAbsPath}");
                return;
            }

            var comparison = new YAMLCompareSimple();
            comparison.CompareFiles(baseAbsPath, oursAbsPath, theirsAbsPath);
            PullPreviewSimpleWindow.ShowWindow(comparison);
        }

        public static void PreviewPullChanges(string oursPath, string theirsPath)
        {
            // Main implementation for comparing any two scene/prefab files
            string oursAbsPath = GetAbsolutePath(oursPath);
            string theirsAbsPath = GetAbsolutePath(theirsPath);

            if (!File.Exists(oursAbsPath))
            {
                Debug.LogError($"File not found: {oursAbsPath}");
                return;
            }
            if (!File.Exists(theirsAbsPath))
            {
                Debug.LogError($"File not found: {theirsAbsPath}");
                return;
            }

            var comparison = new YAMLCompare();
            comparison.CompareFiles(oursAbsPath, theirsAbsPath);
            PullPreviewWindow.ShowWindow(comparison);
        }

        private static string GetAbsolutePath(string assetPath)
        {
            // Convert Unity relative path (Assets/...) to absolute file system path
            if (assetPath.StartsWith("Assets/"))
            {
                return Path.Combine(Application.dataPath, assetPath.Substring(7));
            }
            return assetPath;
        }

        public Dictionary<string, YAMLBlock> baseBlocks  = new Dictionary<string, YAMLBlock>();
        public Dictionary<string, YAMLBlock> oursBlocks  = new Dictionary<string, YAMLBlock>();
        public Dictionary<string, YAMLBlock> theirsBlocks = new Dictionary<string, YAMLBlock>();
        public List<ChangeInfo> changes = new List<ChangeInfo>();
        
        // Paths to the source files (needed for fixing ID collisions)
        public string basePath;
        public string oursPath;
        public string theirsPath;

        public enum ChangeType
        {
            Added,      // In Theirs but not in Ours (or Base)
            Deleted,    // Theirs deleted something we still have unchanged
            Modified,   // Only Theirs changed from Base (clean incoming)
            Conflict    // Both Ours and Theirs diverged from Base differently
        }

        public enum ConflictResolution
        {
            None,
            Ours,
            Theirs
        }

        public class PropertyDiff
        {
            public string propertyName;      // Property key (e.g., "m_IsTrigger")
            public string oursValue;         // Value in our version (null if not present)
            public string theirsValue;       // Value in their version (null if not present)
            public bool isConflict;          // True if both sides modified to different values
            public bool isArrayProperty;     // True if this is an array property
        }

        public class ChangeInfo
        {
            public ChangeType changeType;
            public BlockCategory blockCategory;  // Category of this block
            public string blockID;               // The file ID of the block
            public string blockType;             // Type name (GameObject, Transform, etc)
            public string blockName;             // Name if available
            public string oursContent;           // Full content from Ours
            public string theirsContent;         // Full content from Theirs
            public string baseContent;           // Full content from Base (null if not present in base)
            public string parentGoID;            // For Secondary blocks: fileID of the owner GameObject
            public bool isArrayChange;           // True if change involves array properties (Unity handles these well)
            public bool isSceneRoots;            // True if this is a SceneRoots block (scene ordering metadata)
            public List<string> conflictingProperties;  // Properties that have true conflicts (both sides modified)
            public List<PropertyDiff> propertyDiffs;     // Computed property-level diffs for display
            public bool hasIDCollision;          // True if same fileID has different ClassID (typeID) in ours vs theirs
            public string oursTypeID;            // Our ClassID/typeID
            public string theirsTypeID;          // Their ClassID/typeID
            public ConflictResolution conflictResolution; // Expected winner for conflict cases
        }

        public void CompareFiles(string oursPath, string theirsPath)
        {
            // 2-way: load and parse both files
            this.oursPath = oursPath;
            this.theirsPath = theirsPath;
            
            string oursContent   = File.ReadAllText(oursPath);
            string theirsContent = File.ReadAllText(theirsPath);

            oursBlocks   = ParseYAMLBlocks(oursContent);
            theirsBlocks = ParseYAMLBlocks(theirsContent);

            CompareBlocks();
        }

        public void CompareFiles(string basePath, string oursPath, string theirsPath)
        {
            // 3-way: load and parse all three files
            this.basePath = basePath;
            this.oursPath = oursPath;
            this.theirsPath = theirsPath;
            
            string baseContent   = File.ReadAllText(basePath);
            string oursContent   = File.ReadAllText(oursPath);
            string theirsContent = File.ReadAllText(theirsPath);

            baseBlocks   = ParseYAMLBlocks(baseContent);
            oursBlocks   = ParseYAMLBlocks(oursContent);
            theirsBlocks = ParseYAMLBlocks(theirsContent);

            CompareBlocksThreeWay();
        }

        private static BlockCategory CategorizeBlock(string typeID, string fileID, bool isStripped)
        {
            if (isStripped)              return BlockCategory.Stripped;
            if (fileID.Length <= 2)      return BlockCategory.SceneSettings;
            if (typeID == "1660057539")  return BlockCategory.SceneRoots;
            if (typeID == "1")           return BlockCategory.GameObject;
            if (typeID == "1001")        return BlockCategory.PrefabInstance;
            return BlockCategory.Secondary;
        }

        private Dictionary<string, YAMLBlock> ParseYAMLBlocks(string yamlContent)
        {
            var blocks = new Dictionary<string, YAMLBlock>();

            // Split by document separator (--- !u!)
            var documents = BlockSplitRegex.Split(yamlContent);

            foreach (var doc in documents)
            {
                if (string.IsNullOrWhiteSpace(doc)) continue;

                // Match: --- !u!TYPE_ID &FILE_ID [optional: stripped]
                var headerMatch = BlockHeaderRegex.Match(doc);
                if (!headerMatch.Success) continue;

                string typeID = headerMatch.Groups[1].Value;
                string fileID = headerMatch.Groups[2].Value;
                bool isStripped = headerMatch.Groups[3].Value.Contains("stripped");

                // Get the object type from the next line
                var typeLineMatch = ObjectTypeRegex.Match(doc);
                string objectType = typeLineMatch.Success ? typeLineMatch.Groups[1].Value : $"Type{typeID}";

                // Try to extract a name
                string name = null;
                var nameMatch = NameRegex.Match(doc);
                if (nameMatch.Success)
                {
                    name = nameMatch.Groups[1].Value.Trim();
                    if (string.IsNullOrEmpty(name))
                        name = null;
                }

                // MonoBehaviour blocks (typeID 114) — always extract script class name from m_EditorClassIdentifier
                if (typeID == "114")
                {
                    var classIdMatch = EditorClassIdRegex.Match(doc);
                    if (classIdMatch.Success)
                    {
                        name = classIdMatch.Groups[1].Value;
                    }
                    else
                    {
                        Debug.Log($"[YAMLCompare] MonoBehaviour block {fileID} has no m_EditorClassIdentifier match");
                    }
                }

                // PrefabInstance blocks have no m_Name — resolve from source prefab GUID
                if (name == null && typeID == "1001")
                {
                    var guidMatch = SourcePrefabGuidRegex.Match(doc);
                    if (guidMatch.Success)
                    {
                        string assetPath = AssetDatabase.GUIDToAssetPath(guidMatch.Groups[1].Value);
                        if (!string.IsNullOrEmpty(assetPath))
                            name = Path.GetFileNameWithoutExtension(assetPath);
                    }
                }

                // Try to extract the owner GameObject reference (present on component blocks)
                string parentGoID = null;
                var goRefMatch = GameObjectRefRegex.Match(doc);
                if (goRefMatch.Success)
                    parentGoID = goRefMatch.Groups[1].Value;

                var block = new YAMLBlock
                {
                    typeID = typeID,
                    fileID = fileID,
                    objectType = objectType,
                    fullContent = doc,
                    name = name,
                    category = CategorizeBlock(typeID, fileID, isStripped),
                    parentGoID = parentGoID
                };

                blocks[fileID] = block;
            }

            return blocks;
        }

        private void CompareBlocks()
        {
            changes.Clear();
            int added = 0, modified = 0, deleted = 0;

            // Single pass over ours: find Deleted and Modified
            foreach (var kvp in oursBlocks)
            {
                if (!theirsBlocks.TryGetValue(kvp.Key, out var theirsBlock))
                {
                    changes.Add(new ChangeInfo
                    {
                        changeType    = ChangeType.Deleted,
                        blockCategory = kvp.Value.category,
                        blockID       = kvp.Key,
                        blockType     = kvp.Value.objectType,
                        blockName     = kvp.Value.name,
                        oursContent   = kvp.Value.fullContent,
                        parentGoID    = kvp.Value.parentGoID
                    });
                    deleted++;
                }
                else if (kvp.Value.fullContent != theirsBlock.fullContent)
                {
                    changes.Add(new ChangeInfo
                    {
                        changeType    = ChangeType.Modified,
                        blockCategory = kvp.Value.category,
                        blockID       = kvp.Key,
                        blockType     = kvp.Value.objectType,
                        blockName     = kvp.Value.name ?? theirsBlock.name,
                        oursContent   = kvp.Value.fullContent,
                        theirsContent = theirsBlock.fullContent,
                        parentGoID    = kvp.Value.parentGoID ?? theirsBlock.parentGoID
                    });
                    modified++;
                }
            }

            // Second pass over theirs: find Added (blocks absent from ours)
            foreach (var kvp in theirsBlocks)
            {
                if (!oursBlocks.ContainsKey(kvp.Key))
                {
                    changes.Add(new ChangeInfo
                    {
                        changeType    = ChangeType.Added,
                        blockCategory = kvp.Value.category,
                        blockID       = kvp.Key,
                        blockType     = kvp.Value.objectType,
                        blockName     = kvp.Value.name,
                        theirsContent = kvp.Value.fullContent,
                        parentGoID    = kvp.Value.parentGoID
                    });
                    added++;
                }
            }
        }

        private void CompareBlocksThreeWay()
        {
            changes.Clear();
            int added = 0, modified = 0, deleted = 0, conflict = 0;

            var allIds = new HashSet<string>();
            allIds.UnionWith(baseBlocks.Keys);
            allIds.UnionWith(oursBlocks.Keys);
            allIds.UnionWith(theirsBlocks.Keys);

            // Track conflicting properties for current iteration
            List<string> conflictingProperties = null;

            foreach (var id in allIds)
            {
                bool inBase   = baseBlocks.TryGetValue(id,   out var baseBlock);
                bool inOurs   = oursBlocks.TryGetValue(id,   out var oursBlock);
                bool inTheirs = theirsBlocks.TryGetValue(id, out var theirsBlock);

                string baseContent   = baseBlock?.fullContent;
                string oursContent   = oursBlock?.fullContent;
                string theirsContent = theirsBlock?.fullContent;

                bool oursMatchesBase   = inBase && inOurs   && oursContent   == baseContent;
                bool theirsMatchesBase = inBase && inTheirs && theirsContent == baseContent;
                bool oursMatchesTheirs = inOurs && inTheirs && oursContent   == theirsContent;

                ChangeType? type = null;
                conflictingProperties = null;  // Reset for each block
                bool hasIDCollision = false;

                if (!inBase)
                {
                    // Not in common ancestor — new in ours and/or theirs
                    if      (!inOurs)              type = ChangeType.Added;        // only in theirs — incoming addition
                    else if (!inTheirs)            continue;                       // only in ours — our local addition
                    else if (oursMatchesTheirs)    continue;                       // same addition both sides
                    else
                    {
                        // Both added with different content - check for ID collision
                        type = ChangeType.Conflict;
                        if (oursBlock.typeID != theirsBlock.typeID)
                        {
                            hasIDCollision = true;  // Same fileID, different ClassID - CRITICAL
                            Debug.LogError($"[YAMLCompare] ID COLLISION: Block {id} has different ClassIDs - Ours: {oursBlock.typeID} ({oursBlock.objectType}), Theirs: {theirsBlock.typeID} ({theirsBlock.objectType})");
                        }
                    }
                }
                else if (!inOurs && !inTheirs)     continue;                       // both deleted
                else if (!inOurs)
                {
                    // We deleted it; theirs still has it
                    if (theirsMatchesBase)         continue;                       // theirs unchanged — our deletion stands
                    else                           type = ChangeType.Conflict;     // they modified what we deleted
                }
                else if (!inTheirs)
                {
                    // Theirs deleted it; we still have it
                    if (oursMatchesBase)           type = ChangeType.Deleted;      // clean incoming delete
                    else                           type = ChangeType.Conflict;     // we modified what they deleted
                }
                else
                {
                    // Present in all three
                    if (oursMatchesBase && theirsMatchesBase) continue;            // unchanged
                    if (oursMatchesTheirs)         continue;                       // same change both sides
                    if (oursMatchesBase)           type = ChangeType.Modified;     // only theirs changed (clean)
                    else if (theirsMatchesBase)    continue;                       // only ours changed — local change, no incoming
                    else
                    {
                        // Both changed — check property-level conflicts
                        var conflictingProps = GetConflictingProperties(baseContent, oursContent, theirsContent);
                        if (conflictingProps.Count > 0)
                        {
                            type = ChangeType.Conflict;     // same property modified by both sides
                            conflictingProperties = conflictingProps;
                        }
                        else
                            type = ChangeType.Modified;     // different properties modified (clean merge)
                    }
                }

                var rep = oursBlock ?? theirsBlock ?? baseBlock;
                bool isArrayChange = (type == ChangeType.Conflict || type == ChangeType.Modified) 
                                     && HasArrayPropertyChanges(baseContent, oursContent, theirsContent);
                bool prefabOverrideConflict = rep.category == BlockCategory.PrefabInstance
                                              && PrefabOverridesLastWins(baseContent, oursContent, theirsContent);

                var finalType = type.Value;
                if (prefabOverrideConflict)
                {
                    finalType = ChangeType.Conflict;
                }
                else if (type == ChangeType.Conflict && isArrayChange)
                {
                    finalType = ChangeType.Modified; // array merges are usually clean
                }

                var conflictResolution = ConflictResolution.None;
                if (finalType == ChangeType.Conflict)
                {
                    if (oursContent == null)
                        conflictResolution = ConflictResolution.Ours;    // ours deleted -> deletion wins -> ours kept
                    else if (theirsContent == null)
                        conflictResolution = ConflictResolution.Theirs;  // theirs deleted -> deletion wins -> theirs kept
                    else
                        conflictResolution = ConflictResolution.Ours;    // property conflicts: ours wins

                    if (prefabOverrideConflict)
                        conflictResolution = ConflictResolution.Theirs;
                }
                
                // Compute property diffs for Modified/Conflict changes
                List<PropertyDiff> propertyDiffs = null;
                if ((finalType == ChangeType.Modified || finalType == ChangeType.Conflict))
                {
                    if (oursContent != null && theirsContent != null)
                    {
                        // Normal case: both versions exist
                        propertyDiffs = ComputePropertyDiffs(baseContent, oursContent, theirsContent, 
                            conflictingProperties != null ? new HashSet<string>(conflictingProperties) : null);
                    }
                    else if (finalType == ChangeType.Conflict)
                    {
                        // Deletion conflict: compute diffs from base to the version that exists
                        if (oursContent != null && baseContent != null)
                        {
                            // They deleted, we modified - show our changes
                            propertyDiffs = ComputePropertyDiffsFromBase(baseContent, oursContent, fromOurs: true);
                        }
                        else if (theirsContent != null && baseContent != null)
                        {
                            // We deleted, they modified - show their changes
                            propertyDiffs = ComputePropertyDiffsFromBase(baseContent, theirsContent, fromOurs: false);
                        }
                    }
                }

                if (prefabOverrideConflict)
                {
                    var prefabDiffs = BuildPrefabOverrideDiffs(baseContent, oursContent, theirsContent);
                    if (prefabDiffs.Count > 0)
                    {
                        if (propertyDiffs == null || propertyDiffs.Count == 0)
                        {
                            propertyDiffs = prefabDiffs;
                        }
                        else
                        {
                            propertyDiffs.AddRange(prefabDiffs);
                        }
                    }
                }
                
                // Ensure deletion conflicts always have at least one property diff for visibility
                if (finalType == ChangeType.Conflict && (oursContent == null || theirsContent == null))
                {
                    if (propertyDiffs == null || propertyDiffs.Count == 0)
                    {
                        string conflictDesc = oursContent == null 
                            ? "Deleted in Ours, Modified in Theirs" 
                            : "Modified in Ours, Deleted in Theirs";
                        
                        propertyDiffs = new List<PropertyDiff>
                        {
                            new PropertyDiff
                            {
                                propertyName = $"⚠️ Deletion Conflict: {conflictDesc}",
                                oursValue = oursContent == null ? null : "[Block exists with modifications]",
                                theirsValue = theirsContent == null ? null : "[Block exists with modifications]",
                                isConflict = true,
                                isArrayProperty = false
                            }
                        };
                    }
                }
                
                changes.Add(new ChangeInfo
                {
                    changeType    = finalType,  // Treat array additions/changes as modified (clean merge)
                    blockCategory = rep.category,
                    blockID       = id,
                    blockType     = rep.objectType,
                    blockName     = oursBlock?.name ?? theirsBlock?.name ?? baseBlock?.name,
                    oursContent   = oursContent,
                    theirsContent = theirsContent,
                    baseContent   = baseContent,
                    parentGoID    = rep.parentGoID,
                    isArrayChange = isArrayChange,
                    isSceneRoots  = rep.category == BlockCategory.SceneRoots,
                    conflictingProperties = conflictingProperties,
                    propertyDiffs = propertyDiffs,
                    hasIDCollision = hasIDCollision,
                    oursTypeID = oursBlock?.typeID,
                    theirsTypeID = theirsBlock?.typeID,
                    conflictResolution = conflictResolution
                });
                switch (finalType)
                {
                    case ChangeType.Added:    added++;    break;
                    case ChangeType.Modified: modified++; break;
                    case ChangeType.Deleted:  deleted++;  break;
                    case ChangeType.Conflict: conflict++; break;
                }
            }
        }

        // Returns list of property names that have true conflicts (both sides modified to different values)
        private static List<string> GetConflictingProperties(string baseContent, string oursContent, string theirsContent)
        {
            var conflicts = new List<string>();
            if (string.IsNullOrEmpty(baseContent)) return conflicts;
            if (string.IsNullOrEmpty(oursContent) || string.IsNullOrEmpty(theirsContent)) return conflicts;

            var baseProps = ParsePropertiesForAnalysis(baseContent);
            var oursProps = ParsePropertiesForAnalysis(oursContent);
            var theirsProps = ParsePropertiesForAnalysis(theirsContent);

            // Check each property in base
            foreach (var key in baseProps.Keys)
            {
                var baseVal = baseProps[key];
                oursProps.TryGetValue(key, out var oursVal);
                theirsProps.TryGetValue(key, out var theirsVal);

                // Check if both sides changed this property
                bool oursChanged = oursVal != null && oursVal != baseVal;
                bool theirsChanged = theirsVal != null && theirsVal != baseVal;

                // Conflict: both changed the same property to different values
                if (oursChanged && theirsChanged && oursVal != theirsVal)
                    conflicts.Add(key);
            }

            // Check for properties added by both sides (not in base)
            var oursNewKeys = new HashSet<string>();
            foreach (var key in oursProps.Keys)
                if (!baseProps.ContainsKey(key))
                    oursNewKeys.Add(key);

            foreach (var key in theirsProps.Keys)
            {
                if (!baseProps.ContainsKey(key) && oursNewKeys.Contains(key))
                {
                    // Both added same property - conflict if different values
                    if (oursProps[key] != theirsProps[key])
                        conflicts.Add(key);
                }
            }

            return conflicts;
        }

        // Computes property-level diffs for display in UI
        private static List<PropertyDiff> ComputePropertyDiffs(string baseContent, string oursContent, string theirsContent, HashSet<string> conflictingProps)
        {
            var result = new List<PropertyDiff>();
            var oursProps = ParsePropertiesForAnalysis(oursContent);
            var theirsProps = ParsePropertiesForAnalysis(theirsContent);
            var baseProps = ParsePropertiesForAnalysis(baseContent);

            // Track properties we've already processed
            var processed = new HashSet<string>();

            // Check all properties in ours
            foreach (var key in oursProps.Keys)
            {
                theirsProps.TryGetValue(key, out var theirsVal);
                var oursVal = oursProps[key];

                // Only include if there's a difference
                if (oursVal != theirsVal)
                {
                    bool isConflict = conflictingProps != null && conflictingProps.Contains(key);
                    bool isArray = IsArrayValue(oursVal) || (theirsVal != null && IsArrayValue(theirsVal));
                    
                    result.Add(new PropertyDiff
                    {
                        propertyName = key,
                        oursValue = oursVal,
                        theirsValue = theirsVal,
                        isConflict = isConflict,
                        isArrayProperty = isArray
                    });
                }
                processed.Add(key);
            }

            // Check properties only in theirs
            foreach (var key in theirsProps.Keys)
            {
                if (!processed.Contains(key))
                {
                    var theirsVal = theirsProps[key];
                    bool isArray = IsArrayValue(theirsVal);
                    
                    result.Add(new PropertyDiff
                    {
                        propertyName = key,
                        oursValue = null,
                        theirsValue = theirsVal,
                        isConflict = false,
                        isArrayProperty = isArray
                    });
                }
            }

            return result;
        }

        // Computes diffs for deletion conflicts (base vs. the version that still exists)
        private static List<PropertyDiff> ComputePropertyDiffsFromBase(string baseContent, string modifiedContent, bool fromOurs)
        {
            var result = new List<PropertyDiff>();
            var baseProps = ParsePropertiesForAnalysis(baseContent);
            var modifiedProps = ParsePropertiesForAnalysis(modifiedContent);

            // Find properties that changed from base
            foreach (var key in modifiedProps.Keys)
            {
                var modifiedVal = modifiedProps[key];
                baseProps.TryGetValue(key, out var baseVal);

                // Include if different from base or not in base
                if (modifiedVal != baseVal)
                {
                    result.Add(new PropertyDiff
                    {
                        propertyName = key,
                        oursValue = fromOurs ? modifiedVal : null,
                        theirsValue = fromOurs ? null : modifiedVal,
                        isConflict = false,
                        isArrayProperty = IsArrayValue(modifiedVal)
                    });
                }
            }

            return result;
        }

        // Detects if the change involves array properties (which Unity handles well)
        // TODO: Add targeted tests for prefab override arrays to verify merge results vs. conflict classification.
        private static bool HasArrayPropertyChanges(string baseContent, string oursContent, string theirsContent)
        {
            if (string.IsNullOrEmpty(baseContent) || string.IsNullOrEmpty(theirsContent))
                return false;

            var baseProps = ParsePropertiesForAnalysis(baseContent);
            var theirsProps = ParsePropertiesForAnalysis(theirsContent);

            // Check if any changed property is an array
            foreach (var key in theirsProps.Keys)
            {
                if (!baseProps.TryGetValue(key, out var baseVal)) continue;
                if (theirsProps[key] == baseVal) continue; // unchanged

                // Check if this looks like an array property
                if (IsArrayValue(baseVal) || IsArrayValue(theirsProps[key]))
                    return true;
            }

            return false;
        }

        private static bool IsArrayValue(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            var trimmed = value.Trim();
            // Check for inline array format or multi-line array items
            return trimmed.StartsWith("[") || trimmed.StartsWith("-");
        }

        private static Dictionary<string, string> ParsePropertiesForAnalysis(string content)
        {
            var result = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(content)) return result;

            string currentKey = null;
            var currentValue = new System.Text.StringBuilder();

            foreach (var line in content.Split('\n'))
            {
                var trimmed = line.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith("---")) continue;

                // Check if this is a new key:value line
                int colonIdx = line.IndexOf(':');
                if (colonIdx > 0 && !line.TrimStart().StartsWith("-"))
                {
                    // Save previous property
                    if (currentKey != null)
                        result[currentKey] = currentValue.ToString().Trim();

                    // Start new property
                    currentKey = line[..colonIdx].Trim();
                    string valuepart = line[(colonIdx + 1)..].Trim();
                    currentValue.Clear();
                    currentValue.Append(valuepart);
                }
                else if (currentKey != null && (trimmed.StartsWith("-") || trimmed.StartsWith("{")))
                {
                    // Array item or inline value continuation
                    currentValue.Append(" ");
                    currentValue.Append(trimmed);
                }
            }

            // Save last property
            if (currentKey != null)
                result[currentKey] = currentValue.ToString().Trim();

            return result;
        }

        private static bool PrefabOverridesLastWins(string baseContent, string oursContent, string theirsContent)
        {
            // Three-way comparison: only flag as conflict if the SAME property was modified by both sides
            var baseMap = ParsePrefabModificationValues(baseContent);
            var oursMap = ParsePrefabModificationValues(oursContent);
            var theirsMap = ParsePrefabModificationValues(theirsContent);

            if (oursMap.Count == 0 || theirsMap.Count == 0)
                return false;

            // Check each property that exists in either ours or theirs
            var allKeys = new HashSet<string>(oursMap.Keys);
            allKeys.UnionWith(theirsMap.Keys);

            foreach (var key in allKeys)
            {
                baseMap.TryGetValue(key, out var baseVal);
                oursMap.TryGetValue(key, out var oursVal);
                theirsMap.TryGetValue(key, out var theirsVal);

                // Check if both sides modified this property from base
                bool oursChanged = oursVal != null && !string.Equals(oursVal, baseVal);
                bool theirsChanged = theirsVal != null && !string.Equals(theirsVal, baseVal);

                // Only a conflict if BOTH sides changed AND they changed to different values
                if (oursChanged && theirsChanged && !string.Equals(oursVal, theirsVal))
                    return true;
            }

            return false;
        }

        private static Dictionary<string, string> ParsePrefabModificationValues(string content)
        {
            var result = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(content)) return result;

            string currentTarget = null;
            string currentPropertyPath = null;

            foreach (var line in content.Split('\n'))
            {
                var trimmed = line.Trim();
                if (trimmed.StartsWith("target:"))
                {
                    currentTarget = trimmed;
                    currentPropertyPath = null;
                }
                else if (trimmed.StartsWith("- target:"))
                {
                    currentTarget = trimmed.Substring(2).Trim();
                    currentPropertyPath = null;
                }
                else if (trimmed.StartsWith("propertyPath:"))
                {
                    currentPropertyPath = trimmed.Substring("propertyPath:".Length).Trim();
                }
                else if (trimmed.StartsWith("value:") && currentTarget != null && !string.IsNullOrEmpty(currentPropertyPath))
                {
                    var value = trimmed.Substring("value:".Length).Trim();
                    var key = currentTarget + "|" + currentPropertyPath;
                    result[key] = value; // last wins in the same file
                }
            }

            return result;
        }

        private static List<PropertyDiff> BuildPrefabOverrideDiffs(string baseContent, string oursContent, string theirsContent)
        {
            // Three-way comparison: show all property changes with appropriate conflict flags
            var baseMap = ParsePrefabModificationValues(baseContent);
            var oursMap = ParsePrefabModificationValues(oursContent);
            var theirsMap = ParsePrefabModificationValues(theirsContent);
            var result = new List<PropertyDiff>();

            var keys = new HashSet<string>(oursMap.Keys);
            keys.UnionWith(theirsMap.Keys);

            foreach (var key in keys)
            {
                baseMap.TryGetValue(key, out var baseVal);
                oursMap.TryGetValue(key, out var oursVal);
                theirsMap.TryGetValue(key, out var theirsVal);

                // Check if either side modified this property from base
                bool oursChanged = oursVal != null && !string.Equals(oursVal, baseVal);
                bool theirsChanged = theirsVal != null && !string.Equals(theirsVal, baseVal);

                // Skip if both match base (no changes)
                if (!oursChanged && !theirsChanged)
                    continue;

                // Skip if values are the same (same change on both sides)
                if (string.Equals(oursVal, theirsVal))
                    continue;

                var displayName = key;
                var split = key.Split(new[] { '|' }, 2);
                if (split.Length == 2)
                    displayName = split[1];

                // It's a conflict only if BOTH sides changed to different values
                bool isConflict = oursChanged && theirsChanged;

                result.Add(new PropertyDiff
                {
                    propertyName = displayName,
                    oursValue = oursVal,
                    theirsValue = theirsVal,
                    isConflict = isConflict,
                    isArrayProperty = true
                });
            }

            return result;
        }

        /// <summary>
        /// Fixes an ID collision by renumbering the conflicting block in OURS and updating all references.
        /// Returns true if successful, false otherwise.
        /// </summary>
        public bool FixIDCollision(string collidingID)
        {
            if (string.IsNullOrEmpty(oursPath))
            {
                Debug.LogError("[YAMLCompare] Cannot fix ID collision - ours path not set");
                return false;
            }

            try
            {
                // Get all existing IDs from all versions to ensure uniqueness
                var allExistingIds = new HashSet<string>();
                allExistingIds.UnionWith(baseBlocks.Keys);
                allExistingIds.UnionWith(oursBlocks.Keys);
                allExistingIds.UnionWith(theirsBlocks.Keys);

                // Generate new unique ID
                string newID = GenerateUniqueID(allExistingIds);
                Debug.Log($"[YAMLCompare] Fixing ID collision: {collidingID} → {newID}");

                // Read ours file
                string oursContent = File.ReadAllText(oursPath);

                // Replace the block header: --- !u!XXX &OLDID  →  --- !u!XXX &NEWID
                oursContent = Regex.Replace(oursContent, 
                    $@"^(--- !u!\d+) &{collidingID}\b",
                    $"$1 &{newID}",
                    RegexOptions.Multiline);

                // Replace all fileID references in any format:
                // - Simple: {fileID: OLDID}
                // - With guid: {fileID: OLDID, guid: abc, type: 3}
                // - In arrays: - {fileID: OLDID}
                // - In modifications: target: {fileID: OLDID, ...}
                // Pattern captures "fileID: " and replaces just the ID number, preserving everything after
                oursContent = Regex.Replace(oursContent,
                    $@"(fileID:\s*){collidingID}\b",
                    $"${{1}}{newID}");

                // Write back to ours file
                File.WriteAllText(oursPath, oursContent);

                // Re-parse to refresh the comparison
                if (!string.IsNullOrEmpty(basePath))
                {
                    // 3-way comparison
                    CompareFiles(basePath, oursPath, theirsPath);
                }
                else
                {
                    // 2-way comparison
                    CompareFiles(oursPath, theirsPath);
                }

                Debug.Log($"[YAMLCompare] ✅ ID collision fixed: {collidingID} → {newID}");
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[YAMLCompare] Failed to fix ID collision for {collidingID}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Generates a unique ID that doesn't exist in the provided set.
        /// Uses Unity's typical ID format (positive 32-bit integers).
        /// </summary>
        private static string GenerateUniqueID(HashSet<string> existingIds)
        {
            var random = new System.Random();
            string newId;
            int attempts = 0;
            const int maxAttempts = 1000;

            do
            {
                // Generate random positive 32-bit integer (Unity's format)
                newId = random.Next(10000000, int.MaxValue).ToString();
                attempts++;

                if (attempts > maxAttempts)
                {
                    Debug.LogError($"[YAMLCompare] Failed to generate unique ID after {maxAttempts} attempts");
                    return random.Next(10000000, int.MaxValue).ToString(); // Return anyway
                }
            } while (existingIds.Contains(newId));

            return newId;
        }
    }
}
