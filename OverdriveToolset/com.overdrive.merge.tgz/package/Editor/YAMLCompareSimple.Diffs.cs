using UnityEngine;
using System.Collections.Generic;

namespace Overdrive.Editor.Merge
{
    public partial class YAMLCompareSimple
    {
        /// <summary>
        /// Routes to the appropriate property diff computation based on block type.
        /// Note: PrefabInstance blocks should NOT reach here — they have a separate code path.
        /// </summary>
        private static List<PropertyDiffResult> ComputePropertyDiffsForBlockType(BlockCategory category, string baseContent, string oursContent, string theirsContent)
        {
            switch (category)
            {
                case BlockCategory.PrefabInstance:
                    Debug.LogWarning("[YAMLCompareSimple] PrefabInstance block reached property diff computation — this should not happen");
                    return new List<PropertyDiffResult>();

                case BlockCategory.Stripped:
                    return ComputeStrippedBlockDiffs(baseContent, oursContent, theirsContent);

                case BlockCategory.GameObject:
                    return ComputeGameObjectDiffs(baseContent, oursContent, theirsContent);

                case BlockCategory.Secondary:
                    return ComputeComponentDiffs(baseContent, oursContent, theirsContent);

                default:
                    return ComputeStandardPropertyDiffs(baseContent, oursContent, theirsContent);
            }
        }

        /// <summary>
        /// Compute diffs for stripped blocks (prefab overrides saved in scene files).
        /// Parses m_Modifications array and compares individual overrides.
        /// Also used by HandlePrefabInstanceBlock for its m_Modifications section.
        /// </summary>
        private static List<PropertyDiffResult> ComputeStrippedBlockDiffs(string baseContent, string oursContent, string theirsContent)
        {
            var result     = new List<PropertyDiffResult>();
            var baseMods   = ParsePrefabModifications(baseContent);
            var oursMods   = ParsePrefabModifications(oursContent);
            var theirsMods = ParsePrefabModifications(theirsContent);

            var allKeys = new HashSet<string>();
            allKeys.UnionWith(oursMods.Keys);
            allKeys.UnionWith(theirsMods.Keys);

            foreach (var key in allKeys)
            {
                baseMods.TryGetValue(key,   out var baseVal);
                oursMods.TryGetValue(key,   out var oursVal);
                theirsMods.TryGetValue(key, out var theirsVal);

                if (oursVal == theirsVal) continue;

                bool oursChanged   = oursVal   != null && oursVal   != baseVal;
                bool theirsChanged = theirsVal != null && theirsVal != baseVal;
                bool isDeletion    = baseVal   != null && oursVal   != null && theirsVal == null;

                if (oursChanged && !theirsChanged && !isDeletion) continue;

                result.Add(new PropertyDiffResult
                {
                    propertyName = key,
                    oursValue    = oursVal,
                    theirsValue  = theirsVal,
                    isConflict   = oursChanged && theirsChanged
                });
            }

            return result;
        }

        private static List<PropertyDiffResult> ComputeGameObjectDiffs(string baseContent, string oursContent, string theirsContent)
            => ComputeStandardPropertyDiffs(baseContent, oursContent, theirsContent);

        private static List<PropertyDiffResult> ComputeComponentDiffs(string baseContent, string oursContent, string theirsContent)
            => ComputeStandardPropertyDiffs(baseContent, oursContent, theirsContent);

        private static List<PropertyDiffResult> ComputeStandardPropertyDiffs(string baseContent, string oursContent, string theirsContent)
        {
            var result      = new List<PropertyDiffResult>();
            var baseProps   = ParseProperties(baseContent);
            var oursProps   = ParseProperties(oursContent);
            var theirsProps = ParseProperties(theirsContent);

            var allKeys = new HashSet<string>();
            allKeys.UnionWith(oursProps.Keys);
            allKeys.UnionWith(theirsProps.Keys);

            foreach (var key in allKeys)
            {
                baseProps.TryGetValue(key,   out var baseVal);
                oursProps.TryGetValue(key,   out var oursVal);
                theirsProps.TryGetValue(key, out var theirsVal);

                if (oursVal == theirsVal) continue;

                bool oursChanged   = oursVal   != null && oursVal   != baseVal;
                bool theirsChanged = theirsVal != null && theirsVal != baseVal;
                bool isDeletion    = baseVal   != null && oursVal   != null && theirsVal == null;

                if (oursChanged && !theirsChanged && !isDeletion) continue;

                result.Add(new PropertyDiffResult
                {
                    propertyName = key,
                    oursValue    = oursVal,
                    theirsValue  = theirsVal,
                    isConflict   = oursChanged && theirsChanged
                });
            }

            return result;
        }

        /// <summary>
        /// Extract just the propertyPath from a ParsePrefabModifications key.
        /// Key format: "target: {fileID: ...}|propertyPath"
        /// </summary>
        private static string ExtractPropertyPath(string modKey)
        {
            int pipe = modKey.IndexOf('|');
            return pipe >= 0 ? modKey[(pipe + 1)..] : modKey;
        }
    }
}
