using System.Globalization;
using System.Text.RegularExpressions;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace Overdrive.Editor.Merge
{
    public static class YAMLPropertyUI
    {
        public enum ValueKind { Int, Float, Vector2, Vector3, Vector4, Color, ObjectRef, String }

        // Compiled at class load — Detect() runs per-property on every Modified/Conflict block
        private static readonly Regex ColorRegex    = new(@"\{\s*r\s*:.*g\s*:.*b\s*:.*a\s*:",  RegexOptions.Compiled);
        private static readonly Regex Vector4Regex  = new(@"\{\s*x\s*:.*y\s*:.*z\s*:.*w\s*:", RegexOptions.Compiled);
        private static readonly Regex Vector3Regex  = new(@"\{\s*x\s*:.*y\s*:.*z\s*:",        RegexOptions.Compiled);
        private static readonly Regex Vector2Regex  = new(@"\{\s*x\s*:.*y\s*:",               RegexOptions.Compiled);
        private static readonly Regex ObjectRefRegex = new(@"\{\s*fileID\s*:",                  RegexOptions.Compiled);
        private static readonly Regex FloatRegex    = new(@"^-?\d+\.\d+$",                     RegexOptions.Compiled);
        private static readonly Regex IntRegex      = new(@"^-?\d+$",                          RegexOptions.Compiled);
        private static readonly Regex ObjectRefIdRegex = new(@"fileID\s*:\s*(\d+)",            RegexOptions.Compiled);

        // Pre-compiled per-field parsers for the 8 known YAML vector/color component names
        private static readonly System.Collections.Generic.Dictionary<string, Regex> ParseFieldRegexes = new()
        {
            ["r"] = new Regex(@"r\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["g"] = new Regex(@"g\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["b"] = new Regex(@"b\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["a"] = new Regex(@"a\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["x"] = new Regex(@"x\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["y"] = new Regex(@"y\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["z"] = new Regex(@"z\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
            ["w"] = new Regex(@"w\s*:\s*(-?\d+(?:\.\d+)?)", RegexOptions.Compiled),
        };

        // Produces a full property-item row.
        // Non-conflict: name | theirs value
        // Conflict: name / [Yours: ours] / [Theirs: theirs]  (column layout via CSS)
        // In property conflicts, OURS wins (gets .keep class), THEIRS gets discarded.
        // onStashTheirs is used to save the discarded (theirs) value for later application.
        public static VisualElement MakeDiffRow(string key, string oursVal, string theirsVal, bool isConflict = false,
            System.Action<string, string> onStashTheirs = null, System.Action<string, string> onStashOurs = null)
        {
            var kind = Reconcile(Detect(oursVal), Detect(theirsVal));

            var row = new VisualElement();
            row.AddToClassList("property-item");
            if (isConflict) row.AddToClassList("conflict");

            var nameLabel = new Label(HumanizePropertyName(key));
            nameLabel.AddToClassList("property-name");
            row.Add(nameLabel);

            if (isConflict)
            {
                // In property-level conflicts, OURS wins (not theirs)
                var oursElement = MakeValueElement(oursVal, kind, "Yours");
                oursElement.AddToClassList("keep");
                row.Add(oursElement);
                
                var theirsElement = MakeValueElement(theirsVal, kind, "Theirs");
                theirsElement.AddToClassList("discard");
                row.Add(theirsElement);

                // Add stash button for the discarded value (theirs)
                if (onStashTheirs != null && !string.IsNullOrEmpty(theirsVal))
                {
                    var stashButton = new UnityEngine.UIElements.Button(() => onStashTheirs(key, theirsVal))
                    {
                        text = "Stash Theirs"
                    };
                    stashButton.AddToClassList("stash");
                    stashButton.tooltip = "Save 'Theirs' value to stash file for later application";
                    row.Add(stashButton);
                }
            }
            else
            {
                row.Add(MakeValueElement(theirsVal, kind));
            }

            return row;
        }
        
        private static ValueKind Reconcile(ValueKind a, ValueKind b)
        {
            if (a == b) return a;
            if ((a == ValueKind.Float && b == ValueKind.Int) ||
                (a == ValueKind.Int  && b == ValueKind.Float))
                return ValueKind.Float;
            return ValueKind.String;
        }

        // Produces a single typed, read-only element for a YAML value string
        public static VisualElement MakeValueElement(string value) =>
            MakeValueElement(value, Detect(value));

        public static VisualElement MakeValueElement(string value, ValueKind kind, string fieldLabel = "")
        {
            if (string.IsNullOrEmpty(value))
            {
                var dash = new Label(string.IsNullOrEmpty(fieldLabel) ? "—" : $"{fieldLabel}: —");
                dash.AddToClassList("property-value");
                return dash;
            }

            switch (kind)
            {
                case ValueKind.Color:
                {
                    var field = new ColorField { label = fieldLabel, showEyeDropper = false };
                    field.SetValueWithoutNotify(ParseColor(value));
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("color");
                    return field;
                }
                case ValueKind.Vector4:
                {
                    var field = new Vector4Field { label = fieldLabel };
                    field.SetValueWithoutNotify(ParseVector4(value));
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("vector4");
                    return field;
                }
                case ValueKind.Vector3:
                {
                    var field = new Vector3Field { label = fieldLabel };
                    field.SetValueWithoutNotify(ParseVector3(value));
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("vector3");
                    return field;
                }
                case ValueKind.Vector2:
                {
                    var field = new Vector2Field { label = fieldLabel };
                    field.SetValueWithoutNotify(ParseVector2(value));
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("vector2");
                    return field;
                }
                case ValueKind.Float:
                {
                    var field = new FloatField { label = fieldLabel };
                    field.SetValueWithoutNotify(float.Parse(value, CultureInfo.InvariantCulture));
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("float");
                    return field;
                }
                case ValueKind.Int:
                {
                    var field = new IntegerField { label = fieldLabel };
                    if (int.TryParse(value, out int intVal))
                        field.SetValueWithoutNotify(intVal);
                    field.SetEnabled(false);
                    field.AddToClassList("property-value");
                    field.AddToClassList("int");
                    return field;
                }
                case ValueKind.ObjectRef:
                {
                    string text = FormatObjectRef(value);
                    var lbl = new Label(string.IsNullOrEmpty(fieldLabel) ? text : $"{fieldLabel}: {text}");
                    lbl.AddToClassList("property-value");
                    lbl.AddToClassList("object-ref");
                    return lbl;
                }
                default:
                {
                    var lbl = new Label(string.IsNullOrEmpty(fieldLabel) ? value : $"{fieldLabel}: {value}");
                    lbl.AddToClassList("property-value");
                    return lbl;
                }
            }
        }

        public static ValueKind Detect(string value)
        {
            if (string.IsNullOrEmpty(value)) return ValueKind.String;

            // Color:   {r: _, g: _, b: _, a: _}
            if (ColorRegex.IsMatch(value))   return ValueKind.Color;

            // Vector4: {x: _, y: _, z: _, w: _}
            if (Vector4Regex.IsMatch(value)) return ValueKind.Vector4;

            // Vector3: {x: _, y: _, z: _}  (no w key)
            if (Vector3Regex.IsMatch(value) && !value.Contains("w:")) return ValueKind.Vector3;

            // Vector2: {x: _, y: _}  (no z or w key)
            if (Vector2Regex.IsMatch(value) && !value.Contains("z:") && !value.Contains("w:")) return ValueKind.Vector2;

            // Object ref: {fileID: _}
            if (ObjectRefRegex.IsMatch(value)) return ValueKind.ObjectRef;

            // Float before Int so "1.0" doesn't match Int
            if (FloatRegex.IsMatch(value)) return ValueKind.Float;
            if (IntRegex.IsMatch(value))   return ValueKind.Int;

            return ValueKind.String;
        }

        // --- Parsers ---

        private static Color ParseColor(string v) =>
            new Color(ParseField(v, "r"), ParseField(v, "g"), ParseField(v, "b"), ParseField(v, "a"));

        private static Vector4 ParseVector4(string v) =>
            new Vector4(ParseField(v, "x"), ParseField(v, "y"), ParseField(v, "z"), ParseField(v, "w"));

        private static Vector3 ParseVector3(string v) =>
            new Vector3(ParseField(v, "x"), ParseField(v, "y"), ParseField(v, "z"));

        private static Vector2 ParseVector2(string v) =>
            new Vector2(ParseField(v, "x"), ParseField(v, "y"));

        private static float ParseField(string value, string field)
        {
            var m = ParseFieldRegexes[field].Match(value);
            return m.Success && float.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out float f)
                ? f : 0f;
        }

        private static string FormatObjectRef(string value)
        {
            var m = ObjectRefIdRegex.Match(value);
            string id = m.Success ? m.Groups[1].Value : "?";
            return id == "0" ? "None" : $"ref {id}";
        }

        // Converts property names from m_CamelCase to Human Readable format
        // e.g., "m_LocalPosition" -> "Local Position"
        //       "m_Name" -> "Name"
        public static string HumanizePropertyName(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
                return propertyName;

            // Remove m_ prefix if present
            if (propertyName.StartsWith("m_"))
                propertyName = propertyName.Substring(2);

            // Insert space before uppercase letters
            propertyName = Regex.Replace(propertyName, "([A-Z])", " $1").Trim();

            return propertyName;
        }
    }
}
