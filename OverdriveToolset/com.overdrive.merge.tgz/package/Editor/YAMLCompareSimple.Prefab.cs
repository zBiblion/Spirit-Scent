using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    public partial class YAMLCompareSimple
    {
        /// <summary>
        /// Handle PrefabInstance blocks with granular per-property comparison.
        /// PrefabInstances are treated as atomic units for deletions; for modifications,
        /// we diff m_Modifications and the four structural arrays individually.
        /// </summary>
        private void HandlePrefabInstanceBlock(string id, YAMLBlock rep, string baseContent, string oursContent, string theirsContent, bool inBase, bool inOurs, bool inTheirs)
        {
            string gameObjectName = rep.name;
            string componentType  = rep.objectType;
            string displayPath    = BuildDisplayPath(gameObjectName, componentType);
            bool   oursChanged    = oursContent   != null && oursContent   != baseContent;
            bool   theirsChanged  = theirsContent != null && theirsContent != baseContent;

            // Deleted in theirs, exists in ours
            if (inBase && inOurs && !inTheirs)
            {
                changes.Add(new PropertyChange
                {
                    propertyName       = "[Prefab Instance Deleted]",
                    oursValue          = oursChanged ? "Modified" : "Exists",
                    theirsValue        = "Deleted",
                    isConflict         = oursChanged,
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = displayPath,
                    isDeletion         = true,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = false,
                    isSceneRoots       = false,
                    oursBlockContent   = oursContent,
                    theirsBlockContent = null,
                    baseBlockContent   = baseContent
                });
                return;
            }

            // Deleted in ours, exists in theirs
            if (inBase && !inOurs && inTheirs)
            {
                changes.Add(new PropertyChange
                {
                    propertyName       = "[Prefab Instance Deleted]",
                    oursValue          = "Deleted",
                    theirsValue        = theirsChanged ? "Modified" : "Exists",
                    isConflict         = theirsChanged,
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = displayPath,
                    isDeletion         = true,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = true,
                    isSceneRoots       = false,
                    oursBlockContent   = null,
                    theirsBlockContent = theirsContent,
                    baseBlockContent   = baseContent
                });
                return;
            }

            if (!inOurs || !inTheirs) return;
            if (oursContent == theirsContent) return;
            if (oursChanged && !theirsChanged) return;

            // Granular diff: m_Modifications (reuses stripped-block parser — format is identical)
            var modDiffs = ComputeStrippedBlockDiffs(baseContent, oursContent, theirsContent);
            foreach (var diff in modDiffs)
            {
                string propPath        = ExtractPropertyPath(diff.propertyName);
                string oursFormatted   = diff.oursValue   != null ? FormatPropertyValue(diff.oursValue)   : null;
                string theirsFormatted = diff.theirsValue != null ? FormatPropertyValue(diff.theirsValue) : null;
                bool   propIsDeletion  = string.IsNullOrEmpty(diff.theirsValue) && !string.IsNullOrEmpty(diff.oursValue);

                changes.Add(new PropertyChange
                {
                    propertyName       = propPath,
                    oursValue          = oursFormatted,
                    theirsValue        = theirsFormatted ?? "[Deleted]",
                    isConflict         = diff.isConflict,
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = displayPath,
                    isDeletion         = propIsDeletion,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = false,
                    isSceneRoots       = false,
                    oursBlockContent   = oursContent,
                    theirsBlockContent = theirsContent,
                    baseBlockContent   = baseContent
                });
            }

            // Structural arrays: m_AddedGameObjects, m_AddedComponents, m_RemovedComponents, m_RemovedGameObjects
            ComputeAndAddPrefabStructuralChanges(id, baseContent, oursContent, theirsContent, componentType, gameObjectName, displayPath);
        }

        private void ComputeAndAddPrefabStructuralChanges(string id, string baseContent, string oursContent, string theirsContent,
            string componentType, string gameObjectName, string displayPath)
        {
            // m_AddedGameObjects: companion-block-aware conflict detection on removal
            DiffAddedGameObjects(id, baseContent, oursContent, theirsContent, componentType, gameObjectName);

            // m_AddedComponents: never a conflict (Unity merges additively)
            DiffStructuralArray(id, baseContent, oursContent, theirsContent,
                "m_AddedComponents", "[Added Component]", componentType, gameObjectName, displayPath);

            // m_RemovedComponents: precise cross-type conflict via m_Modifications target matching
            DiffRemovedComponents(id, baseContent, oursContent, theirsContent, componentType, gameObjectName, displayPath);

            // m_RemovedGameObjects: conservative potential-conflict warning
            DiffRemovedGameObjects(id, baseContent, oursContent, theirsContent, componentType, gameObjectName);
        }

        private void DiffStructuralArray(string id, string baseContent, string oursContent, string theirsContent,
            string arrayName, string changeLabel, string componentType, string gameObjectName, string displayPath)
        {
            var baseSet   = ParseStructuralArray(baseContent,   arrayName);
            var oursSet   = ParseStructuralArray(oursContent,   arrayName);
            var theirsSet = ParseStructuralArray(theirsContent, arrayName);

            var allIDs = new HashSet<string>(oursSet);
            allIDs.UnionWith(theirsSet);

            foreach (var fileID in allIDs)
            {
                bool inBase   = baseSet.Contains(fileID);
                bool inOurs   = oursSet.Contains(fileID);
                bool inTheirs = theirsSet.Contains(fileID);

                if (inOurs == inTheirs) continue;

                bool oursChanged   = inOurs   != inBase;
                bool theirsChanged = inTheirs != inBase;

                // Skip if only ours changed (not an incoming change)
                if (oursChanged && !theirsChanged) continue;

                string name = GetBlockDisplayName(fileID);

                changes.Add(new PropertyChange
                {
                    propertyName       = $"{changeLabel}: {name}",
                    oursValue          = inOurs   ? name : "(not present)",
                    theirsValue        = inTheirs ? name : "(not present)",
                    isConflict         = false,  // Additive arrays are never a conflict
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = displayPath,
                    isDeletion         = !inTheirs,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = false,
                    isSceneRoots       = false,
                    oursBlockContent   = oursContent,
                    theirsBlockContent = theirsContent,
                    baseBlockContent   = baseContent
                });
            }
        }

        /// <summary>
        /// Diff m_AddedGameObjects. When Theirs removes an added GO that Ours still has,
        /// checks companion blocks to determine whether the removal conflicts with local edits.
        /// </summary>
        private void DiffAddedGameObjects(string id, string baseContent, string oursContent, string theirsContent,
            string componentType, string gameObjectName)
        {
            var baseSet   = ParseStructuralArray(baseContent,   "m_AddedGameObjects");
            var oursSet   = ParseStructuralArray(oursContent,   "m_AddedGameObjects");
            var theirsSet = ParseStructuralArray(theirsContent, "m_AddedGameObjects");

            var allIDs = new HashSet<string>(oursSet);
            allIDs.UnionWith(theirsSet);

            foreach (var fileID in allIDs)
            {
                bool inBase   = baseSet.Contains(fileID);
                bool inOurs   = oursSet.Contains(fileID);
                bool inTheirs = theirsSet.Contains(fileID);

                if (inOurs == inTheirs) continue;

                bool oursChanged   = inOurs   != inBase;
                bool theirsChanged = inTheirs != inBase;

                if (oursChanged && !theirsChanged) continue;

                string name       = GetBlockDisplayName(fileID);
                bool   isConflict = inBase && inOurs && !inTheirs && HasCompanionBlockChanges(fileID);

                changes.Add(new PropertyChange
                {
                    propertyName       = $"{name} (Various Edits)",
                    oursValue          = inOurs   ? name : "(not present)",
                    theirsValue        = inTheirs ? name : "(not present)",
                    isConflict         = isConflict,
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = $"{gameObjectName} / {name}",
                    isDeletion         = !inTheirs,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = false,
                    isSceneRoots       = false,
                    oursBlockContent   = oursContent,
                    theirsBlockContent = theirsContent,
                    baseBlockContent   = baseContent
                });
            }
        }

        /// <summary>
        /// Diff m_RemovedComponents. For each component newly removed in Theirs, checks
        /// whether Ours has a new m_Modifications entry targeting the same prefab-internal
        /// {fileID, guid} — if so, marks as a precise conflict (your override will be lost).
        /// </summary>
        private void DiffRemovedComponents(string id, string baseContent, string oursContent, string theirsContent,
            string componentType, string gameObjectName, string displayPath)
        {
            var baseSet   = ParseRemovedItemSet(baseContent,   "m_RemovedComponents");
            var theirsSet = ParseRemovedItemSet(theirsContent, "m_RemovedComponents");

            var newInTheirs = new HashSet<string>(theirsSet);
            newInTheirs.ExceptWith(baseSet);
            if (newInTheirs.Count == 0) return;

            var newOursMods = new HashSet<string>(ParseModificationTargetSet(oursContent));
            newOursMods.ExceptWith(ParseModificationTargetSet(baseContent));

            foreach (var key in newInTheirs)
            {
                bool   isConflict = newOursMods.Contains(key);
                string fileID     = key.Split('|')[0];

                changes.Add(new PropertyChange
                {
                    propertyName       = $"[Removed Component] (fileID: {fileID})",
                    oursValue          = isConflict ? "Modified" : "Exists",
                    theirsValue        = "Removed",
                    isConflict         = isConflict,
                    componentType      = componentType,
                    gameObjectName     = gameObjectName,
                    displayPath        = displayPath,
                    isDeletion         = true,
                    blockID            = id,
                    blockCategory      = BlockCategory.PrefabInstance,
                    oursWins           = false,
                    isSceneRoots       = false,
                    oursBlockContent   = oursContent,
                    theirsBlockContent = theirsContent,
                    baseBlockContent   = baseContent
                });
            }
        }

        /// <summary>
        /// Diff m_RemovedGameObjects. For each native child GO newly removed in Theirs,
        /// uses a conservative check: if Ours has ANY new m_Modifications entries vs Base,
        /// flags as a potential conflict (can't resolve which GO without the prefab asset).
        /// </summary>
        private void DiffRemovedGameObjects(string id, string baseContent, string oursContent, string theirsContent,
            string componentType, string gameObjectName)
        {
            var baseSet   = ParseRemovedItemSet(baseContent,   "m_RemovedGameObjects");
            var theirsSet = ParseRemovedItemSet(theirsContent, "m_RemovedGameObjects");

            var newInTheirs = new HashSet<string>(theirsSet);
            newInTheirs.ExceptWith(baseSet);
            if (newInTheirs.Count == 0) return;

            var newOursMods = new HashSet<string>(ParseModificationTargetSet(oursContent));
            newOursMods.ExceptWith(ParseModificationTargetSet(baseContent));
            bool hasNewOursMods = newOursMods.Count > 0;

            // Emit one aggregated item — can't identify specific GOs without the prefab asset
            changes.Add(new PropertyChange
            {
                propertyName       = $"{gameObjectName} (Child Edits)",
                oursValue          = hasNewOursMods ? "Has overrides" : "Exists",
                theirsValue        = "Removed",
                isConflict         = hasNewOursMods,
                conflictNote       = hasNewOursMods
                                         ? "You modified children of this prefab, but some have been deleted in Theirs. Your changes may be lost."
                                         : null,
                componentType      = componentType,
                gameObjectName     = gameObjectName,
                displayPath        = $"{gameObjectName} / Prefab Children",
                isDeletion         = true,
                blockID            = id,
                blockCategory      = BlockCategory.PrefabInstance,
                oursWins           = false,
                isSceneRoots       = false,
                oursBlockContent   = oursContent,
                theirsBlockContent = theirsContent,
                baseBlockContent   = baseContent
            });
        }

        /// <summary>
        /// Returns true if any companion blocks rooted at the given added-object Transform
        /// fileID have different content in Ours vs Base.
        /// </summary>
        private bool HasCompanionBlockChanges(string addedObjectTransformFileID)
        {
            if (!oursBlocks.TryGetValue(addedObjectTransformFileID, out var transformBlock))
                return false;

            string goFileID = transformBlock.parentGoID;
            if (string.IsNullOrEmpty(goFileID)) return false;

            if (oursBlocks.TryGetValue(goFileID, out var goBlock) &&
                baseBlocks.TryGetValue(goFileID, out var baseGoBlock) &&
                goBlock.fullContent != baseGoBlock.fullContent)
                return true;

            foreach (var kvp in oursBlocks)
            {
                if (kvp.Value.parentGoID != goFileID) continue;
                if (baseBlocks.TryGetValue(kvp.Key, out var baseBlock) &&
                    kvp.Value.fullContent != baseBlock.fullContent)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Like GetBlockName but also resolves Transforms to their parent GO name,
        /// giving a better display label for structural array entries.
        /// </summary>
        private string GetBlockDisplayName(string fileID)
        {
            var block = oursBlocks.TryGetValue(fileID, out var b1)   ? b1 :
                        theirsBlocks.TryGetValue(fileID, out var b2) ? b2 :
                        baseBlocks.TryGetValue(fileID, out var b3)   ? b3 : null;

            if (block == null)                                          return GetBlockName(fileID);
            if (block.name != null)                                     return block.name;
            if (block.objectType == "Transform" && block.parentGoID != null) return GetBlockName(block.parentGoID);
            return block.objectType ?? GetBlockName(fileID);
        }

        // ── Prefab-specific parsers ─────────────────────────────────────────────────

        private static Dictionary<string, string> ParsePrefabModifications(string content)
        {
            var result = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(content)) return result;

            string currentTarget       = null;
            string currentPropertyPath = null;

            foreach (var line in content.Split('\n'))
            {
                var trimmed = line.Trim();
                if (trimmed.StartsWith("target:"))
                {
                    currentTarget       = trimmed;
                    currentPropertyPath = null;
                }
                else if (trimmed.StartsWith("- target:"))
                {
                    currentTarget       = trimmed.Substring(2).Trim();
                    currentPropertyPath = null;
                }
                else if (trimmed.StartsWith("propertyPath:"))
                {
                    currentPropertyPath = trimmed.Substring("propertyPath:".Length).Trim();
                }
                else if (trimmed.StartsWith("value:") && currentTarget != null && !string.IsNullOrEmpty(currentPropertyPath))
                {
                    result[currentTarget + "|" + currentPropertyPath] = trimmed.Substring("value:".Length).Trim();
                }
            }

            return result;
        }

        /// <summary>
        /// Parse an addedObject structural array section and return the set of addedObject fileIDs.
        /// Handles both the inline-empty form (m_AddedGameObjects: []) and the multi-entry form.
        /// </summary>
        private static HashSet<string> ParseStructuralArray(string content, string arrayName)
        {
            var result = new HashSet<string>();
            if (string.IsNullOrEmpty(content)) return result;

            bool inSection     = false;
            int  sectionIndent = -1;

            foreach (var rawLine in content.Split('\n'))
            {
                var trimmed = rawLine.TrimStart();
                int indent  = rawLine.Length - trimmed.Length;

                if (trimmed.StartsWith(arrayName + ":"))
                {
                    inSection     = true;
                    sectionIndent = indent;
                    continue;
                }

                if (!inSection) continue;

                if (trimmed.Length > 0 && !trimmed.StartsWith("-") && indent <= sectionIndent)
                {
                    inSection = false;
                    continue;
                }

                var m = Regex.Match(trimmed, @"addedObject:\s*\{fileID:\s*(\d+)\}");
                if (m.Success && m.Groups[1].Value != "0")
                    result.Add(m.Groups[1].Value);
            }

            return result;
        }

        /// <summary>
        /// Parse a removed-items array (m_RemovedComponents or m_RemovedGameObjects) and
        /// return the set of "fileID|guid" keys for each entry.
        /// </summary>
        private static HashSet<string> ParseRemovedItemSet(string content, string arrayName)
        {
            var result = new HashSet<string>();
            if (string.IsNullOrEmpty(content)) return result;

            bool inSection     = false;
            int  sectionIndent = -1;

            foreach (var rawLine in content.Split('\n'))
            {
                var trimmed = rawLine.TrimStart();
                int indent  = rawLine.Length - trimmed.Length;

                if (trimmed.StartsWith(arrayName + ":"))
                {
                    inSection     = true;
                    sectionIndent = indent;
                    continue;
                }

                if (!inSection) continue;

                if (trimmed.Length > 0 && !trimmed.StartsWith("-") && indent <= sectionIndent)
                {
                    inSection = false;
                    continue;
                }

                var m = Regex.Match(trimmed, @"\{fileID:\s*(\d+),\s*guid:\s*([a-f0-9]+)");
                if (m.Success)
                    result.Add(m.Groups[1].Value + "|" + m.Groups[2].Value);
            }

            return result;
        }

        /// <summary>
        /// Parse all target: {fileID, guid} pairs from m_Modifications entries.
        /// Returns "fileID|guid" keys.
        /// </summary>
        private static HashSet<string> ParseModificationTargetSet(string content)
        {
            var result = new HashSet<string>();
            if (string.IsNullOrEmpty(content)) return result;
            foreach (Match m in ModTargetRegex.Matches(content))
                result.Add(m.Groups[1].Value + "|" + m.Groups[2].Value);
            return result;
        }
    }
}
