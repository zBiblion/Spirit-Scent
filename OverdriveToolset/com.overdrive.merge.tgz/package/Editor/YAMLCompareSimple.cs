using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Simplified YAML comparison focused on property-level diffs for display.
    /// Used by PullPreviewSimpleWindow for straightforward 3-way diff visualization.
    /// </summary>
    public partial class YAMLCompareSimple
    {
        // Compiled regex patterns for YAML parsing
        private static readonly Regex BlockSplitRegex        = new(@"(?=^--- !u!)",                                         RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex BlockHeaderRegex       = new(@"^--- !u!(\d+) &(\d+)(.*)",                             RegexOptions.Compiled);
        private static readonly Regex ObjectTypeRegex        = new(@"^--- !u!\d+ &\d+.*\n(\w+):",                           RegexOptions.Compiled | RegexOptions.Multiline);
        private static readonly Regex NameRegex              = new(@"m_Name:\s*(.+)",                                        RegexOptions.Compiled);
        private static readonly Regex SourcePrefabGuidRegex  = new(@"m_SourcePrefab:\s*\{fileID:\s*\d+,\s*guid:\s*([a-f0-9]+)", RegexOptions.Compiled);
        private static readonly Regex GameObjectRefRegex     = new(@"m_GameObject:\s*\{fileID:\s*(\d+)\}",                   RegexOptions.Compiled);
        private static readonly Regex EditorClassIdRegex     = new(@"m_EditorClassIdentifier:\s*[^:]*::(\w+)",               RegexOptions.Compiled);
        private static readonly Regex PrefabInstanceRefRegex = new(@"m_PrefabInstance:\s*\{fileID:\s*(\d+)\}",               RegexOptions.Compiled);
        private static readonly Regex FatherRefRegex         = new(@"m_Father:\s*\{fileID:\s*(\d+)\}",                       RegexOptions.Compiled);
        private static readonly Regex ModTargetRegex         = new(@"target:\s*\{fileID:\s*(\d+),\s*guid:\s*([a-f0-9]+)",   RegexOptions.Compiled);

        public enum BlockCategory
        {
            SceneSettings,   // fileID has 1-2 digits (scene-level settings)
            SceneRoots,      // typeID 1660057539 (scene ordering metadata)
            Stripped,        // header contains "stripped" (prefab overrides)
            GameObject,      // typeID 1
            PrefabInstance,  // typeID 1001
            Secondary        // everything else (components, assets, etc)
        }

        public class YAMLBlock
        {
            public string typeID;            // Unity type ID (1=GameObject, 4=Transform, etc)
            public string fileID;            // File ID reference
            public string objectType;        // Object type name (GameObject, Transform, etc)
            public string fullContent;       // Complete YAML block content
            public string name;              // Extracted name if available
            public BlockCategory category;   // Categorized block type
            public string parentGoID;        // For Secondary blocks: fileID of the owner GameObject
            public string prefabOwnerID;     // Non-null when this block is a companion of a PrefabInstance
            public string fatherID;          // From m_Father (Transform hierarchy, used to resolve companion ownership)
        }

        /// <summary>
        /// Self-contained property change with all context needed for display and merging.
        /// </summary>
        public class PropertyChange
        {
            // What changed
            public string propertyName;      // Property key (e.g., "m_IsTrigger")
            public string oursValue;         // Value in our version (null if not present)
            public string theirsValue;       // Value in their version (null if not present)
            public bool isConflict;          // True if both sides modified to different values

            // Display context
            public string componentType;     // "Transform", "Rigidbody", "PlayerController"
            public string gameObjectName;    // "Player", "Enemy" (null for scene-level blocks)
            public string displayPath;       // Pre-computed "Player / Rigidbody" or just "Transform"

            // Deletion info
            public bool isDeletion;          // True if change is due to a deletion

            // Block metadata (for merge operations)
            public string blockID;           // File ID of the block
            public BlockCategory blockCategory;
            public bool oursWins;            // True if ours wins for this block type (false for prefabs)
            public bool isSceneRoots;        // True if this is scene ordering metadata

            // Raw content (for merge operations)
            public string oursBlockContent;
            public string theirsBlockContent;
            public string baseBlockContent;

            // Optional: override the default conflict message shown in the display window
            public string conflictNote;
        }

        // Internal helper for property-level comparison
        private class PropertyDiffResult
        {
            public string propertyName;
            public string oursValue;
            public string theirsValue;
            public bool isConflict;
        }

        // Block dictionaries - private, used internally for comparison
        private Dictionary<string, YAMLBlock> baseBlocks   = new Dictionary<string, YAMLBlock>();
        private Dictionary<string, YAMLBlock> oursBlocks   = new Dictionary<string, YAMLBlock>();
        private Dictionary<string, YAMLBlock> theirsBlocks = new Dictionary<string, YAMLBlock>();

        // File paths - needed for ID collision fixing
        public string basePath;
        public string oursPath;
        public string theirsPath;

        // ID collision detection results (delegated to YAMLIDCollisionDetector)
        public List<YAMLIDCollisionDetector.IDCollision> detectedCollisions = new List<YAMLIDCollisionDetector.IDCollision>();

        // Public output - flattened, display-ready property changes
        public List<PropertyChange> changes = new List<PropertyChange>();

        /// <summary>
        /// Pre-flight check for ID collisions. MUST be called before CompareFiles.
        /// Returns true if collisions were found (blocking further comparison).
        /// </summary>
        public bool DetectIDCollisions(string basePath, string oursPath, string theirsPath)
        {
            this.basePath   = basePath;
            this.oursPath   = oursPath;
            this.theirsPath = theirsPath;

            detectedCollisions = YAMLIDCollisionDetector.DetectCollisions(basePath, oursPath, theirsPath);
            return detectedCollisions.Count > 0;
        }

        /// <summary>
        /// Compare three YAML files (base, ours, theirs) and identify changes.
        /// Should only be called AFTER DetectIDCollisions returns false (no collisions).
        /// </summary>
        public void CompareFiles(string basePath, string oursPath, string theirsPath)
        {
            this.basePath   = basePath;
            this.oursPath   = oursPath;
            this.theirsPath = theirsPath;

            string baseContent   = File.ReadAllText(basePath);
            string oursContent   = File.ReadAllText(oursPath);
            string theirsContent = File.ReadAllText(theirsPath);

            baseBlocks   = ParseYAMLBlocks(baseContent);
            oursBlocks   = ParseYAMLBlocks(oursContent);
            theirsBlocks = ParseYAMLBlocks(theirsContent);

            ResolvePrefabCompanions(baseBlocks);
            ResolvePrefabCompanions(oursBlocks);
            ResolvePrefabCompanions(theirsBlocks);

            CompareBlocksThreeWay();
        }

        /// <summary>
        /// Fix all detected ID collisions by renumbering the conflicting blocks in OURS.
        /// Returns true if all collisions were successfully fixed.
        /// </summary>
        public bool FixAllIDCollisions()
        {
            return YAMLIDCollisionDetector.FixAllCollisions(detectedCollisions, basePath, oursPath, theirsPath);
        }

        private void CompareBlocksThreeWay()
        {
            changes.Clear();

            var allIds = new HashSet<string>();
            allIds.UnionWith(baseBlocks.Keys);
            allIds.UnionWith(oursBlocks.Keys);
            allIds.UnionWith(theirsBlocks.Keys);

            foreach (var id in allIds)
            {
                bool inBase   = baseBlocks.TryGetValue(id,   out var baseBlock);
                bool inOurs   = oursBlocks.TryGetValue(id,   out var oursBlock);
                bool inTheirs = theirsBlocks.TryGetValue(id, out var theirsBlock);

                string baseContent   = baseBlock?.fullContent;
                string oursContent   = oursBlock?.fullContent;
                string theirsContent = theirsBlock?.fullContent;

                var rep = oursBlock ?? theirsBlock ?? baseBlock;

                // Skip companion blocks owned by a PrefabInstance — handled inside HandlePrefabInstanceBlock
                if (rep.prefabOwnerID != null)
                    continue;

                // PrefabInstance blocks use simple whole-block comparison only
                if (rep.category == BlockCategory.PrefabInstance)
                {
                    HandlePrefabInstanceBlock(id, rep, baseContent, oursContent, theirsContent, inBase, inOurs, inTheirs);
                    continue;
                }

                bool oursWins = true;  // Non-prefab blocks use ours-wins strategy

                string componentType  = rep.objectType;
                string gameObjectName = null;

                if (!string.IsNullOrEmpty(rep.parentGoID))
                    gameObjectName = GetBlockName(rep.parentGoID);
                else if (rep.category == BlockCategory.GameObject)
                    gameObjectName = rep.name;

                string displayPath = BuildDisplayPath(gameObjectName, componentType);

                // Block deleted in theirs, exists in ours
                if (inBase && inOurs && !inTheirs)
                {
                    bool hasChangesInOurs    = HasPropertyChanges(rep.category, baseContent, oursContent);
                    bool hasComponentChanges = rep.category == BlockCategory.GameObject && HasComponentChangesForGameObject(id);
                    bool isConflict          = hasChangesInOurs || hasComponentChanges;

                    // Component whose parent GO is also deleted — GO entry covers the conflict
                    if (rep.category == BlockCategory.Secondary && !string.IsNullOrEmpty(rep.parentGoID) &&
                        baseBlocks.ContainsKey(rep.parentGoID) && oursBlocks.ContainsKey(rep.parentGoID) && !theirsBlocks.ContainsKey(rep.parentGoID))
                        isConflict = false;

                    changes.Add(new PropertyChange
                    {
                        propertyName       = $"{gameObjectName} (Various)",
                        oursValue          = "Exists",
                        theirsValue        = "Deleted",
                        isConflict         = isConflict,
                        componentType      = componentType,
                        gameObjectName     = gameObjectName,
                        displayPath        = displayPath,
                        isDeletion         = true,
                        blockID            = id,
                        blockCategory      = rep.category,
                        oursWins           = oursWins,
                        isSceneRoots       = rep.category == BlockCategory.SceneRoots,
                        oursBlockContent   = oursContent,
                        theirsBlockContent = null,
                        baseBlockContent   = baseContent
                    });
                    continue;
                }

                // Block deleted in ours, exists in theirs
                if (inBase && !inOurs && inTheirs)
                {
                    bool hasChangesInTheirs  = HasPropertyChanges(rep.category, baseContent, theirsContent);
                    bool hasComponentChanges = rep.category == BlockCategory.GameObject && HasComponentChangesForGameObjectInTheirs(id);
                    bool isConflict          = hasChangesInTheirs || hasComponentChanges;

                    // Component whose parent GO is also deleted in ours — GO entry covers the conflict
                    if (rep.category == BlockCategory.Secondary && !string.IsNullOrEmpty(rep.parentGoID) &&
                        baseBlocks.ContainsKey(rep.parentGoID) && !oursBlocks.ContainsKey(rep.parentGoID) && theirsBlocks.ContainsKey(rep.parentGoID))
                        isConflict = false;

                    changes.Add(new PropertyChange
                    {
                        propertyName       = "[Block Deleted]",
                        oursValue          = "Deleted",
                        theirsValue        = "Exists",
                        isConflict         = isConflict,
                        componentType      = componentType,
                        gameObjectName     = gameObjectName,
                        displayPath        = displayPath,
                        isDeletion         = true,
                        blockID            = id,
                        blockCategory      = rep.category,
                        oursWins           = oursWins,
                        isSceneRoots       = rep.category == BlockCategory.SceneRoots,
                        oursBlockContent   = null,
                        theirsBlockContent = theirsContent,
                        baseBlockContent   = baseContent
                    });
                    continue;
                }

                if (!inOurs || !inTheirs) continue;
                if (oursContent == null || theirsContent == null) continue;

                var propertyDiffs = ComputePropertyDiffsForBlockType(rep.category, baseContent, oursContent, theirsContent);
                if (propertyDiffs == null || propertyDiffs.Count == 0) continue;

                foreach (var propDiff in propertyDiffs)
                {
                    string oursFormatted   = FormatPropertyValue(propDiff.oursValue);
                    string theirsFormatted = FormatPropertyValue(propDiff.theirsValue);
                    bool   isDeletion      = string.IsNullOrEmpty(propDiff.theirsValue) && !string.IsNullOrEmpty(propDiff.oursValue);

                    changes.Add(new PropertyChange
                    {
                        propertyName       = propDiff.propertyName,
                        oursValue          = oursFormatted,
                        theirsValue        = theirsFormatted ?? "[Deleted]",
                        isConflict         = propDiff.isConflict,
                        componentType      = componentType,
                        gameObjectName     = gameObjectName,
                        displayPath        = displayPath,
                        isDeletion         = isDeletion,
                        blockID            = id,
                        blockCategory      = rep.category,
                        oursWins           = oursWins,
                        isSceneRoots       = rep.category == BlockCategory.SceneRoots,
                        oursBlockContent   = oursContent,
                        theirsBlockContent = theirsContent,
                        baseBlockContent   = baseContent
                    });
                }
            }
        }

        private bool HasPropertyChanges(BlockCategory category, string baseContent, string oursContent)
        {
            if (string.IsNullOrEmpty(baseContent) || string.IsNullOrEmpty(oursContent))
                return false;

            if (category == BlockCategory.PrefabInstance)
                return baseContent != oursContent;

            var baseProps = ParseProperties(baseContent);
            var oursProps = ParseProperties(oursContent);

            var allKeys = new HashSet<string>();
            allKeys.UnionWith(baseProps.Keys);
            allKeys.UnionWith(oursProps.Keys);

            foreach (var key in allKeys)
            {
                baseProps.TryGetValue(key, out var baseVal);
                oursProps.TryGetValue(key, out var oursVal);
                if (baseVal != oursVal) return true;
            }

            return false;
        }

        private bool HasComponentChangesForGameObject(string goID)
        {
            foreach (var kvp in oursBlocks)
            {
                var block = kvp.Value;
                if (block.parentGoID != goID) continue;
                if (!baseBlocks.TryGetValue(kvp.Key, out var baseBlock)) continue;
                if (theirsBlocks.ContainsKey(kvp.Key)) continue;  // still in theirs, handled elsewhere
                if (HasPropertyChanges(block.category, baseBlock.fullContent, block.fullContent))
                    return true;
            }
            return false;
        }

        private bool HasComponentChangesForGameObjectInTheirs(string goID)
        {
            foreach (var kvp in theirsBlocks)
            {
                var block = kvp.Value;
                if (block.parentGoID != goID) continue;
                if (!baseBlocks.TryGetValue(kvp.Key, out var baseBlock)) continue;
                if (oursBlocks.ContainsKey(kvp.Key)) continue;  // still in ours, handled elsewhere
                if (HasPropertyChanges(block.category, baseBlock.fullContent, block.fullContent))
                    return true;
            }
            return false;
        }

        private static string BuildDisplayPath(string gameObjectName, string componentType)
        {
            if (!string.IsNullOrEmpty(gameObjectName))
                return $"{gameObjectName} / {componentType ?? "Unknown"}";
            return componentType ?? "Unknown";
        }

        private string GetBlockName(string fileID)
        {
            if (fileID == "0") return "None";

            if (oursBlocks.TryGetValue(fileID, out var block) && block.name != null)       return block.name;
            if (theirsBlocks.TryGetValue(fileID, out block) && block.name != null)         return block.name;
            if (baseBlocks.TryGetValue(fileID, out block) && block.name != null)           return block.name;

            if (oursBlocks.TryGetValue(fileID, out block) && block.objectType != null)     return block.objectType;
            if (theirsBlocks.TryGetValue(fileID, out block) && block.objectType != null)   return block.objectType;
            if (baseBlocks.TryGetValue(fileID, out block) && block.objectType != null)     return block.objectType;

            return $"Object {fileID}";
        }

        private string FormatPropertyValue(string value)
        {
            if (string.IsNullOrEmpty(value)) return value;

            return Regex.Replace(
                value,
                @"-\s*\{fileID:\s*(\d+)\}|\{fileID:\s*(\d+)\}",
                match =>
                {
                    string fileID      = match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Value;
                    string objectName  = GetBlockName(fileID);
                    if (objectName.StartsWith("Object "))
                        return $"{{fileID: {fileID}}}";
                    return $"{objectName} ({{fileID: {fileID}}})";
                });
        }
    }
}
