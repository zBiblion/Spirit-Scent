using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Simple status window showing installation and license status.
    /// Opened via Window > Overdrive > Scene Merge, or automatically after install/update.
    /// </summary>
    public class SceneMergeStatus : EditorWindow
    {
        [MenuItem("Window/Overdrive/Scene Merge")]
        public static void ShowWindow()
        {
            var window = GetWindow<SceneMergeStatus>("Scene Merge");
            window.minSize = new Vector2(400, 200);
        }

        private void OnEnable()
        {
            EnsureVersionFileExists();
        }

        private void OnGUI()
        {
            GUILayout.Label("Scene Merge Status", EditorStyles.boldLabel);
            GUILayout.Space(10);

            // Installation status
            if (SceneMergeInstaller.IsInstalled())
            {
                EditorGUILayout.HelpBox("✓ CLI Tool Installed and Active", MessageType.Info);
                EditorGUILayout.LabelField("Location:", SceneMergeInstaller.GetInstalledToolPath());

                string toolVersion = GetMergeToolVersion();
                if (!string.IsNullOrEmpty(toolVersion))
                {
                    EditorGUILayout.LabelField("Tool Version:", toolVersion);
                }
            }
            else
            {
                EditorGUILayout.HelpBox("CLI Tool Not Installed", MessageType.Warning);
                if (GUILayout.Button("Install Now"))
                {
                    SceneMergeInstaller.ForceReinstall();
                }
            }

            GUILayout.Space(10);

            // Git configuration status
            if (SceneMergeInstaller.IsGitConfigured())
            {
                EditorGUILayout.HelpBox("✓ Git Configured", MessageType.Info);
            }
            else
            {
                string gitError = SceneMergeInstaller.GetGitConfigError();
                if (gitError == SceneMergeInstaller.GIT_ERROR_NOT_A_REPO)
                {
                    EditorGUILayout.HelpBox(
                        "Git driver not yet registered — this project has no git repository.\n" +
                        "Initialize one (git init or clone), then click Reconfigure Git.",
                        MessageType.Warning
                    );
                }
                else
                {
                    EditorGUILayout.HelpBox(
                        string.IsNullOrEmpty(gitError)
                            ? "Git Not Configured for Scene Merges"
                            : $"Git Configuration Failed:\n{gitError}",
                        MessageType.Warning
                    );
                    EditorGUILayout.HelpBox(
                        "Make sure git is installed and accessible from the command line, then click Reconfigure Git.",
                        MessageType.None
                    );
                }
                if (GUILayout.Button("Reconfigure Git"))
                {
                    string error = SceneMergeInstaller.ReconfigureGit();
                    if (string.IsNullOrEmpty(error))
                        Repaint();
                    else if (error == SceneMergeInstaller.GIT_ERROR_NOT_A_REPO)
                        Repaint(); // message already shown above
                    else
                        EditorUtility.DisplayDialog("Git Configuration Failed", error, "OK");
                }
            }

            GUILayout.Space(10);

            // License status
            bool hasLicense = HasValidLicense();
            if (hasLicense)
            {
                EditorGUILayout.HelpBox("✓ License Active", MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox("No License Found", MessageType.Warning);
                EditorGUILayout.HelpBox(
                    "Please activate your license in the Toolset Manager:\n" +
                    "Window > Overdrive > Toolset Manager",
                    MessageType.None
                );
                if (GUILayout.Button("Open Toolset Manager"))
                {
                    EditorApplication.ExecuteMenuItem("Window/Overdrive/Toolset Manager");
                }
            }

            GUILayout.FlexibleSpace();

            // Footer
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Documentation", GUILayout.Width(120)))
            {
                Application.OpenURL("https://overdrivetoolset.com/scene-merge/docs");
            }
            if (GUILayout.Button("Support", GUILayout.Width(120)))
            {
                Application.OpenURL("https://overdrivetoolset.com/support");
            }
            GUILayout.EndHorizontal();
        }

        private bool HasValidLicense()
        {
            // Ask Toolset Manager if this product is licensed
            return Overdrive.ToolsetManager.OverdriveToolsetManager.IsProductLicensed(889);
        }

        private static string GetVersionFilePath()
        {
            string versionDir = Application.platform == RuntimePlatform.WindowsEditor
                ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Overdrive", "SceneMerge")
                : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Library", "Application Support", "Overdrive", "SceneMerge");
            return Path.Combine(versionDir, "toolVersion.txt");
        }

        private string GetMergeToolVersion()
        {
            try
            {
                string versionPath = GetVersionFilePath();
                if (File.Exists(versionPath))
                {
                    string version = File.ReadAllText(versionPath).Trim();
                    if (!string.IsNullOrEmpty(version))
                        return version;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[Scene Merge] Failed to read tool version: {ex.Message}");
            }

            return "Unknown";
        }

        private void EnsureVersionFileExists()
        {
            try
            {
                string versionPath = GetVersionFilePath();

                // If version file doesn't exist, create it with a default placeholder version
                if (!File.Exists(versionPath))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(versionPath));
                    File.WriteAllText(versionPath, "1.0.0");
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[Scene Merge] Failed to ensure version file exists: {ex.Message}");
            }
        }
    }
}
