using UnityEditor;
using UnityEngine;
using System.IO;
using System.Linq;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Handles test and validation operations for scene merge functionality.
    /// </summary>
    public static class SceneMergeTestRunner
    {
        [MenuItem("Tools/Overdrive/Scene Merge/TEST Apply Stash To Merge Result")]
        public static void TestApplyStashToMergeResult()
        {
            string resultAssetPath = "Assets/Merge Testing/MergeTest_Result.unity";
            string resultAbsPath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Result.unity");
            string mergeTestingDir = Path.Combine(Application.dataPath, "Merge Testing");
            string logPath = Path.Combine(Application.dataPath, "Merge Testing", "SceneMergeTest_StashApply.log");
            var logDir = Path.GetDirectoryName(logPath);
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            using (var logWriter = new StreamWriter(logPath, false))
            {
                logWriter.WriteLine("=== Scene Merge Test Apply Stash ===");
                logWriter.WriteLine($"Timestamp: {System.DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                logWriter.WriteLine();

                try
                {
                    if (!File.Exists(resultAbsPath))
                    {
                        logWriter.WriteLine($"ERROR: Merge result not found: {resultAbsPath}");
                        Debug.LogWarning($"[SceneMerge] Merge result not found: {resultAbsPath}");
                        return;
                    }

                    if (!Directory.Exists(mergeTestingDir))
                    {
                        logWriter.WriteLine($"ERROR: Merge Testing folder not found: {mergeTestingDir}");
                        Debug.LogWarning($"[SceneMerge] Merge Testing folder not found: {mergeTestingDir}");
                        return;
                    }

                    var stashFiles = Directory.GetFiles(mergeTestingDir, "*.stash", SearchOption.TopDirectoryOnly)
                        .OrderBy(path => path)
                        .ToList();

                    if (stashFiles.Count == 0)
                    {
                        logWriter.WriteLine($"ERROR: No stash files found in: {mergeTestingDir}");
                        Debug.LogWarning($"[SceneMerge] No stash files found in Merge Testing folder: {mergeTestingDir}");
                        return;
                    }

                    string sourceStashPath = stashFiles[0];
                    string resultStashPath = YAMLStash.GetStashPath(resultAssetPath);

                    if (!string.Equals(sourceStashPath, resultStashPath, System.StringComparison.OrdinalIgnoreCase))
                    {
                        File.Copy(sourceStashPath, resultStashPath, true);
                        logWriter.WriteLine($"Using stash: {sourceStashPath}");
                        logWriter.WriteLine($"Copied to: {resultStashPath}");
                    }
                    else
                    {
                        logWriter.WriteLine($"Using stash: {resultStashPath}");
                    }

                    logWriter.WriteLine($"Applying stash to: {resultAssetPath}");
                    logWriter.Flush();

                    bool applied = YAMLStashApplicator.ApplyStashes(resultAssetPath);
                    logWriter.WriteLine(applied ? "Stash applied successfully." : "Stash apply canceled or failed.");

                    if (applied && !string.Equals(sourceStashPath, resultStashPath, System.StringComparison.OrdinalIgnoreCase))
                    {
                        if (File.Exists(sourceStashPath))
                            File.Delete(sourceStashPath);
                    }
                }
                catch (System.Exception ex)
                {
                    logWriter.WriteLine($"ERROR: {ex.Message}");
                    logWriter.WriteLine($"Stack trace: {ex.StackTrace}");
                    Debug.LogError($"[SceneMerge] Apply stash test failed: {ex.Message}");
                }
            }

            Debug.Log($"[SceneMerge] Stash apply test log written to: {logPath}");
        }

        [MenuItem("Tools/Overdrive/Scene Merge/TEST Preview Pull Changes")]
        public static void ShowWindowTest()
        {
            var logPath = Path.Combine(Application.dataPath, "Merge Testing", "SceneMergeTest.log");
            var logDir = Path.GetDirectoryName(logPath);
            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            YAMLCompare previewComparison = null;

            using (var logWriter = new StreamWriter(logPath, false))
            {
                logWriter.WriteLine("=== Scene Merge Test Preview ===");
                logWriter.WriteLine($"Timestamp: {System.DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                logWriter.WriteLine();

                try
                {
                    logWriter.WriteLine("Step 1: Running preview comparison...");
                    logWriter.Flush();
                    
                    string basePath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Base.unity");
                    string oursPath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Ours.unity");
                    string theirsPath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Theirs.unity");
                    
                    // Run comparison and capture the result
                    previewComparison = new YAMLCompare();
                    previewComparison.CompareFiles(basePath, oursPath, theirsPath);
                    PullPreviewWindow.ShowWindow(previewComparison, null, "Assets/Merge Testing/MergeTest_Ours.unity");
                    
                    logWriter.WriteLine($"Preview detected {previewComparison.changes.Count} changes");
                    logWriter.WriteLine();
                    
                    // Check for critical conflicts (ID collisions) that will crash UnityYAMLMerge
                    var idCollisions = previewComparison.changes.Where(c => c.hasIDCollision).ToList();
                    if (idCollisions.Count > 0)
                    {
                        logWriter.WriteLine("⛔ CRITICAL CONFLICTS DETECTED - MERGE ABORTED");
                        logWriter.WriteLine();
                        logWriter.WriteLine($"Found {idCollisions.Count} ID collision(s) that would crash UnityYAMLMerge:");
                        logWriter.WriteLine();
                        
                        foreach (var collision in idCollisions)
                        {
                            logWriter.WriteLine($"  Block ID {collision.blockID}: {collision.blockName ?? collision.blockType}");
                            logWriter.WriteLine($"    Ours:   ClassID {collision.oursTypeID}");
                            logWriter.WriteLine($"    Theirs: ClassID {collision.theirsTypeID}");
                            logWriter.WriteLine($"    (Same ID used for different component types)");
                            logWriter.WriteLine();
                        }
                        
                        logWriter.WriteLine("MERGE SKIPPED - Fix ID collisions first using the Pull Preview window.");
                        logWriter.WriteLine("Click 'Fix ID Collision' button for each conflict, then re-run the test.");
                        
                        Debug.LogError($"[SceneMerge] ⛔ Merge aborted - {idCollisions.Count} ID collision(s) detected. Fix in Pull Preview window.");
                    }
                    else
                    {
                        // No critical conflicts - safe to proceed with merge
                        logWriter.WriteLine("Step 2: Performing actual merge with UnityYAMLMerge...");
                        logWriter.Flush();
                        
                        string outputPath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Result.unity");
                        
                        bool mergeSuccess = PerformUnityMerge(basePath, oursPath, theirsPath, outputPath, logWriter);
                    
                        if (mergeSuccess)
                        {
                            logWriter.WriteLine($"Merge completed successfully. Result written to: {outputPath}");
                            logWriter.WriteLine();
                            
                            // Step 3: Validate the merge result
                            logWriter.WriteLine("Step 3: Validating merge result...");
                            logWriter.Flush();
                            
                            ValidateMergeResult(basePath, oursPath, theirsPath, outputPath, previewComparison, logWriter);
                            
                            // Step 4: Compare to expected result if available
                            string wantPath = Path.Combine(Application.dataPath, "Merge Testing", "MergeTest_Want.unity");
                            if (File.Exists(wantPath))
                            {
                                logWriter.WriteLine();
                                logWriter.WriteLine("Step 4: Comparing to expected result (MergeTest_Want.unity)...");
                                logWriter.Flush();
                                
                                CompareToExpected(outputPath, wantPath, logWriter);
                            }
                            else
                            {
                                logWriter.WriteLine();
                                logWriter.WriteLine("Step 4: Skipped - MergeTest_Want.unity not found");
                            }
                            
                            Debug.Log($"[SceneMerge] Merge result saved to: {outputPath}");
                        }
                        else
                        {
                            logWriter.WriteLine("Merge failed - see log for details.");
                            Debug.LogWarning("[SceneMerge] Merge failed - check log for details.");
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    logWriter.WriteLine($"ERROR: {ex.Message}");
                    logWriter.WriteLine($"Stack trace: {ex.StackTrace}");
                    Debug.LogError($"[SceneMerge] Test failed: {ex.Message}");
                }
            }

            Debug.Log($"[SceneMerge] Test log written to: {logPath}");
        }

        public static bool PerformUnityMerge(string basePath, string oursPath, string theirsPath, string outputPath, StreamWriter logWriter)
        {
            try
            {
                // Validate input files exist
                if (!File.Exists(basePath))
                {
                    logWriter.WriteLine($"ERROR: Base file not found: {basePath}");
                    return false;
                }
                if (!File.Exists(oursPath))
                {
                    logWriter.WriteLine($"ERROR: Ours file not found: {oursPath}");
                    return false;
                }
                if (!File.Exists(theirsPath))
                {
                    logWriter.WriteLine($"ERROR: Theirs file not found: {theirsPath}");
                    return false;
                }

                // Find UnityYAMLMerge.exe
                string unityYamlMergePath = SceneMergeGitOperations.FindUnityYAMLMerge();
                if (string.IsNullOrEmpty(unityYamlMergePath))
                {
                    logWriter.WriteLine("ERROR: Could not locate UnityYAMLMerge.exe");
                    return false;
                }
                
                logWriter.WriteLine($"Using UnityYAMLMerge at: {unityYamlMergePath}");
                logWriter.WriteLine($"Base:   {basePath}");
                logWriter.WriteLine($"Ours:   {oursPath}");
                logWriter.WriteLine($"Theirs: {theirsPath}");
                logWriter.WriteLine($"Output: {outputPath}");
                logWriter.Flush();

                // Run UnityYAMLMerge
                var psi = new System.Diagnostics.ProcessStartInfo(unityYamlMergePath)
                {
                    Arguments = $"merge --fallback none -p \"{basePath}\" \"{oursPath}\" \"{theirsPath}\" \"{outputPath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                logWriter.WriteLine($"Running: {unityYamlMergePath} {psi.Arguments}");
                logWriter.Flush();

                using (var proc = System.Diagnostics.Process.Start(psi))
                {
                    string output = proc.StandardOutput.ReadToEnd();
                    string error = proc.StandardError.ReadToEnd();
                    proc.WaitForExit();

                    logWriter.WriteLine($"Exit code: {proc.ExitCode}");
                    
                    if (!string.IsNullOrEmpty(output))
                    {
                        logWriter.WriteLine("STDOUT:");
                        logWriter.WriteLine(output);
                    }
                    
                    if (!string.IsNullOrEmpty(error))
                    {
                        logWriter.WriteLine("STDERR:");
                        logWriter.WriteLine(error);
                    }

                    // Exit codes:
                    // 0 = clean merge (no conflicts)
                    // 2 = conflicts resolved (ours kept)
                    // other = failure
                    if (proc.ExitCode == 0)
                    {
                        logWriter.WriteLine("SUCCESS: Clean merge (no conflicts)");
                        return true;
                    }
                    else if (proc.ExitCode == 2)
                    {
                        logWriter.WriteLine("SUCCESS: Conflicts resolved (ours kept)");
                        return true;
                    }
                    else
                    {
                        logWriter.WriteLine($"FAILURE: UnityYAMLMerge exited with code {proc.ExitCode}");
                        return false;
                    }
                }
            }
            catch (System.Exception ex)
            {
                logWriter.WriteLine($"EXCEPTION during merge: {ex.Message}");
                logWriter.WriteLine(ex.StackTrace);
                return false;
            }
        }

        public static void ValidateMergeResult(string basePath, string oursPath, string theirsPath, string resultPath, 
            YAMLCompare previewComparison, StreamWriter logWriter)
        {
            try
            {
                logWriter.WriteLine("Parsing merge result...");
                
                // Compare result against ours to see what actually changed
                var resultComparison = new YAMLCompare();
                resultComparison.CompareFiles(oursPath, resultPath);
                
                logWriter.WriteLine($"Result has {resultComparison.changes.Count} differences from ours");
                
                // Expected behavior: Result should include "theirs" additions and may resolve conflicts via deletion
                int unexpectedChanges = 0;
                int expectedAdditions = 0;
                int expectedConflicts = 0;
                int expectedOverwrites = 0;
                int unexpectedDeletions = 0;
                
                // Build a map of preview conflicts where theirs deleted (modify-delete conflicts)
                var modifyDeleteConflicts = new System.Collections.Generic.HashSet<string>(
                    previewComparison.changes
                        .Where(c => c.changeType == YAMLCompare.ChangeType.Conflict && c.theirsContent == null)
                        .Select(c => c.blockID));
                
                // Check that all "Added" items from preview are in the result
                var previewAdditions = previewComparison.changes.Where(c => c.changeType == YAMLCompare.ChangeType.Added).ToList();
                foreach (var addition in previewAdditions)
                {
                    // This block should now exist in result (check theirsBlocks which is the result file)
                    if (resultComparison.theirsBlocks.ContainsKey(addition.blockID))
                    {
                        expectedAdditions++;
                    }
                    else
                    {
                        logWriter.WriteLine($"  WARNING: Addition not found in result - {addition.blockCategory} {addition.blockName ?? addition.blockID}");
                        unexpectedChanges++;
                    }
                }
                
                // Check for overwrites (modify-delete conflicts where deletion wins)
                var resultDeletions = resultComparison.changes.Where(c => c.changeType == YAMLCompare.ChangeType.Deleted).ToList();
                foreach (var deletion in resultDeletions)
                {
                    if (modifyDeleteConflicts.Contains(deletion.blockID))
                    {
                        // Expected overwrite - we modified, they deleted, deletion wins
                        expectedOverwrites++;
                        logWriter.WriteLine($"  OVERWRITE: Local changes discarded (deletion wins) - {deletion.blockCategory} {deletion.blockName ?? deletion.blockID}");
                    }
                    else
                    {
                        // Truly unexpected deletion
                        unexpectedDeletions++;
                        logWriter.WriteLine($"  WARNING: Unexpected deletion in result - {deletion.blockCategory} {deletion.blockName ?? deletion.blockID}");
                    }
                }
                
                // Check that other conflicts were processed
                var previewConflicts = previewComparison.changes
                    .Where(c => c.changeType == YAMLCompare.ChangeType.Conflict && c.theirsContent != null)
                    .ToList();
                expectedConflicts = previewConflicts.Count;
                
                logWriter.WriteLine();
                logWriter.WriteLine("Validation Summary:");
                logWriter.WriteLine($"  Expected additions applied: {expectedAdditions}/{previewAdditions.Count}");
                logWriter.WriteLine($"  Conflicts resolved: {expectedConflicts}");
                logWriter.WriteLine($"  Expected overwrites (deletion wins): {expectedOverwrites}");
                logWriter.WriteLine($"  Unexpected deletions: {unexpectedDeletions}");
                logWriter.WriteLine($"  Other unexpected changes: {unexpectedChanges}");
                
                if (unexpectedChanges == 0 && unexpectedDeletions == 0 && expectedAdditions == previewAdditions.Count)
                {
                    logWriter.WriteLine();
                    logWriter.WriteLine("✓ VALIDATION PASSED - Merge result matches preview expectations");
                }
                else
                {
                    logWriter.WriteLine();
                    logWriter.WriteLine("⚠ VALIDATION WARNINGS - Some discrepancies detected (see above)");
                }
            }
            catch (System.Exception ex)
            {
                logWriter.WriteLine($"ERROR during validation: {ex.Message}");
                logWriter.WriteLine(ex.StackTrace);
            }
        }

        public static void CompareToExpected(string resultPath, string expectedPath, StreamWriter logWriter)
        {
            try
            {
                logWriter.WriteLine($"Comparing result to expected output...");
                
                var comparison = new YAMLCompare();
                comparison.CompareFiles(resultPath, expectedPath);
                
                if (comparison.changes.Count == 0)
                {
                    logWriter.WriteLine();
                    logWriter.WriteLine("✓ PERFECT MATCH - Result exactly matches MergeTest_Want.unity");
                    Debug.Log("[SceneMerge] ✓ Result matches expected output!");
                }
                else
                {
                    logWriter.WriteLine();
                    logWriter.WriteLine($"⚠ DIFFERENCES FOUND - Result differs from expected in {comparison.changes.Count} blocks:");
                    logWriter.WriteLine();
                    
                    var byType = comparison.changes.GroupBy(c => c.changeType).ToDictionary(g => g.Key, g => g.Count());
                    foreach (var kvp in byType)
                        logWriter.WriteLine($"  {kvp.Key}: {kvp.Value}");
                    
                    logWriter.WriteLine();
                    logWriter.WriteLine("Detailed differences:");
                    
                    foreach (var change in comparison.changes.Take(20))  // Limit to first 20 for readability
                    {
                        logWriter.WriteLine($"  [{change.changeType}] {change.blockCategory} - {change.blockName ?? change.blockType} (ID: {change.blockID})");
                        
                        if (change.propertyDiffs != null && change.propertyDiffs.Count > 0)
                        {
                            foreach (var diff in change.propertyDiffs.Take(3))
                            {
                                logWriter.WriteLine($"    • {diff.propertyName}:");
                                logWriter.WriteLine($"      Result:   {SceneMergeLogger.TruncateForLog(diff.oursValue)}");
                                logWriter.WriteLine($"      Expected: {SceneMergeLogger.TruncateForLog(diff.theirsValue)}");
                            }
                        }
                    }
                    
                    if (comparison.changes.Count > 20)
                        logWriter.WriteLine($"  ... and {comparison.changes.Count - 20} more differences");
                    
                    Debug.LogWarning($"[SceneMerge] ⚠ Result differs from expected in {comparison.changes.Count} blocks - check log");
                }
            }
            catch (System.Exception ex)
            {
                logWriter.WriteLine($"ERROR comparing to expected: {ex.Message}");
                logWriter.WriteLine(ex.StackTrace);
            }
        }
    }
}
