using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Applies stashed property values to scene files.
    /// Uses a similar approach to Scene Blocks for parsing and patching YAML.
    /// </summary>
    public static class YAMLStashApplicator
    {
        private static readonly Regex BlockHeaderRegex = new Regex(@"^--- !u!(\d+) &(\d+)", RegexOptions.Compiled);
        private static readonly Regex PropertyRegex = new Regex(@"^(\s*)(\w+):\s*(.*)$", RegexOptions.Compiled);

        /// <summary>
        /// Applies all stashed properties for the active scene.
        /// </summary>
        [MenuItem("Tools/Overdrive/Scene Merge/Apply Stashes", false, 50)]
        public static void ApplyStashesForActiveScene()
        {
            var scene = EditorSceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(scene.path))
            {
                EditorUtility.DisplayDialog("No Scene", "No scene is currently open.", "OK");
                return;
            }

            ApplyStashes(scene.path);
        }

        /// <summary>
        /// Applies stashed properties for the given scene file.
        /// </summary>
        public static bool ApplyStashes(string sceneAssetPath)
        {
            // Check if stash exists
            if (!YAMLStash.HasStash(sceneAssetPath))
            {
                EditorUtility.DisplayDialog("No Stash", 
                    $"No stash file found for {Path.GetFileName(sceneAssetPath)}.", 
                    "OK");
                return false;
            }

            // Load the stash
            var stash = YAMLStash.LoadStash(sceneAssetPath);
            if (stash == null || stash.entries.Count == 0)
            {
                EditorUtility.DisplayDialog("Empty Stash", 
                    $"Stash file is empty for {Path.GetFileName(sceneAssetPath)}.", 
                    "OK");
                return false;
            }

            // Get absolute path
            string absScenePath = sceneAssetPath;
            if (sceneAssetPath.StartsWith("Assets/"))
            {
                absScenePath = Path.Combine(Application.dataPath, sceneAssetPath.Substring(7));
            }

            // Confirm with user
            bool confirm = EditorUtility.DisplayDialog("Apply Stashes",
                $"Apply {stash.entries.Count} stashed properties to {Path.GetFileName(sceneAssetPath)}?\n\n" +
                $"This will modify the scene file and cannot be undone except through version control.\n\n" +
                $"Make sure the scene is saved before applying stashes.",
                "Apply", "Cancel");

            if (!confirm)
                return false;

            try
            {
                // Read the scene file
                string sceneContent = File.ReadAllText(absScenePath);

                // Sort stash entries to ensure entities are restored before their references
                // 1. Full entities first (__FULL_ENTITY__)
                // 2. Then dependent references
                // 3. Then regular property stashes
                var sortedEntries = stash.entries.OrderBy(e =>
                {
                    if (e.propertyPath == "__FULL_ENTITY__") return 0;  // Entities first
                    if (e.isDependentReference) return 1;                // References second
                    return 2;                                            // Regular properties last
                }).ToList();

                // Apply each stash entry
                foreach (var entry in sortedEntries)
                {
                    sceneContent = ApplyStashEntry(sceneContent, entry);
                }

                // Write back to file
                File.WriteAllText(absScenePath, sceneContent);

                // Delete the stash file
                YAMLStash.DeleteStash(sceneAssetPath);

                // Refresh Unity's asset database
                AssetDatabase.Refresh();

                // Reload the scene if it's currently open
                var activeScene = EditorSceneManager.GetActiveScene();
                if (activeScene.path == sceneAssetPath)
                {
                    EditorSceneManager.OpenScene(sceneAssetPath, OpenSceneMode.Single);
                }

                EditorUtility.DisplayDialog("Stashes Applied",
                    $"Successfully applied {stash.entries.Count} stashed properties.\n\n" +
                    $"The stash file has been deleted.",
                    "OK");

                Debug.Log($"Applied {stash.entries.Count} stashed properties to {Path.GetFileName(sceneAssetPath)}");
                return true;
            }
            catch (Exception e)
            {
                EditorUtility.DisplayDialog("Error",
                    $"Failed to apply stashes:\n{e.Message}",
                    "OK");
                Debug.LogError($"Failed to apply stashes: {e}");
                return false;
            }
        }

        /// <summary>
        /// Applies a single stash entry to the scene content.
        /// </summary>
        private static string ApplyStashEntry(string sceneContent, YAMLStash.StashEntry entry)
        {
            // Special handling for full entity stashing
            if (entry.propertyPath == "__FULL_ENTITY__")
            {
                return ApplyFullEntityStash(sceneContent, entry);
            }
            
            // Regular property-level stashing
            var lines = sceneContent.Split('\n').ToList();
            
            // Find the block with the matching fileID
            int blockStartIndex = FindBlockStart(lines, entry.blockId);
            if (blockStartIndex < 0)
            {
                Debug.LogWarning($"Block {entry.blockId} not found in scene. Skipping stash entry for {entry.propertyPath}");
                return sceneContent;
            }

            // Find the block end
            int blockEndIndex = FindBlockEnd(lines, blockStartIndex);

            // Find the property within the block
            int propertyIndex = FindProperty(lines, blockStartIndex, blockEndIndex, entry.propertyPath);

            if (propertyIndex >= 0)
            {
                // Property exists - replace it
                var match = PropertyRegex.Match(lines[propertyIndex]);
                if (match.Success)
                {
                    string indent = match.Groups[1].Value;
                    string propertyName = match.Groups[2].Value;
                    
                    // Check if the value is multi-line (starts with newline or is a multi-line structure)
                    if (IsMultiLineValue(entry.value))
                    {
                        // Handle multi-line properties (vectors, arrays, etc.)
                        lines[propertyIndex] = $"{indent}{propertyName}:{entry.value}";
                    }
                    else
                    {
                        lines[propertyIndex] = $"{indent}{propertyName}: {entry.value}";
                    }
                    
                    Debug.Log($"Updated {entry.blockType}.{entry.propertyPath} in block {entry.blockId}");
                }
            }
            else
            {
                // Property doesn't exist - add it
                // Insert at the end of the block (before the next block or end of file)
                int insertIndex = blockEndIndex > 0 ? blockEndIndex : lines.Count;
                
                // Determine appropriate indentation (use the same as other properties in this block)
                string indent = DetermineIndentation(lines, blockStartIndex, blockEndIndex);
                
                if (IsMultiLineValue(entry.value))
                {
                    lines.Insert(insertIndex, $"{indent}{entry.propertyPath}:{entry.value}");
                }
                else
                {
                    lines.Insert(insertIndex, $"{indent}{entry.propertyPath}: {entry.value}");
                }
                
                Debug.Log($"Added {entry.blockType}.{entry.propertyPath} to block {entry.blockId}");
            }

            return string.Join("\n", lines);
        }

        /// <summary>
        /// Applies a full entity stash by inserting or replacing an entire YAML block.
        /// </summary>
        private static string ApplyFullEntityStash(string sceneContent, YAMLStash.StashEntry entry)
        {
            var lines = sceneContent.Split('\n').ToList();
            
            // Check if the block already exists
            int existingBlockIndex = FindBlockStart(lines, entry.blockId);
            
            if (existingBlockIndex >= 0)
            {
                // Block exists - replace it
                int blockEnd = FindBlockEnd(lines, existingBlockIndex);
                
                // Remove the existing block
                lines.RemoveRange(existingBlockIndex, blockEnd - existingBlockIndex);
                
                // Insert the stashed content
                lines.InsertRange(existingBlockIndex, entry.value.Split('\n'));
                
                Debug.Log($"Replaced existing block {entry.blockId} with stashed {entry.source} version");
            }
            else
            {
                // Block doesn't exist - insert it
                // Find a good insertion point (after the last block, before the footer)
                int insertIndex = FindEntityInsertionPoint(lines);
                
                // Ensure proper spacing
                if (insertIndex > 0 && !string.IsNullOrWhiteSpace(lines[insertIndex - 1]))
                {
                    lines.Insert(insertIndex, "");
                    insertIndex++;
                }
                
                lines.InsertRange(insertIndex, entry.value.Split('\n'));
                
                Debug.Log($"Inserted stashed {entry.source} block {entry.blockId} ({entry.blockType})");
            }
            
            return string.Join("\n", lines);
        }

        /// <summary>
        /// Finds the best insertion point for a new entity block.
        /// </summary>
        private static int FindEntityInsertionPoint(List<string> lines)
        {
            // Insert before any footer/metadata at the end, or at the very end
            for (int i = lines.Count - 1; i >= 0; i--)
            {
                if (lines[i].TrimStart().StartsWith("--- !u!"))
                {
                    // Found the last YAML block, insert after it
                    int blockEnd = FindBlockEnd(lines, i);
                    return blockEnd;
                }
            }
            
            // No blocks found, insert at end
            return lines.Count;
        }

        /// <summary>
        /// Finds the start line index of a block with the given fileID.
        /// </summary>
        private static int FindBlockStart(List<string> lines, string fileId)
        {
            for (int i = 0; i < lines.Count; i++)
            {
                var match = BlockHeaderRegex.Match(lines[i]);
                if (match.Success && match.Groups[2].Value == fileId)
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// Finds the end line index of a block (the line before the next block starts).
        /// </summary>
        private static int FindBlockEnd(List<string> lines, int blockStartIndex)
        {
            for (int i = blockStartIndex + 1; i < lines.Count; i++)
            {
                if (lines[i].TrimStart().StartsWith("--- !u!"))
                {
                    return i;
                }
            }
            return lines.Count;
        }

        /// <summary>
        /// Finds a property within a block by its key.
        /// Returns the line index, or -1 if not found.
        /// </summary>
        private static int FindProperty(List<string> lines, int blockStart, int blockEnd, string propertyPath)
        {
            for (int i = blockStart; i < blockEnd && i < lines.Count; i++)
            {
                var match = PropertyRegex.Match(lines[i]);
                if (match.Success && match.Groups[2].Value == propertyPath)
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// Determines the appropriate indentation for properties in a block.
        /// </summary>
        private static string DetermineIndentation(List<string> lines, int blockStart, int blockEnd)
        {
            // Find the first property in the block and use its indentation
            for (int i = blockStart + 1; i < blockEnd && i < lines.Count; i++)
            {
                var match = PropertyRegex.Match(lines[i]);
                if (match.Success)
                {
                    return match.Groups[1].Value;
                }
            }
            // Default to 2 spaces
            return "  ";
        }

        /// <summary>
        /// Checks if a value should be treated as multi-line (vectors, objects, arrays).
        /// </summary>
        private static bool IsMultiLineValue(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;

            // Check if it starts with a newline or contains curly braces/brackets
            return value.StartsWith("\n") || 
                   value.StartsWith("\r") || 
                   (value.Contains("{") && value.Contains("}"));
        }
    }
}
