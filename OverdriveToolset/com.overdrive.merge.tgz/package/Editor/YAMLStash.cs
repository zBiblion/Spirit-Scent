using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Manages stash files for merge conflicts.
    /// Stashes store individual property values that would be discarded during a merge,
    /// allowing users to selectively apply them after the merge completes.
    /// </summary>
    [Serializable]
    public class YAMLStash
    {
        [SerializeField] public string sceneGuid;
        [SerializeField] public string scenePath;
        [SerializeField] public List<StashEntry> entries = new List<StashEntry>();

        [Serializable]
        public class StashEntry
        {
            [SerializeField] public string blockId;           // The fileID of the YAML block
            [SerializeField] public string blockType;         // Human-readable type (Transform, BoxCollider, etc)
            [SerializeField] public string blockName;         // Name of the GameObject (if applicable)
            [SerializeField] public string propertyPath;      // Property key (e.g., "m_LocalPosition")
            [SerializeField] public string value;             // The YAML value to apply
            [SerializeField] public string source;            // "ours" or "theirs"
            [SerializeField] public string timestamp;         // When this was stashed
            [SerializeField] public bool isDependentReference; // True if this is a reference to a stashed entity
            [SerializeField] public string referencedEntityId; // fileID of the entity this references (if isDependentReference)
        }

        /// <summary>
        /// Gets the stash file path for a given scene file.
        /// </summary>
        public static string GetStashPath(string sceneAssetPath)
        {
            return sceneAssetPath + ".stash";
        }

        /// <summary>
        /// Loads an existing stash file for the given scene.
        /// Returns null if no stash exists.
        /// </summary>
        public static YAMLStash LoadStash(string sceneAssetPath)
        {
            string stashPath = GetStashPath(sceneAssetPath);
            if (!File.Exists(stashPath))
                return null;

            try
            {
                string json = File.ReadAllText(stashPath);
                return JsonUtility.FromJson<YAMLStash>(json);
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to load stash file: {stashPath}\n{e.Message}");
                return null;
            }
        }

        /// <summary>
        /// Adds a property stash entry to the stash file.
        /// Creates the stash file if it doesn't exist.
        /// </summary>
        public static void AddStashEntry(string sceneAssetPath, string sceneGuid, StashEntry entry)
        {
            // Load existing stash or create new one
            YAMLStash stash = LoadStash(sceneAssetPath) ?? new YAMLStash
            {
                sceneGuid = sceneGuid,
                scenePath = sceneAssetPath
            };

            // Add timestamp
            entry.timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            // Check if this exact property is already stashed
            int existingIndex = stash.entries.FindIndex(e => 
                e.blockId == entry.blockId && 
                e.propertyPath == entry.propertyPath);

            if (existingIndex >= 0)
            {
                // Update existing entry
                stash.entries[existingIndex] = entry;
                Debug.Log($"Updated stash for {entry.blockType}.{entry.propertyPath} (block {entry.blockId})");
            }
            else
            {
                // Add new entry
                stash.entries.Add(entry);
                Debug.Log($"Stashed {entry.source} value for {entry.blockType}.{entry.propertyPath} (block {entry.blockId})");
            }

            SaveStash(sceneAssetPath, stash);
        }

        /// <summary>
        /// Removes a specific stash entry.
        /// </summary>
        public static void RemoveStashEntry(string sceneAssetPath, string blockId, string propertyPath)
        {
            YAMLStash stash = LoadStash(sceneAssetPath);
            if (stash == null)
                return;

            stash.entries.RemoveAll(e => e.blockId == blockId && e.propertyPath == propertyPath);

            if (stash.entries.Count == 0)
            {
                // Delete the stash file if no entries remain
                DeleteStash(sceneAssetPath);
            }
            else
            {
                SaveStash(sceneAssetPath, stash);
            }
        }

        /// <summary>
        /// Saves the stash to disk.
        /// </summary>
        private static void SaveStash(string sceneAssetPath, YAMLStash stash)
        {
            string stashPath = GetStashPath(sceneAssetPath);
            try
            {
                string json = JsonUtility.ToJson(stash, true);
                File.WriteAllText(stashPath, json);
                Debug.Log($"Stash saved: {stashPath} ({stash.entries.Count} entries)");
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to save stash file: {stashPath}\n{e.Message}");
            }
        }

        /// <summary>
        /// Deletes the stash file for the given scene.
        /// </summary>
        public static void DeleteStash(string sceneAssetPath)
        {
            string stashPath = GetStashPath(sceneAssetPath);
            if (File.Exists(stashPath))
            {
                File.Delete(stashPath);
                Debug.Log($"Stash deleted: {stashPath}");
            }
        }

        /// <summary>
        /// Checks if a stash exists for the given scene.
        /// </summary>
        public static bool HasStash(string sceneAssetPath)
        {
            return File.Exists(GetStashPath(sceneAssetPath));
        }

        /// <summary>
        /// Gets the number of stashed entries for the given scene.
        /// </summary>
        public static int GetStashCount(string sceneAssetPath)
        {
            var stash = LoadStash(sceneAssetPath);
            return stash?.entries.Count ?? 0;
        }

        /// <summary>
        /// Finds all property references to a specific fileID in the scene content.
        /// Returns a list of (blockId, propertyPath, fullValue) tuples.
        /// </summary>
        public static List<(string blockId, string blockType, string blockName, string propertyPath, string value)> FindReferencesToEntity(string sceneContent, string targetFileId)
        {
            var references = new List<(string, string, string, string, string)>();
            var lines = sceneContent.Split('\n');
            
            // Regex to match YAML block headers
            var blockHeaderRegex = new System.Text.RegularExpressions.Regex(@"^--- !u!(\d+) &(\d+)");
            // Regex to match object type line
            var objectTypeRegex = new System.Text.RegularExpressions.Regex(@"^(\w+):");
            // Regex to match m_Name property
            var nameRegex = new System.Text.RegularExpressions.Regex(@"^\s*m_Name:\s*(.+)");
            // Regex to match fileID references
            var fileIdRefRegex = new System.Text.RegularExpressions.Regex(@"\{fileID:\s*" + targetFileId + @"[,}\s]");
            // Regex to match property lines
            var propertyRegex = new System.Text.RegularExpressions.Regex(@"^(\s*)(\w+):\s*(.*)$");
            
            string currentBlockId = null;
            string currentBlockType = null;
            string currentBlockName = null;
            int currentBlockStart = -1;
            
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                
                // Check if this is a new block header
                var headerMatch = blockHeaderRegex.Match(line);
                if (headerMatch.Success)
                {
                    currentBlockId = headerMatch.Groups[2].Value;
                    currentBlockStart = i;
                    currentBlockType = null;
                    currentBlockName = null;
                    
                    // Look ahead for the object type
                    if (i + 1 < lines.Length)
                    {
                        var typeMatch = objectTypeRegex.Match(lines[i + 1]);
                        if (typeMatch.Success)
                        {
                            currentBlockType = typeMatch.Groups[1].Value;
                        }
                    }
                    continue;
                }
                
                // Check for m_Name property
                if (currentBlockId != null && currentBlockName == null)
                {
                    var nameMatch = nameRegex.Match(line);
                    if (nameMatch.Success)
                    {
                        currentBlockName = nameMatch.Groups[1].Value.Trim();
                    }
                }
                
                // Check if this line contains a reference to our target fileID
                if (currentBlockId != null && fileIdRefRegex.IsMatch(line))
                {
                    // Find the property name for this line
                    var propertyMatch = propertyRegex.Match(line);
                    if (propertyMatch.Success)
                    {
                        string propertyName = propertyMatch.Groups[2].Value;
                        string propertyValue = propertyMatch.Groups[3].Value;
                        
                        // Add this reference
                        references.Add((currentBlockId, currentBlockType ?? "Unknown", currentBlockName, propertyName, propertyValue));
                        
                        Debug.Log($"Found reference to fileID {targetFileId} in block {currentBlockId} ({currentBlockType}) property {propertyName}");
                    }
                }
            }
            
            return references;
        }
    }
}
