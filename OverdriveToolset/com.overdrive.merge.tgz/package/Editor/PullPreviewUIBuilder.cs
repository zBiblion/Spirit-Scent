using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Overdrive.Editor.Merge
{
    /// <summary>
    /// Handles UI construction for the Pull Preview window.
    /// </summary>
    public class PullPreviewUIBuilder
    {
        private readonly YAMLCompare _comparison;
        private readonly Dictionary<string, Texture2D> _iconCache = new Dictionary<string, Texture2D>();
        private readonly string _sceneAssetPath;
        private readonly Action<YAMLCompare.ChangeInfo, string, string, string> _onStashProperty;
        private readonly Action<YAMLCompare.ChangeInfo, string> _onStashEntity;
        private readonly Action<string> _onFixIDCollision;

        public PullPreviewUIBuilder(
            YAMLCompare comparison, 
            string sceneAssetPath,
            Action<YAMLCompare.ChangeInfo, string, string, string> onStashProperty,
            Action<YAMLCompare.ChangeInfo, string> onStashEntity,
            Action<string> onFixIDCollision)
        {
            _comparison = comparison;
            _sceneAssetPath = sceneAssetPath;
            _onStashProperty = onStashProperty;
            _onStashEntity = onStashEntity;
            _onFixIDCollision = onFixIDCollision;
        }

        public VisualElement CreateBlockGroup(string goId, YAMLCompare.ChangeInfo goChange, List<YAMLCompare.ChangeInfo> components)
        {
            bool hasConflict = goChange?.changeType == YAMLCompare.ChangeType.Conflict ||
                               (components?.Any(c => c.changeType == YAMLCompare.ChangeType.Conflict) ?? false);
            bool hasIDCollision = goChange?.hasIDCollision ?? false ||
                                  (components?.Any(c => c.hasIDCollision) ?? false);

            var group = new Foldout();
            group.text = $"{GetGoName(goId, null, goChange)} — ID {goId}";
            group.value = false;
            group.AddToClassList("block-group");
            if (hasConflict) group.AddToClassList("conflict");
            if (hasIDCollision) group.AddToClassList("id-conflict");

            // If there's an ID collision anywhere, only show the warnings - skip all other content
            if (hasIDCollision)
            {
                if (goChange?.hasIDCollision ?? false)
                    group.Add(CreateIDCollisionWarning(goChange));
                
                if (components != null)
                    foreach (var component in components.Where(c => c.hasIDCollision).OrderBy(c => c.blockName ?? c.blockType))
                        group.Add(CreateIDCollisionWarning(component));
            }
            else
            {
                // Normal display - no ID collisions
                if (goChange != null && goChange.propertyDiffs != null && goChange.propertyDiffs.Count > 0)
                    group.Add(CreateBlockItem(goChange));

                if (components != null)
                    foreach (var component in components.OrderBy(c => c.blockName ?? c.blockType))
                        group.Add(CreateBlockItem(component));
            }

            return group;
        }

        public VisualElement CreateSingleBlockGroup(YAMLCompare.ChangeInfo change, VisualElement note = null)
        {
            var group = new Foldout();
            group.text = $"{change.blockName ?? change.blockType} — ID {change.blockID}";
            group.value = false;
            group.AddToClassList("block-group");
            if (change.changeType == YAMLCompare.ChangeType.Conflict) group.AddToClassList("conflict");
            if (change.hasIDCollision) group.AddToClassList("id-conflict");

            // If there's an ID collision, only show the warning - skip all other content
            if (change.hasIDCollision)
            {
                group.Add(CreateIDCollisionWarning(change));
            }
            else
            {
                group.Add(CreateBlockItem(change, showHeader: false, note: note));
            }

            return group;
        }

        public VisualElement CreateIDCollisionWarning(YAMLCompare.ChangeInfo change)
        {
            var warningContainer = new VisualElement();
            warningContainer.AddToClassList("id-conflict-note");

            var warningLabel = new Label($"⚠ CRITICAL: ID Collision Detected\n" +
                $"Block: {change.blockName ?? change.blockType}\n" +
                $"Same ID ({change.blockID}) used for different component types:\n" +
                $"  • Ours: {change.blockType} (ClassID {change.oursTypeID})\n" +
                $"  • Theirs: ClassID {change.theirsTypeID}\n" +
                $"This will crash Unity's merge tool.");
            warningLabel.style.whiteSpace = WhiteSpace.Normal;
            warningLabel.style.marginBottom = 8;
            warningContainer.Add(warningLabel);

            var fixButton = new Button(() => _onFixIDCollision?.Invoke(change.blockID))
            {
                text = "Fix ID Collision (Renumber Ours)"
            };
            fixButton.style.marginTop = 4;
            warningContainer.Add(fixButton);

            return warningContainer;
        }

        public VisualElement BuildDeletionConflictNote(List<YAMLCompare.ChangeInfo> conflictingComponents, YAMLCompare.ChangeInfo goChange)
        {
            var parts = new List<string>();
            foreach (var comp in conflictingComponents)
            {
                if (comp.propertyDiffs != null && comp.propertyDiffs.Count > 0)
                {
                    var changedProps = comp.propertyDiffs
                        .Where(d => d.oursValue != null)
                        .Select(d => YAMLPropertyUI.HumanizePropertyName(d.propertyName))
                        .ToList();
                    parts.Add(changedProps.Count > 0
                        ? $"{comp.blockName ?? comp.blockType} ({string.Join(", ", changedProps)})"
                        : comp.blockName ?? comp.blockType);
                }
                else
                {
                    parts.Add(comp.blockName ?? comp.blockType);
                }
            }

            string what = string.Join(", ", parts);
            string objName = goChange?.blockName ?? "this object";
            var label = new Label($"You modified {what}, but {objName} has been removed. Deletion wins - your changes will be lost.");
            label.AddToClassList("conflict-notes");
            return label;
        }

        public VisualElement BuildDeletionConflictNoteReverse(List<YAMLCompare.ChangeInfo> conflictingComponents, YAMLCompare.ChangeInfo goChange)
        {
            var parts = new List<string>();
            foreach (var comp in conflictingComponents)
            {
                if (comp.propertyDiffs != null && comp.propertyDiffs.Count > 0)
                {
                    var changedProps = comp.propertyDiffs
                        .Where(d => d.theirsValue != null)
                        .Select(d => YAMLPropertyUI.HumanizePropertyName(d.propertyName))
                        .ToList();
                    parts.Add(changedProps.Count > 0
                        ? $"{comp.blockName ?? comp.blockType} ({string.Join(", ", changedProps)})"
                        : comp.blockName ?? comp.blockType);
                }
                else
                {
                    parts.Add(comp.blockName ?? comp.blockType);
                }
            }

            string what = string.Join(", ", parts);
            string objName = goChange?.blockName ?? "this object";
            var label = new Label($"Someone else modified {what}, but you removed {objName}. Deletion wins - their changes will be lost.");
            label.AddToClassList("conflict-notes");
            return label;
        }

        public VisualElement BuildComponentDeletionNote(YAMLCompare.ChangeInfo change)
        {
            string subject = change.blockName ?? change.blockType;
            
            if (change.propertyDiffs != null && change.propertyDiffs.Count > 0)
            {
                var changed = change.propertyDiffs
                    .Where(d => d.oursValue != null)
                    .Select(d => YAMLPropertyUI.HumanizePropertyName(d.propertyName))
                    .ToList();
                    
                string message = changed.Count > 0
                    ? $"You modified {string.Join(", ", changed)}, but {subject} has been removed. Deletion wins - your changes will be lost."
                    : $"You have local changes here, but {subject} has been removed. Deletion wins - your changes will be lost.";
                var label = new Label(message);
                label.AddToClassList("conflict-notes");
                return label;
            }
            else
            {
                var label = new Label($"You have local changes here, but {subject} has been removed. Deletion wins - your changes will be lost.");
                label.AddToClassList("conflict-notes");
                return label;
            }
        }

        public VisualElement BuildComponentDeletionNoteReverse(YAMLCompare.ChangeInfo change)
        {
            string subject = change.blockName ?? change.blockType;
            
            if (change.propertyDiffs != null && change.propertyDiffs.Count > 0)
            {
                var changed = change.propertyDiffs
                    .Where(d => d.theirsValue != null)
                    .Select(d => YAMLPropertyUI.HumanizePropertyName(d.propertyName))
                    .ToList();
                    
                string message = changed.Count > 0
                    ? $"Someone else modified {string.Join(", ", changed)}, but you removed {subject}. Deletion wins - their changes will be lost."
                    : $"Someone else has changes here, but you removed {subject}. Deletion wins - their changes will be lost.";
                var label = new Label(message);
                label.AddToClassList("conflict-notes");
                return label;
            }
            else
            {
                var label = new Label($"Someone else has changes here, but you removed {subject}. Deletion wins - their changes will be lost.");
                label.AddToClassList("conflict-notes");
                return label;
            }
        }

        private VisualElement CreateBlockItem(YAMLCompare.ChangeInfo change, bool showHeader = true, VisualElement note = null)
        {
            var blockItem = new VisualElement();
            blockItem.AddToClassList("block-item");
            bool isDeletionConflict = (change.changeType == YAMLCompare.ChangeType.Conflict && change.theirsContent == null)
                                   || (change.changeType == YAMLCompare.ChangeType.Deleted && note != null);
            blockItem.AddToClassList(isDeletionConflict ? "modify" : CssClass(change.changeType));
            blockItem.style.marginBottom = 4;

            if (showHeader)
            {
                var header = new VisualElement();
                header.style.flexDirection = FlexDirection.Row;

                var nameLabel = new Label(change.blockName ?? change.blockType);
                nameLabel.AddToClassList("block-title");
                var iconTexture = GetBlockIcon(change);
                if (iconTexture != null)
                    nameLabel.style.backgroundImage = new StyleBackground(iconTexture);
                header.Add(nameLabel);

                var idLabel = new Label($"ID {change.blockID}");
                idLabel.AddToClassList("id");
                header.Add(idLabel);

                blockItem.Add(header);
            }

            if (change.changeType == YAMLCompare.ChangeType.Modified ||
                change.changeType == YAMLCompare.ChangeType.Conflict)
            {
                if (change.changeType == YAMLCompare.ChangeType.Conflict && change.theirsContent == null)
                {
                    bool isGo = change.blockCategory == YAMLCompare.BlockCategory.GameObject;
                    blockItem.Add(MakeConflictRemovalItem(isGo ? "GameObject Removed" : "Removed", BuildComponentDeletionNote(change)));
                    
                    // Add stash button for component deletion (they deleted, we modified)
                    // GameObject-level buttons are handled in RefreshDisplay, not here
                    if (!isGo && !string.IsNullOrEmpty(_sceneAssetPath))
                    {
                        string entityName = change.blockName ?? change.blockType;
                        var stashButton = new UnityEngine.UIElements.Button(() => _onStashEntity?.Invoke(change, "ours"))
                        {
                            text = $"Stash Ours ({entityName})"
                        };
                        stashButton.AddToClassList("stash");
                        stashButton.tooltip = $"Save the entire {change.blockType} for restoration after merge";
                        blockItem.Add(stashButton);
                    }
                }
                else if (change.changeType == YAMLCompare.ChangeType.Conflict && change.oursContent == null)
                {
                    bool isGo = change.blockCategory == YAMLCompare.BlockCategory.GameObject;
                    blockItem.Add(MakeConflictRemovalItem(isGo ? "GameObject Removed" : "Removed", BuildComponentDeletionNoteReverse(change)));
                    
                    // Add stash button for component deletion (we deleted, they modified)
                    // GameObject-level buttons are handled in RefreshDisplay, not here
                    if (!isGo && !string.IsNullOrEmpty(_sceneAssetPath))
                    {
                        string entityName = change.blockName ?? change.blockType;
                        var stashButton = new UnityEngine.UIElements.Button(() => _onStashEntity?.Invoke(change, "theirs"))
                        {
                            text = $"Stash Theirs ({entityName})"
                        };
                        stashButton.AddToClassList("stash");
                        stashButton.tooltip = $"Save the entire {change.blockType} for restoration after merge";
                        blockItem.Add(stashButton);
                    }
                }
                else if (change.isArrayChange)
                {
                    var arrayProps = change.propertyDiffs?.Where(d => d.isArrayProperty).Select(d => d.propertyName).ToList() ?? new List<string>();
                    if (arrayProps.Count == 0)
                        blockItem.Add(MakeArrayChangeItem("Array properties"));
                    else
                        foreach (var propName in arrayProps)
                            blockItem.Add(MakeArrayChangeItem(propName));
                }
                else if (change.propertyDiffs != null && change.propertyDiffs.Count > 0)
                {
                    var diffs = FilterRotationDiffs(change.propertyDiffs);
                    foreach (var diff in diffs)
                    {
                        Action<string, string> onStashTheirs = null;
                        
                        // Property conflicts: Ours wins, so we show "Stash Theirs" to save the discarded value
                        if (diff.isConflict && !string.IsNullOrEmpty(_sceneAssetPath))
                        {
                            onStashTheirs = (propName, value) => _onStashProperty?.Invoke(change, propName, value, "theirs");
                        }
                        
                        blockItem.Add(YAMLPropertyUI.MakeDiffRow(diff.propertyName, diff.oursValue, diff.theirsValue, diff.isConflict, onStashTheirs, null));
                    }
                }
                else
                {
                    blockItem.Add(MakePropertyItem("(no property differences detected)", null));
                }
            }
            else
            {
                bool isGo = change.blockCategory == YAMLCompare.BlockCategory.GameObject;
                string label = change.changeType == YAMLCompare.ChangeType.Added
                    ? (isGo ? "GameObject Added" : "Added")
                    : (isGo ? "GameObject Removed" : "Removed");
                blockItem.Add(note != null
                    ? MakeConflictRemovalItem(label, note)
                    : MakePropertyItem(label, null));
            }

            return blockItem;
        }

        private VisualElement MakePropertyItem(string name, string values)
        {
            var row = new VisualElement();
            row.AddToClassList("property-item");

            var nameLabel = new Label(name);
            nameLabel.AddToClassList("property-name");
            row.Add(nameLabel);

            if (values != null)
                row.Add(new Label(values) { enableRichText = true });

            return row;
        }

        private VisualElement MakeConflictRemovalItem(string label, VisualElement note)
        {
            var row = new VisualElement();
            row.AddToClassList("property-item");
            row.AddToClassList("conflict");

            var nameLabel = new Label(label);
            nameLabel.AddToClassList("property-name");
            row.Add(nameLabel);
            row.Add(note);

            return row;
        }

        private VisualElement MakeArrayChangeItem(string propName)
        {
            var row = new VisualElement();
            row.AddToClassList("property-item");
            row.AddToClassList("modify");

            var nameLabel = new Label(YAMLPropertyUI.HumanizePropertyName(propName));
            nameLabel.AddToClassList("property-name");
            row.Add(nameLabel);

            var infoLabel = new Label("(array contents updated)");
            row.Add(infoLabel);

            return row;
        }

        private string CssClass(YAMLCompare.ChangeType changeType) => changeType switch
        {
            YAMLCompare.ChangeType.Added    => "add",
            YAMLCompare.ChangeType.Deleted  => "remove",
            YAMLCompare.ChangeType.Modified => "modify",
            YAMLCompare.ChangeType.Conflict => "modify",
            _                               => ""
        };

        private Texture2D GetBlockIcon(YAMLCompare.ChangeInfo change)
        {
            if (change == null) return null;

            if (string.Equals(change.blockType, "MonoBehaviour", StringComparison.OrdinalIgnoreCase))
            {
                var monoIcon = GetCachedIcon("cs Script Icon") ?? GetCachedIcon("Script Icon");
                if (monoIcon != null) return monoIcon;
            }

            var candidates = new List<string>();
            if (!string.IsNullOrEmpty(change.blockName))
                candidates.Add(change.blockName);
            if (!string.IsNullOrEmpty(change.blockType))
                candidates.Add(change.blockType);

            foreach (var candidate in candidates.Distinct())
            {
                var icon = GetCachedIcon($"{candidate} Icon");
                if (icon != null) return icon;

                icon = GetCachedIcon(candidate);
                if (icon != null) return icon;
            }

            return null;
        }

        private Texture2D GetCachedIcon(string iconName)
        {
            if (string.IsNullOrEmpty(iconName)) return null;
            if (_iconCache.TryGetValue(iconName, out var cached)) return cached;

            var content = EditorGUIUtility.IconContent(iconName);
            var texture = content?.image as Texture2D;
            _iconCache[iconName] = texture;
            return texture;
        }

        private List<YAMLCompare.PropertyDiff> FilterRotationDiffs(List<YAMLCompare.PropertyDiff> diffs)
        {
            var hasLocalRotation = diffs.Any(d => d.propertyName == "m_LocalRotation");
            var hasEulerAngles = diffs.Any(d => d.propertyName == "m_LocalEulerAnglesHint");

            var result = new List<YAMLCompare.PropertyDiff>();
            
            foreach (var diff in diffs)
            {
                // Skip quaternion rotation (redundant with euler angles)
                if (diff.propertyName == "m_LocalRotation" && hasEulerAngles)
                    continue;

                // Humanize property names for display
                var displayName = diff.propertyName switch
                {
                    "m_LocalPosition" => "Position",
                    "m_LocalScale" => "Scale",
                    "m_LocalEulerAnglesHint" => "Rotation",
                    "m_LocalRotation" => "Rotation",
                    _ => diff.propertyName
                };

                result.Add(new YAMLCompare.PropertyDiff
                {
                    propertyName = displayName,
                    oursValue = diff.oursValue,
                    theirsValue = diff.theirsValue,
                    isConflict = diff.isConflict,
                    isArrayProperty = diff.isArrayProperty
                });
            }

            return result;
        }

        private string GetGoName(string goId, Dictionary<string, YAMLCompare.ChangeInfo> goById, YAMLCompare.ChangeInfo goChange = null)
        {
            if (goChange != null && goChange.blockName != null) return goChange.blockName;
            if (goById != null && goById.TryGetValue(goId, out var c) && c.blockName != null) return c.blockName;

            if (_comparison.oursBlocks.TryGetValue(goId, out var block) && block.name != null) return block.name;
            if (_comparison.theirsBlocks.TryGetValue(goId, out block) && block.name != null) return block.name;
            if (_comparison.baseBlocks.TryGetValue(goId, out block) && block.name != null) return block.name;

            return $"ID {goId}";
        }
    }
}
