# com.overdrive.merge — Technical Reference

**Package:** `com.overdrive.merge` v0.5.2
**Display name:** Overdrive Smart Merge
**Unity minimum:** 2021.3
**Assembly:** `Overdrive.SceneMerge.Editor`
**Namespaces:** `Overdrive.Merge.Editor`, `Overdrive.SceneMerge`
**Dependencies:** `Overdrive.Framework`, `Overdrive.ToolsetManager.Editor`

> For user-facing flow documentation see [FLOW.md](FLOW.md).

---

## Overview

This package does two things:

1. **Pre-Merge Check** — an editor window that shows a clear, friendly diff of what will change in the active scene if the user pulls from upstream right now. Runs before any git operation so the user can make informed decisions.

2. **Git Merge Driver** — a system-level CLI tool (`SceneMergeTool`) that git invokes automatically when merging `.unity` files. It delegates to UnityYAMLMerge to perform the actual 3-way merge, ensuring the merge result matches what the Pre-Merge Check showed.

---

## Package Layout

```
com.overdrive.merge/
├── package.json
├── README.md                       ← this file
├── FLOW.md                         ← end-to-end flow analysis
├── CLI~/                           ← bundled CLI tool (~ excluded from Unity import)
│   ├── VERSION.txt                 ← build number of the CLI tool
│   ├── win-x64/SceneMergeTool.exe
│   ├── osx-x64/SceneMergeTool
│   └── osx-arm64/SceneMergeTool
└── Editor/
    ├── Overdrive.SceneMerge.Editor.asmdef
    ├── SceneMergeInstaller.cs      ← [InitializeOnLoad] — copies CLI, configures git
    ├── SceneMergeStatus.cs         ← Window > Overdrive > Scene Merge (status window)
    ├── YAMLCompare.cs              ← core parser and 3-way diff engine
    ├── PullPreviewWindow.cs        ← Pre-Merge Check editor window + UI logic
    ├── YAMLPropertyUI.cs           ← typed property display elements (color, vector, etc.)
    └── Resources/
        └── UI/PullPreview.uxml     ← UI layout for the preview window
```

The CLI source lives outside this package at `C:\_git\overdrive-merge-tool` (Go project).

---

## Installation Flow (`SceneMergeInstaller.cs`)

`[InitializeOnLoad]` — runs automatically on Unity startup and package import via `EditorApplication.delayCall`.

```
CheckAndInstall()
  ├── Compare stored EditorPref version vs current package version
  ├── If different (or tool missing):
  │     InstallTool()
  │       1. CreateDirectory  → %LOCALAPPDATA%\Overdrive\SceneMerge\  (Win)
  │                          → ~/Library/Application Support/Overdrive/SceneMerge/  (Mac)
  │       2. Copy CLI executable from CLI~/{platform}/ to install dir
  │       3. Write toolVersion.txt (read from CLI~/VERSION.txt)
  │       4. chmod +x  (Mac/Linux only)
  │       5. ConfigureGit()
  │             a. Check we are inside a git repo
  │             b. Append  *.unity merge=unityscenemerge  to .gitattributes
  │             c. git config merge.unityscenemerge.driver "SceneMergeTool" %O %A %B %P
  │             d. git config merge.unityscenemerge.name "Unity Scene Merge Tool"
  │       6. Store installed version in EditorPrefs
  │       7. Open SceneMergeStatus window
  └── (no-op if already installed at current version)
```

**Install directory:**

| Platform | Path |
|----------|------|
| Windows  | `%LOCALAPPDATA%\Overdrive\SceneMerge\` |
| macOS    | `~/Library/Application Support/Overdrive/SceneMerge/` |
| Linux    | `~/.local/share/Overdrive/SceneMerge/` |

**Public API** (used by `SceneMergeStatus`):

```csharp
SceneMergeInstaller.IsInstalled()            // bool
SceneMergeInstaller.GetInstalledToolPath()   // string — absolute path to exe
SceneMergeInstaller.IsGitConfigured()        // bool — from EditorPrefs
SceneMergeInstaller.GetGitConfigError()      // string — last error, or ""
SceneMergeInstaller.ReconfigureGit()         // string? — null on success
SceneMergeInstaller.ForceReinstall()         // [MenuItem] manual trigger
SceneMergeInstaller.GIT_ERROR_NOT_A_REPO     // const — sentinel for "no repo yet"
```

---

## YAML Parser (`YAMLCompare.cs`)

### Block Structure

Unity scene/prefab files are sequences of YAML documents separated by `--- !u!TYPE &FILEID` headers. Each document is one Unity object. This parser treats each document as a single **block**, keyed by its `fileID`.

```
--- !u!1 &1234567890
GameObject:
  m_Name: Player
  ...
--- !u!4 &9876543210
Transform:
  m_GameObject: {fileID: 1234567890}
  ...
```

### Block Categories

| Category       | Detection                        | Examples                              |
|----------------|----------------------------------|---------------------------------------|
| `SceneSettings`| fileID ≤ 2 digits                | RenderSettings, LightmapSettings      |
| `SceneRoots`   | typeID == 1660057539             | Object ordering (Unity-managed)       |
| `Stripped`     | header contains "stripped"       | Prefab override stubs inside scenes   |
| `GameObject`   | typeID == 1                      | GameObjects                           |
| `PrefabInstance`| typeID == 1001                  | Instantiated prefabs                  |
| `Secondary`    | everything else                  | Components (Transform, Rigidbody, ...) |

### Per-Block Extraction

For each block the parser captures:

| Field        | Source                                                |
|--------------|-------------------------------------------------------|
| `typeID`     | Header: `--- !u!{typeID}`                             |
| `fileID`     | Header: `&{fileID}`                                   |
| `objectType` | First key on the line after the header                |
| `name`       | `m_Name:` field; for PrefabInstances: resolved from `m_SourcePrefab` GUID via `AssetDatabase` |
| `category`   | `CategorizeBlock(typeID, fileID, isStripped)`         |
| `parentGoID` | `m_GameObject: {fileID: N}` — links components to their owner GO |
| `fullContent`| The entire raw YAML document string                   |

All 6 Regex patterns used during parsing are `static readonly` with `RegexOptions.Compiled` — they are compiled once at class load, not per-block.

### 2-Way Comparison (`CompareBlocks`)

Used when there is no base (e.g. "Compare Two Files" menu item).

```
Pass 1 — iterate oursBlocks:
  key missing from theirs  →  Deleted
  key present, content !=  →  Modified
Pass 2 — iterate theirsBlocks:
  key missing from ours    →  Added
```

### 3-Way Comparison (`CompareBlocksThreeWay`)

Used for Pre-Merge Check. Iterates the union of all three block sets:

```
¬base, ¬ours              →  Added        (only in theirs)
¬base, ¬theirs            →  (skip)       (only in ours — local addition)
¬base, ours == theirs     →  (skip)       (same addition both sides)
¬base, ours != theirs     →  Conflict     (both added differently)
¬ours, ¬theirs            →  (skip)       (both deleted)
¬ours, theirs == base     →  (skip)       (our deletion stands)
¬ours, theirs != base     →  Conflict     (they modified what we deleted)
¬theirs, ours == base     →  Deleted      (clean incoming delete)
¬theirs, ours != base     →  Conflict     (we modified what they deleted)
all three, unchanged      →  (skip)
all three, ours == theirs →  (skip)       (same change both sides)
all three, ours == base   →  Modified     (only theirs changed — clean incoming)
all three, theirs == base →  (skip)       (only ours changed — no incoming)
all three, both changed   →  Conflict
```

---

## Pre-Merge Check UI (`PullPreviewWindow.cs`)

### Entry Points

| Menu item | Method | Description |
|-----------|--------|-------------|
| `Tools/Overdrive/Scene Merge/Pre-Merge Check Active Scene` | `PreMergeCheckActiveScene()` | Main workflow — compares saved scene vs upstream |
| `Tools/Overdrive/Scene Merge/TEST Preview Pull Changes` | `ShowWindowTest()` | Uses hardcoded test files at `Assets/Merge Testing/` |
| `Tools/Overdrive/Scene Merge/Compare Two Files` | `CompareTwoFiles()` | File picker, 2-way diff |

### How `PreMergeCheckActiveScene` Builds Its Inputs

```
git rev-parse --show-toplevel          → repo root
git rev-parse --abbrev-ref @{u}        → upstream (e.g. origin/main)
git merge-base HEAD {upstream}         → base commit hash
git show {base}:{scene_path}           → base content  → temp file
git show {upstream}:{scene_path}       → theirs content → temp file
saved scene file on disk               → ours
YAMLCompare.CompareFiles(base, ours, theirs)
```

Temp files are cleaned up in a `finally` block regardless of outcome.

### Display Grouping

| Category | Grouping |
|---|---|
| `GameObject` + `Secondary` | One foldout per GO; components listed inside. GOs with all-components-added/removed shown flat. |
| `PrefabInstance` | One foldout per instance |
| `SceneSettings` | One foldout per block |
| `SceneRoots` | **Not shown** — Unity regenerates on import; changes are noise |
| `Stripped` | Not shown directly; their owned Secondary blocks are also excluded |

### Property Diffing

`DiffProperties(oursContent, theirsContent, baseContent?)` flattens each block to `key: value` pairs (skipping YAML headers and list items) and returns a list of `(key, oursVal, theirsVal, isConflict)` tuples for every key where ours ≠ theirs.

`isConflict = true` when base is known AND both ours and theirs diverged from base independently.

For `Modified` GO blocks, diffs are computed **once** in `CreateBlockGroup` and passed to `CreateBlockItem` via `precomputedDiffs` to avoid a redundant parse.

---

## Property UI (`YAMLPropertyUI.cs`)

Renders individual property diff rows with typed display elements. All Regex patterns are `static readonly` compiled fields.

| ValueKind   | Detection                           | UIElement       |
|-------------|-------------------------------------|-----------------|
| `Color`     | `{r: _, g: _, b: _, a: _}`          | `ColorField`    |
| `Vector4`   | `{x: _, y: _, z: _, w: _}`          | `Vector4Field`  |
| `Vector3`   | `{x: _, y: _, z: _}` (no w)        | `Vector3Field`  |
| `Vector2`   | `{x: _, y: _}` (no z or w)         | `Vector2Field`  |
| `ObjectRef` | `{fileID: _}`                       | `Label`         |
| `Float`     | `^-?\d+\.\d+$`                      | `FloatField`    |
| `Int`       | `^-?\d+$`                           | `IntegerField`  |
| `String`    | everything else                     | `Label`         |

Non-conflict rows show the incoming (theirs) value only.
Conflict rows show both `Yours: {ours}` and `Theirs: {theirs}` side by side (column layout via CSS).

---

## CLI Tool (`SceneMergeTool`)

Source: `C:\_git\overdrive-merge-tool` (Go)
Build output: `CLI~/{platform}/SceneMergeTool[.exe]`
CLI build number: `CLI~/VERSION.txt`

### Merge Mode (invoked by git)

```
SceneMergeTool <base> <ours> <theirs> [<path>]
```

1. Locate `UnityYAMLMerge.exe` — searches Unity Hub installs by version (newest first); `UNITY_YAML_MERGE` env var overrides.
2. Run `UnityYAMLMerge merge --fallback none -p <base> <ours> <theirs> <output>`
3. Exit 0 → clean merge; copy output → ours file, exit 0
4. Exit 2 → conflicts present; ours values kept; copy output → ours file, exit 0
5. Other → failure; exit 1 (git marks the merge as failed)

Debug log: `{InstallDir}/merge-debug.log`

---

## Testing

**Menu:** `Tools/Overdrive/Scene Merge/TEST Preview Pull Changes`

Opens the Pre-Merge Check window using hardcoded test scene files. Does not require a live git repo.

Requires:
```
Assets/Merge Testing/MergeTest_Base.unity
Assets/Merge Testing/MergeTest_Ours.unity
Assets/Merge Testing/MergeTest_Theirs.unity
```

---

## Key Data Types

```csharp
// YAMLCompare.YAMLBlock — one parsed YAML document
string typeID, fileID, objectType, fullContent, name, parentGoID;
BlockCategory category;

// YAMLCompare.ChangeInfo — one entry in the changes list
ChangeType changeType;          // Added | Deleted | Modified | Conflict
BlockCategory blockCategory;
string blockID, blockType, blockName;
string oursContent, theirsContent, baseContent;  // null if not present
string parentGoID;

// YAMLCompare public fields
Dictionary<string, YAMLBlock> baseBlocks, oursBlocks, theirsBlocks;
List<ChangeInfo> changes;
```

---

## Menu Reference

| Path | Class | Notes |
|------|-------|-------|
| `Tools/Overdrive/Scene Merge/Pre-Merge Check Active Scene` | `PullPreviewWindow` | Main feature |
| `Tools/Overdrive/Scene Merge/Compare Two Files` | `PullPreviewWindow` | File picker, 2-way |
| `Tools/Overdrive/Scene Merge/TEST Preview Pull Changes` | `PullPreviewWindow` | Uses test scenes |
| `Tools/Overdrive/Scene Merge/Force Reinstall CLI Tool` | `SceneMergeInstaller` | Debug / recovery |
| `Window/Overdrive/Scene Merge` | `SceneMergeStatus` | Install + license status |
