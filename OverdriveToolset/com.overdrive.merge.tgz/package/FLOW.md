# Scene Merge — Flow Analysis

## Overall
**Problem**
Unity workflows often suffer from "merge conflicts" when teams edit scenes and prefabs. These are large YAML files, difficult to merge in Git clients, especially for non-technical artists typically working on these areas. As a result, work is often lost due to bad merges, or significantly complicated upfront to hopefully avoid merges.

**Desired Outcome**
Safe, confident Scene and Prefab merges, with minimal manual work and no technical knowledge required.

## Desired User Flow

**Current Status:**
- ✅ Pre-Merge Check and preview (step 1-2)
- ✅ ID collision detection and fixing
- ✅ Git merge driver integration (step 3)
- ✅ **Stash system for selective property preservation (steps 2 & 4)**

1. **User works on their scene, saves.**
2. **Before (or after) committing, they run Pre-Merge Check.**
   The goal is proactive conflict avoidance: see clearly what will change if they pull right now, and make deliberate choices before the merge happens. User can click "Stash Theirs" or "Stash Ours" buttons on individual properties to save values that would be discarded. These are written to a `.stash` file next to the scene.
3. **User pulls. The git merge driver takes over.**
   The merge result must match exactly what the Pre-Merge Check showed. We can never show one thing and silently produce another. To ensure this, use standard Unity YAML Merge (not custom), applying "Ours" for any conflicts.
4. **Stash is applied (if user created one)**
   User runs `Tools > Overdrive > Scene Merge > Apply Stashes` after the merge. This patches the stashed property values into the merged scene file using YAML parsing (similar to Scene Blocks). The `.stash` file is then deleted.

---

## How Pre-Merge Check Works

Entry point: `PullPreviewWindow.PreMergeCheckActiveScene()`

```
1. Find git repo root (git rev-parse --show-toplevel)
2. Find upstream tracking branch (git rev-parse --abbrev-ref @{u})
3. Find common ancestor: base = git merge-base HEAD {upstream}
4. Read base file:   git show {base}:{scene_path}     → write to temp file
5. Read theirs file: git show {upstream}:{scene_path}  → write to temp file
6. ours = the saved scene file on disk (absScenePath)
7. Run: YAMLCompare.CompareFiles(base, ours, theirs)   [3-way]
8. Show results in PullPreviewWindow
```

The three inputs map directly to standard 3-way merge semantics:

| Input  | Source                          | Meaning                      |
|--------|---------------------------------|------------------------------|
| `base` | `git merge-base HEAD {upstream}` | Common ancestor              |
| `ours` | Saved scene file on disk        | Our current working state    |
| `theirs` | `{upstream}:{scene_path}`     | Incoming (upstream) changes  |

---

## What the Pre-Merge Check Shows

`CompareBlocksThreeWay()` classifies every YAML block in the scene:

| Change Type | Condition                                        | Meaning for the user                            |
|-------------|--------------------------------------------------|-------------------------------------------------|
| `Modified`  | Only theirs diverged from base; ours unchanged   | Clean incoming change — will be auto-applied    |
| `Added`     | Block exists in theirs, not in base or ours      | Incoming addition — will be added               |
| `Deleted`   | Theirs deleted it; ours unchanged from base      | Incoming deletion — will be removed             |
| `Conflict`  | Both ours and theirs diverged from base differently | Needs attention — see conflict handling below |
| *(hidden)*  | Only ours changed; theirs unchanged from base    | Our local change — no incoming, not shown       |
| *(hidden)*  | Both match base, or same change both sides       | No difference — not shown                       |

**SceneRoots blocks (typeID 1660057539) are intentionally excluded from display.**
They track scene object ordering, change almost universally between branches, and Unity regenerates them automatically on scene import. Showing them is noise.

---

## How the Git Merge Driver Works

Configured in `.gitattributes`:
```
*.unity merge=unityscenemerge
```

Configured in `.git/config` (per-project):
```
[merge "unityscenemerge"]
    driver = "SceneMergeTool.exe" %O %A %B %P
    name   = Unity Scene Merge Tool
```

Git substitutes:
- `%O` → base (common ancestor temp file)
- `%A` → ours (current branch version — **modified in-place**)
- `%B` → theirs (incoming version temp file)
- `%P` → the actual scene path in the repo (currently passed through, not yet used by the driver)

The driver (`SceneMergeTool.exe`, Go project at `C:\_git\overdrive-merge-tool`):

```
1. Locate UnityYAMLMerge.exe (searches Unity Hub installs by version, newest first;
   UNITY_YAML_MERGE env var can override)
2. Run: UnityYAMLMerge merge --fallback none -p <base> <ours> <theirs> <output>
3. On exit 0:  clean merge — copy output → ours file, exit 0
4. On exit 2:  conflicts present — copy output (ours values kept) → ours file, exit 0
5. Other exit: failure — exit 1 (git marks the merge as failed; user must resolve manually)
```

**Argument Order:** UnityYAMLMerge uses `base, left, right, output` where "left" (2nd argument) wins in property-level conflicts. We pass `base, ours, theirs, output` so OURS wins in conflicts.

**Deletions:** Unity treats deletions specially - they always win, regardless of which side deleted and what the other side did. Delete-vs-modify scenarios exit with code 0 (clean merge), not code 2, but represent data loss.

All operations are logged to:
- Windows: `%LOCALAPPDATA%\Overdrive\SceneMerge\merge-debug.log`
- macOS:   `~/Library/Application Support/Overdrive/SceneMerge/merge-debug.log`

---

## Argument Order Consistency

The same base/ours/theirs order is used throughout the entire chain — no transposition anywhere:

| Layer                        | base       | ours              | theirs       |
|------------------------------|------------|-------------------|--------------|
| Git driver call              | `%O`       | `%A`              | `%B`         |
| `PreMergeCheckActiveScene`   | `baseTmp`  | `absScenePath`    | `theirsTmp`  |
| `CompareFiles(b, o, t)`      | arg 1      | arg 2             | arg 3        |
| `CompareBlocksThreeWay`      | `baseBlock`| `oursBlock`       | `theirsBlock`|
| `TestMergeTool --compare`    | arg 1      | arg 2             | arg 3        |

---

## Conflict Handling

**Critical Concept: We Cannot Control the Merge**

The merge result is determined entirely by UnityYAMLMerge's behavior. We have no control over this — it's Unity's tool, and it follows fixed rules:

1. **Property-level conflicts** → OURS wins (our values are kept)
2. **Delete-vs-modify scenarios** → DELETION wins (modifications are lost)

This is non-negotiable. **Stash is our workaround.** It's a user-initiated, post-merge correction mechanism that allows selective application of values that would otherwise be discarded.

When UnityYAMLMerge exits with code `2`, it has encountered property-level conflicting changes and resolved them by **keeping ours** (because "ours" is the 2nd argument, and UnityYAMLMerge keeps the 2nd argument's values in conflicts). The driver treats this as a success (exit 0) and writes the result to the scene file.

This is the safe default — the user's work is never silently overwritten. But if they want theirs values, they must use Stash. 

### Stash System for Selective Property Preservation

The stash system allows users to save values that would be discarded during a merge and apply them after the merge completes.

**Because we cannot control the merge behavior, Stash is our only mechanism for preserving discarded values.**

**Workflow:**

1. Pre-Merge Check shows conflicts with stash buttons next to values that will be discarded:
   - **Property conflicts**: "Stash Theirs" button per-property (because ours wins, theirs gets discarded)
   - **Deletion conflicts**: Single "Stash Ours (EntityName)" or "Stash Theirs (EntityName)" button at the highest level (GameObject or component):
     - If they deleted but we modified → "Stash Ours (EntityName)" (our entire entity gets discarded)
     - If we deleted but they modified → "Stash Theirs (EntityName)" (their entire entity gets discarded)
     - For GameObject deletions with component changes, only one button appears at the GameObject level (not per-component)
2. User clicks stash button on any property or entity they want to preserve.
3. Those values are serialized to a `.stash` JSON file alongside the scene (e.g., `MyScene.unity.stash`).
4. After the merge completes (with merge tool's fixed behavior applied), user runs `Tools > Overdrive > Scene Merge > Apply Stashes`.
5. The stash applicator patches the saved values into the merged scene using YAML parsing.
6. The stash file is deleted automatically after successful application.

**This two-step process (merge → stash apply) is the only way to override the merge tool's fixed behavior.**

**Stash Data Structure:**
```json
{
  "sceneGuid": "abc123...",
  "scenePath": "Assets/Scenes/MyScene.unity",
  "entries": [
    {
      "blockId": "123456789",
      "blockType": "Transform",
      "blockName": "GameObject Name",
      "propertyPath": "m_LocalPosition",
      "value": "{x: 1.5, y: 2.0, z: 0.5}",
      "source": "theirs",
      "timestamp": "2026-02-13 14:30:00",
      "isDependentReference": false,
      "referencedEntityId": ""
    },
    {
      "blockId": "987654321",
      "blockType": "MeshRenderer",
      "blockName": "PlayerModel",
      "propertyPath": "__FULL_ENTITY__",
      "value": "--- !u!23 &987654321\nMeshRenderer:\n  ...",
      "source": "ours",
      "timestamp": "2026-02-13 14:35:00",
      "isDependentReference": false,
      "referencedEntityId": ""
    },
    {
      "blockId": "555555555",
      "blockType": "MonoBehaviour",
      "blockName": "LevelScript",
      "propertyPath": "targetCollider",
      "value": "{fileID: 987654321}",
      "source": "ours",
      "timestamp": "2026-02-13 14:35:00",
      "isDependentReference": true,
      "referencedEntityId": "987654321"
    }
  ]
}
```

**Property-level vs Entity-level Stashing:**
- **Property stashing**: Individual property values are stored and patched into existing blocks
- **Entity stashing**: Entire YAML blocks are stored (marked by `propertyPath: "__FULL_ENTITY__"`) and either replace existing blocks or are inserted as new blocks
  - **Reference tracking**: When stashing an entity, the system automatically finds and stashes all property references to that entity's fileID across the entire scene. This ensures that when the entity is restored, any other components referencing it (e.g., LevelScript referencing a BoxCollider) will have their references restored as well, maintaining object relationships.

**Key Features:**
- **Per-property granularity for property conflicts**: Users can selectively stash individual property values from "theirs"
- **Entity-level stashing for deletions**: Single button stashes entire component/GameObject/prefab as a complete YAML block
- **Automatic reference tracking**: When stashing an entity, all property references to it are automatically discovered and stashed
- **Smart application order**: Stashed entries are applied in dependency order (entities first, then references, then regular properties)
- **Explicit button labels**: "Stash Ours (EntityName)" or "Stash Theirs" clearly indicate source and target
- **Hierarchical button placement**: GameObject-level deletions show only one button (not duplicated per-component)
- **Safe two-step process**: Merge completes normally, then stash applies as a patch
- **Works with Scene Blocks pattern**: Uses similar YAML parsing and patching logic
- **Clear user feedback**: Dialogs confirm what was stashed and how to apply

**Implementation Files:**
- `YAMLStash.cs`: Data structure and file I/O
- `YAMLStashApplicator.cs`: Applies stashes to scene files (property-level and entity-level)
- `PullPreviewWindow.cs`: UI integration with stash buttons and entity stashing logic
- `PullPreviewUIBuilder.cs`: Button creation and placement
- `YAMLPropertyUI.cs`: Property diff rows with stash callbacks

### Delete-vs-Modify Scenarios

**Important:** Unity treats delete-vs-modify scenarios differently from property-level conflicts:

- **Exit code:** 0 (clean merge), not 2 (conflict)
- **Behavior:** Deletion always wins, regardless of which side deleted
- **Data loss:** The modifications from the other side are lost
- **Our handling:** YAMLCompare correctly identifies these as conflicts and the UI warns users that "deletion wins" and their changes will be lost

### ID Collision Detection and Fixing (Implemented)

**What it is:** When the same `fileID` is used for different component types (different `ClassID` / `typeID`) in ours vs theirs, UnityYAMLMerge will crash.

**Detection:** YAMLCompare automatically detects ID collisions during comparison and sets `hasIDCollision = true` on the affected blocks.

**UI:** The Pull Preview window shows a prominent warning for any ID collision with a "Fix ID Collision" button.

**Fix:** Clicking "Fix ID Collision" calls `YAMLCompare.FixIDCollision()` which:
1. Generates a new unique fileID for the conflicting block in ours
2. Updates all references to that ID throughout the file
3. Writes the fixed file back to disk
4. Forces Unity to reimport the asset

This prevents merge-time crashes and must be done before running the actual merge.

---

## Forward-Looking Notes

- **`%P` (scene path) is passed to the driver but currently unused.**
  Wire up `os.Args[4]` in `main.go` if the driver ever needs to locate the project root or resolve asset references.

- **Between running Pre-Merge Check and actually pulling**, new commits may be pushed to upstream. The base and theirs inputs will be re-evaluated by git at pull time, so the preview and the merge result can diverge if upstream moves. This is inherent to the workflow and not a code issue.
